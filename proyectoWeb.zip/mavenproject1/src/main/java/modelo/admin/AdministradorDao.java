/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.admin;


import bd.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author Marely
 */
public class AdministradorDao implements Admin_crud {
  Conexion conetion = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    @Override
    public int setagregaradmin() {
        return 2;
    }

    @Override
    public int buscar(Administrador tr) {
        String sql = "SELECT * FROM administrador WHERE `correo electronico`=? AND contraseña=?";
        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ps.setString(1, tr.getCorreo());
            ps.setString(2, tr.getContraseña());

            rs = ps.executeQuery();
            if (rs.next()) {
                // Si hay resultados, significa que se encontró un usuario con el correo y contraseña proporcionados
                return 1;
            } else {
                // Si no hay resultados, significa que no se encontró el usuario
                return 0;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "error de busquedad" + e.getMessage(), JOptionPane.ERROR_MESSAGE);
            return 0;
        }
    }

}
