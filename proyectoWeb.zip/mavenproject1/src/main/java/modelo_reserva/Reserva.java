/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_reserva;

import java.sql.Date;
import modelo_alojamiento.alojamiento;
import modelo_habitaciones.habitacion;


/**
 *
 * @author Marely
 */
public class Reserva {

    private int idreserva, idalojamiento, personas, c_habitaciones,habitacion;
   
    private Date fechaentrada, fechasalida;
    private Boolean estado;
    
 
    
  
private  alojamiento alojamiento;
    private String nombreAlojamiento;
    private String direccionAlojamiento;
    private String telefonoAlojamiento;
    private byte[] foto;

    public Reserva() {
    }

    public byte[] getFoto() {
        return foto;
    }

    public void setFoto(byte[] foto) {
        this.foto = foto;
    }

  

    public Boolean getEstado() {
        return estado;
    }

    public void setEstado(Boolean estado) {
        this.estado = estado;
    }

    public String getNombreAlojamiento() {
        return nombreAlojamiento;
    }

    public void setNombreAlojamiento(String nombreAlojamiento) {
        this.nombreAlojamiento = nombreAlojamiento;
    }

    public String getDireccionAlojamiento() {
        return direccionAlojamiento;
    }

    public void setDireccionAlojamiento(String direccionAlojamiento) {
        this.direccionAlojamiento = direccionAlojamiento;
    }

    public String getTelefonoAlojamiento() {
        return telefonoAlojamiento;
    }

    public void setTelefonoAlojamiento(String telefonoAlojamiento) {
        this.telefonoAlojamiento = telefonoAlojamiento;
    }

  
    public int getIdreserva() {
        return idreserva;
    }

    public void setIdreserva(int idreserva) {
        this.idreserva = idreserva;
    }

    public int getIdalojamiento() {
        return idalojamiento;
    }

    public void setIdalojamiento(int idalojamiento) {
        this.idalojamiento = idalojamiento;
    }

    public int getPersonas() {
        return personas;
    }

    public void setPersonas(int personas) {
        this.personas = personas;
    }

    public int getC_habitaciones() {
        return c_habitaciones;
    }

    public void setC_habitaciones(int c_habitaciones) {
        this.c_habitaciones = c_habitaciones;
    }

   

    public Date getFechaentrada() {
        return fechaentrada;
    }

    public int getHabitacion() {
        return habitacion;
    }

    public void setHabitacion(int habitacion) {
        this.habitacion = habitacion;
    }

 
    public alojamiento getAlojamiento() {
        return alojamiento;
    }

    public void setAlojamiento(alojamiento alojamiento) {
        this.alojamiento = alojamiento;
    }
    

    public void setFechaentrada(Date fechaentrada) {
        this.fechaentrada = fechaentrada;
    }

    public Date getFechasalida() {
        return fechasalida;
    }

    public void setFechasalida(Date fechasalida) {
        this.fechasalida = fechasalida;
    }

    public Boolean getestado() {
        return estado;
    }

    public void setestado(Boolean estado) {
        this.estado = estado;
    }

}
