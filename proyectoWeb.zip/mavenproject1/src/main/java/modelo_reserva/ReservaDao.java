/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package modelo_reserva;

import bd.Conexion;
import datos.datosguardados;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import modelo_alojamiento.alojamiento;
import modelo_habitaciones.habitacion;
import modelo_recepcionista.Recepcionista;
import modelo_reserva.Reserva;
import modelo_usuario.Usuario;

/**
 *
 * @author Marely
 */
public class ReservaDao implements Crud_reserva {

    Conexion conetion = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    @Override
    public int agregarreserva(Reserva tr) {
        String sql2 = "SELECT MAX(habitacion) AS ultimo_numero FROM reservas WHERE HabitacionID = ?";
        String sql = "INSERT INTO reservas (UsuarioID, HabitacionID, FechaEntrada, FechaSalida,  NumeroHabitaciones,habitacion,Estado) VALUES (?,?,  ?, ?, ?, ?, ? )";
        try {
            int num_habitacion = 1;
            con = conetion.getCon();
            ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            PreparedStatement ps2 = con.prepareStatement(sql2);

            habitacion hab = datosguardados.getHabitacionActual();
            Usuario usu = datosguardados.getUsuarioactual();

            ps2.setInt(1, hab.getHabitacionid());
            rs = ps2.executeQuery();
            while (rs.next()) {
                int num = rs.getInt("ultimo_numero");
                System.out.println("ultimo numoro" + num);
                num_habitacion += num;
            }

            tr.setHabitacion(num_habitacion);

            ps.setInt(1, usu.getIdusuario());

            ps.setInt(2, hab.getHabitacionid());
            ps.setDate(3, tr.getFechaentrada());
            ps.setDate(4, tr.getFechasalida());

            ps.setInt(5, tr.getC_habitaciones());
            ps.setInt(6, tr.getHabitacion());
            ps.setInt(7, 0);
//            ps.setBoolean(10,tr.getestado());

            int affectedRows = ps.executeUpdate();

            if (affectedRows > 0) {
                ResultSet generatedKeys = ps.getGeneratedKeys();
                if (generatedKeys.next()) {
                    tr.setIdreserva(generatedKeys.getInt(1));
                    JOptionPane.showMessageDialog(null, "id de la reserva" + tr.getIdreserva());
                    datosguardados.setReservaactual(tr);

                    return 1;
                }
            } else {
                return 0;
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString());
            e.printStackTrace();
            return 0;
        }
        return 0;

    }

    public int reservarecepcionista(Reserva tr) {
        String sql2 = "SELECT MAX(habitacion) AS ultimo_numero FROM reservas WHERE HabitacionID = ?";
        String sql = "INSERT INTO reservas (recepcionistaid, HabitacionID, FechaEntrada, FechaSalida,  NumeroHabitaciones,habitacion,Estado) VALUES (?,?,  ?, ?, ?, ?, ? )";
        try {
            int num_habitacion = 1;
            con = conetion.getCon();
            ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            PreparedStatement ps2 = con.prepareStatement(sql2);

            habitacion hab = datosguardados.getHabitacionActual();

            Recepcionista re = datosguardados.getRecepcionistaactual();
            ps2.setInt(1, hab.getHabitacionid());
            rs = ps2.executeQuery();
            while (rs.next()) {
                int num = rs.getInt("ultimo_numero");
                num_habitacion += num;
            }

            tr.setHabitacion(num_habitacion);
            ps.setInt(1, re.getRecepcionistaid());
            ps.setInt(2, hab.getHabitacionid());
            ps.setDate(3, tr.getFechaentrada());
            ps.setDate(4, tr.getFechasalida());
            ps.setInt(5, tr.getC_habitaciones());
            ps.setInt(6, tr.getHabitacion());
            ps.setInt(7, 0);
//            ps.setBoolean(10,tr.getestado());

            int affectedRows = ps.executeUpdate();

            if (affectedRows > 0) {
                ResultSet generatedKeys = ps.getGeneratedKeys();
                if (generatedKeys.next()) {
                    tr.setIdreserva(generatedKeys.getInt(1));
                    datosguardados.setReservaactual(tr);
                    Reserva a = datosguardados.getReservaactual();

                    return 1;
                }
            } else {
                return 0;
            }

        } catch (Exception e) {
            System.out.print(e.toString() + "error de actualiacion 1 " + e.getMessage());
            e.printStackTrace();
            return 0;
        }
        return 0;

    }

    @Override
    public List reserva(int a) {
        List<Reserva> reservas = new ArrayList<>();
        String sql = "";
        if (a == 1) {

            sql = "SELECT \n"
                    + "    ur.nombre AS Nombre_Usuario,\n"
                    + "    r.ReservaID,\n"
                    + "    r.habitacion,\n"
                    + "    r.FechaSalida,\n"
                    + "    h.Tipo,\n"
                    + "    h.Precio,\n"
                    + "    a.Nombre AS Nombre_Alojamiento,\n"
                    + "    a.direccion AS Direccion_Alojamiento,\n"
                    + "    a.Telefono,\n"
                    + "     a.Foto\n"
                    + "FROM \n"
                    + "    reservas r\n"
                    + "INNER JOIN \n"
                    + "    habitaciones h ON r.HabitacionID = h.HabitacionID\n"
                    + "INNER JOIN \n"
                    + "    alojamientos a ON h.AlojamientoID = a.AlojamientoID\n"
                    + "INNER JOIN\n"
                    + "    usuarioregistrado ur ON r.UsuarioID = ur.UsuarioID\n"
                    + "WHERE \n"
                    + "    r.pagoID IS NULL\n"
                    + "    AND r.Estado = 0\n"
                    + "    and r.UsuarioID=?";
        } else if (a == 2) {
            sql = "SELECT \n"
                    + "       r.ReservaID,\n"
                    + "       r.habitacion,\n"
                    + "       r.FechaEntrada,\n"
                    + "       r.FechaSalida,\n"
                    + "       h.Tipo,\n"
                    + "       h.Precio,\n"
                    + "       a.Nombre AS Nombre_Alojamiento,\n"
                    + "       a.direccion AS Direccion_Alojamiento,\n"
                    + "       a.Telefono,\n"
                    + "     a.Foto\n"
                    + "FROM reservas r\n"
                    + "INNER JOIN habitaciones h ON r.HabitacionID = h.HabitacionID\n"
                    + "INNER JOIN alojamientos a ON h.AlojamientoID = a.AlojamientoID\n"
                    + "WHERE r.pagoID IS NOT NULL\n"
                    + "AND r.UsuarioID =?\n"
                    + "AND r.Estado = 0 ";
        } else if (a == 3) {
            sql = "SELECT \n"
                    + "       r.ReservaID,\n"
                    + "       r.habitacion,\n"
                    + "       r.FechaEntrada,\n"
                    + "       r.FechaSalida,\n"
                    + "       h.Tipo,\n"
                    + "       h.Precio,\n"
                    + "       a.Nombre AS Nombre_Alojamiento,\n"
                    + "       a.direccion AS Direccion_Alojamiento,\n"
                    + "       a.Telefono,\n"
                    + "     a.Foto\n"
                    + "FROM reservas r\n"
                    + "INNER JOIN habitaciones h ON r.HabitacionID = h.HabitacionID\n"
                    + "INNER JOIN alojamientos a ON h.AlojamientoID = a.AlojamientoID\n"
                    + "WHERE r.pagoID IS NOT NULL\n"
                    + "AND r.UsuarioID =?\n"
                    + "AND r.Estado = 3";

        }

        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            Usuario usu = datosguardados.getUsuarioactual();

            ps.setInt(1, usu.getIdusuario());
            rs = ps.executeQuery();
            while (rs.next()) {
                Reserva reserva = new Reserva();
                reserva.setIdreserva(rs.getInt("ReservaID"));

                reserva.setHabitacion(rs.getInt("habitacion"));
                reserva.setNombreAlojamiento(rs.getString("Nombre_Alojamiento"));
                reserva.setDireccionAlojamiento(rs.getString("Direccion_Alojamiento"));
                reserva.setTelefonoAlojamiento(rs.getString("Telefono"));
                reserva.setFoto(rs.getBytes("Foto"));

                reservas.add(reserva);

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
            e.printStackTrace();
        }
        return reservas;
    }

    public List reservaefectiva() {
        List<Reserva> reservas = new ArrayList<>();
        String sql = "SELECT \n"
                + "       r.ReservaID,\n"
                + "       r.habitacion,\n"
                + "       r.FechaEntrada,\n"
                + "       r.FechaSalida,\n"
                + "       h.Tipo,\n"
                + "       h.Precio,\n"
                + "       a.Nombre AS Nombre_Alojamiento,\n"
                + "       a.direccion AS Direccion_Alojamiento,\n"
                + "       a.Telefono\n"
                + "FROM reservas r\n"
                + "INNER JOIN habitaciones h ON r.HabitacionID = h.HabitacionID\n"
                + "INNER JOIN alojamientos a ON h.AlojamientoID = a.AlojamientoID\n"
                + "WHERE r.pagoID IS NOT NULL\n"
                + "AND r.UsuarioID =?\n"
                + "AND r.Estado = 0 ";
        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            Usuario usu = datosguardados.getUsuarioactual();
            ps.setInt(1, usu.getIdusuario());
            rs = ps.executeQuery();
            while (rs.next()) {
                Reserva reserva = new Reserva();
                reserva.setIdreserva(rs.getInt("ReservaID"));

                reserva.setHabitacion(rs.getInt("habitacion"));
                reserva.setNombreAlojamiento(rs.getString("Nombre_Alojamiento"));
                reserva.setDireccionAlojamiento(rs.getString("Direccion_Alojamiento"));
                reserva.setTelefonoAlojamiento(rs.getString("Telefono"));

                reservas.add(reserva);
                datosguardados.setReservaactual(reserva);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reservas;
    }

    public int detallereserva(Reserva r, alojamiento a, habitacion h, int b) {

        String sql = "SELECT \n"
                + "r.habitacion,\n"
                + "       r.FechaEntrada,\n"
                + "       r.ReservaID,\n"
                + "       r.FechaSalida,\n"
                + "       h.Tipo,\n"
                + "       h.Vista,\n"
                + "       h.Precio,\n"
                + "       a.Nombre AS Nombre_Alojamiento,\n"
                + "       a.direccion AS Direccion_Alojamiento\n"
                + "FROM reservas r\n"
                + "INNER JOIN habitaciones h ON r.HabitacionID = h.HabitacionID\n"
                + "INNER JOIN alojamientos a ON h.AlojamientoID = a.AlojamientoID\n"
                + "WHERE r.ReservaID=?";
        try {

            habitacion ha = datosguardados.getHabitacionActual();

            alojamiento al = datosguardados.getAlojamientoActual();
            con = conetion.getCon();
            ps = con.prepareStatement(sql);

            ps.setInt(1, b);
            rs = ps.executeQuery();
            while (rs.next()) {

                r.setHabitacion(rs.getInt("habitacion"));
                r.setIdreserva(rs.getInt("ReservaID"));

                r.setFechaentrada(rs.getDate("FechaEntrada"));
                r.setFechasalida(rs.getDate("FechaSalida"));

                datosguardados.setReservaactual(r);

                h.setTipo(rs.getString("Tipo"));
                h.setVista(rs.getString("Vista"));
                h.setPrecio(rs.getInt("Precio"));

                datosguardados.setHabitacionActual(h);

                a.setNombre(rs.getString("Nombre_Alojamiento"));
                a.setDireccion(rs.getString("Direccion_Alojamiento"));

                datosguardados.setAlojamientoActual(a);

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
            e.printStackTrace();
            return 0;
        }
        return 1;
    }

    @Override
    public int modificarreserva(Reserva tr) {
        String sql = "UPDATE reservas SET  FechaEntrada=?,  FechaSalida=? WHERE  ReservaID=?";
        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            Reserva re = datosguardados.getReservaactual();

            ps.setDate(1, tr.getFechaentrada());
            ps.setDate(2, tr.getFechasalida());
            ps.setInt(3, re.getIdreserva());
            ps.executeUpdate();
            return 1;

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "error de modificacion" + e.getMessage(), JOptionPane.ERROR_MESSAGE);
            return 0;
        }
    }

    @Override
    public int modificarestadoreserva(int a) {
        String sql = "UPDATE reservas SET Estado=? WHERE ReservaID=?";

        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ReservaDto rdt = datosguardados.getReserva1();
            Reserva re = datosguardados.getReservaactual();
            if (a == 2) {
                ps.setInt(1, 2);
            } else {
                if (a == 3) {
                    ps.setInt(1, 3);
                } else {

                    ps.setInt(1, 1);
                }

            }
            if (rdt == null) {
                ps.setInt(2, re.getIdreserva());
            } else {
                ps.setInt(2, rdt.getIdReserva());
            }
            ps.executeUpdate();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "error de eliminacion" + e.getMessage(), JOptionPane.ERROR_MESSAGE);
            return 0;
        }
        return 1;
    }

    public List<ReservaDto> reservasVirtuales() {
        List<ReservaDto> reservas = new ArrayList<>();
        String sql = "SELECT \n"
                + "    r.ReservaID, \n"
                + "    r.FechaEntrada, \n"
                + "    r.FechaSalida, \n"
                + "    r.habitacion, \n"
                + "    u.nombre AS Nombre_Usuario, \n"
                + "    u.cedula AS Cedula_Usuario, \n"
                + "    h.Tipo AS Tipo_Habitacion, \n"
                + "    h.cantidad AS Cantidad_Huespedes \n"
                + "FROM \n"
                + "    reservas r \n"
                + "JOIN \n"
                + "    usuarioregistrado u ON r.UsuarioID = u.UsuarioID \n"
                + "JOIN \n"
                + "    habitaciones h ON r.HabitacionID = h.HabitacionID \n"
                + "WHERE \n"
                + "    h.AlojamientoID = ?\n"
                + " AND r.pagoId IS NOT NULL\n"
                + "And r.recepcionistaid is null\n"
                + "AND r.Estado = 0";
        try {

            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            alojamiento a = datosguardados.getAlojamientoActual();
            ps.setInt(1, a.getId());
            rs = ps.executeQuery();
            while (rs.next()) {
                ReservaDto reservaDTO = new ReservaDto();
                reservaDTO.setIdReserva(rs.getInt("ReservaID"));
                reservaDTO.setFechaEntrada(rs.getDate("FechaEntrada"));
                reservaDTO.setFechaSalida(rs.getDate("FechaSalida"));
                reservaDTO.setHabitacion(rs.getInt("habitacion"));
                reservaDTO.setNombreUsuario(rs.getString("Nombre_Usuario"));
                reservaDTO.setCedulaUsuario(rs.getInt("Cedula_Usuario"));
                reservaDTO.setTipoHabitacion(rs.getString("Tipo_Habitacion"));
                reservaDTO.setCantidadHuespedes(rs.getInt("Cantidad_Huespedes"));
                reservas.add(reservaDTO);
                datosguardados.setReserva1(reservaDTO);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return reservas;
    }

    public List<ReservaDto> reservaspresenciales(int a) {
        List<ReservaDto> reservas = new ArrayList<>();
        String sql = "";
        if (a == 1) {
            sql = "SELECT \n"
                    + "    r.ReservaID, \n"
                    + "    r.FechaEntrada, \n"
                    + "    r.FechaSalida, \n"
                    + "    r.habitacion, \n"
                    + "    h.Tipo AS Tipo_Habitacion, \n"
                    + "    h.cantidad AS Cantidad_Huespedes \n"
                    + "FROM \n"
                    + "    reservas r \n"
                    + "JOIN \n"
                    + "    habitaciones h ON r.HabitacionID = h.HabitacionID \n"
                    + "WHERE \n"
                    + "    h.AlojamientoID =?\n"
                    + " AND r.pagoId IS NOT NULL\n"
                    + "And r.recepcionistaid IS NOT null\n"
                    + "AND r.Estado = 0";
        } else if (a == 3) {
            sql = "SELECT \n"
                    + "    r.ReservaID, \n"
                    + "    r.FechaEntrada, \n"
                    + "    r.FechaSalida, \n"
                    + "    r.habitacion, \n"
                    + "    h.Tipo AS Tipo_Habitacion, \n"
                    + "    h.cantidad AS Cantidad_Huespedes \n"
                    + "FROM \n"
                    + "    reservas r \n"
                    + "JOIN \n"
                    + "    habitaciones h ON r.HabitacionID = h.HabitacionID \n"
                    + "WHERE \n"
                    + "    h.AlojamientoID =?\n"
                    + " AND r.pagoId IS NOT NULL\n"
                    + "AND r.Estado = 3";
        } else {
            sql = "SELECT \n"
                    + "    r.ReservaID, \n"
                    + "    r.FechaEntrada, \n"
                    + "    r.FechaSalida, \n"
                    + "    r.habitacion, \n"
                    + "    h.Tipo AS Tipo_Habitacion, \n"
                    + "    h.cantidad AS Cantidad_Huespedes \n"
                    + "FROM \n"
                    + "    reservas r \n"
                    + "JOIN \n"
                    + "    habitaciones h ON r.HabitacionID = h.HabitacionID \n"
                    + "WHERE \n"
                    + "    h.AlojamientoID =?\n"
                    + " AND r.pagoId IS NOT NULL\n"
                    + "AND r.Estado = 2";
        }
        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            alojamiento alo = datosguardados.getAlojamientoActual();
            ps.setInt(1, alo.getId());
            rs = ps.executeQuery();
            while (rs.next()) {
                ReservaDto reservaDTO = new ReservaDto();
                reservaDTO.setIdReserva(rs.getInt("ReservaID"));
                reservaDTO.setFechaEntrada(rs.getDate("FechaEntrada"));
                reservaDTO.setFechaSalida(rs.getDate("FechaSalida"));
                reservaDTO.setHabitacion(rs.getInt("habitacion"));
                reservaDTO.setTipoHabitacion(rs.getString("Tipo_Habitacion"));
                reservaDTO.setCantidadHuespedes(rs.getInt("Cantidad_Huespedes"));
                reservas.add(reservaDTO);
                datosguardados.setReserva1(reservaDTO);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return reservas;
    }

}
