/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_comentario;


import bd.Conexion;
import datos.datosguardados;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import modelo_alojamiento.alojamiento;
import modelo_usuario.Usuario;

/**
 *
 * @author Marely
 */
public class ComentarioDao implements Crud_comentario {

    Conexion conetion = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    @Override
    public int agregarcomentario(Comentario tr) {
        String sql = "INSERT INTO comentarios ( UsuarioID, AlojamientoID, Comentario, Calificacion) VALUES ( ?, ?, ?,?)";
        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            Usuario usu = datosguardados.getUsuarioactual();
            alojamiento alo = datosguardados.getAlojamientoActual();
            if (usu == null) {
                return 2;
            } else {
                ps.setInt(1, usu.getIdusuario());
            }
            ps.setInt(2, alo.getId());
            ps.setString(3, tr.getComentario());
            ps.setInt(4, tr.getCalificacion());

            ps.executeUpdate();
            return 1;
        } catch (Exception e) {
            System.out.print(e.toString() + "error de actualiacion 1 " + e.getMessage());
            return 0;
        }
    }

    @Override
    public List obtenercomentarios() {

        List<Comentario> comentarios = new ArrayList<>();
        String sql = "SELECT   Comentarios.Comentario,comentarios.Calificacion, usuarioregistrado.nombre FROM Comentarios JOIN usuarioregistrado ON Comentarios.UsuarioID = usuarioregistrado.UsuarioID WHERE Comentarios.AlojamientoID =?";
        try {
            alojamiento alo = datosguardados.getAlojamientoActual();
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ps.setInt(1, alo.getId());
            rs = ps.executeQuery();
            while (rs.next()) {

                String nombre = rs.getString("nombre");
                String comentario = rs.getString("Comentario");
                int calificacion = rs.getInt("Calificacion");

                Comentario c = new Comentario();
                c.setNombre(nombre);
                c.setComentario(comentario);
                c.setCalificacion(calificacion);

                comentarios.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return comentarios;
    }

}
