/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_gerente;

/**
 *
 * @author Marely
 */
public class gerente {
    
    private String nombre;
private int gerenteid;
    private int cedula;
    private String telefono;
    private String corre;
    private String contraseña;

    

    public gerente(String nombre,int gerenteid, int cedula,String telefono, String corre, String contraseña) {
        this.nombre = nombre;
        this.gerenteid=gerenteid;
        this.cedula = cedula;
        this.corre = corre;
        this.telefono=telefono;
        this.contraseña = contraseña;
    }
    public gerente() {
    }

    public int getGerenteid() {
        return gerenteid;
    }

    public void setGerenteid(int gerenteid) {
        this.gerenteid = gerenteid;
    }

    
    
    public String getNombre() {
        return nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public String getCorreo() {
        return corre;
    }

    public void setCorre(String corre) {
        this.corre = corre;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
}