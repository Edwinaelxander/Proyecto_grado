/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_gerente;

import bd.Conexion;
import datos.datosguardados;
import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import modelo_alojamiento.alojamiento;

/**
 *
 * @author Marely
 */
public class gerenteDao implements crud_gerente {

    Conexion conetion = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    @Override
    public int setagregargerente(gerente tr) {
        String sql = "INSERT INTO gerentes (nombre, cedula, telefono, `correo electronico`, contraseña) VALUES(?,?,?,?,?)";

        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ps.setString(1, tr.getNombre());
            ps.setInt(2, tr.getCedula());
            ps.setString(3, tr.getTelefono());
            ps.setString(4, tr.getCorreo());
            ps.setString(5, tr.getContraseña());
            ps.executeUpdate();
            return 1;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "error de insercion" + e.getMessage(), JOptionPane.ERROR_MESSAGE);
            return 0;
        }
    }

    @Override
    public int setbuscar(gerente tr) {
        String sql = "SELECT * FROM gerentes WHERE `correo electronico`=? AND contraseña=?";
        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ps.setString(1, tr.getCorreo());
            ps.setString(2, tr.getContraseña());

            rs = ps.executeQuery();
            if (rs.next()) {
                int id = rs.getInt("GerenteID");

                tr.setGerenteid(id);
                tr.setNombre(rs.getString("nombre"));
                
                datosguardados.setGerenteActual(tr);
                return 1;

            } else {
                return 0;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "error de busquedad" + e.getMessage(), JOptionPane.ERROR_MESSAGE);
            return 0;
        }
    }

}
