/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datos;

import modelo_alojamiento.alojamiento;
import modelo_gerente.gerente;
import modelo_habitaciones.habitacion;
import modelo_incidentes.Incidente;
import modelo_pagos.Pagar;
import modelo_pqrs.Pqrs;
import modelo_recepcionista.Recepcionista;
import modelo_reserva.Reserva;
import modelo_usuario.Usuario;
import modelo_reserva.ReservaDto;

/**
 *
 * @author Marely
 */
public class datosguardados {
    
      private static gerente gerenteActual;
      
      private static Pqrs pqrsactual;
      private static alojamiento alojamientoActual;
      private static habitacion habitacionActual;
      private static Usuario usuarioactual;
      private static Reserva reservaactual;
      private static Incidente incidenteactual;
      private static Recepcionista recepcionistaactual;
      private static Pagar pagaractual;
      private static ReservaDto reserva1;

    public static ReservaDto getReserva1() {
        return reserva1;
    }

    public static void setReserva1(ReservaDto reservaDto) {
         reserva1 = reservaDto;
    }
      

    public static Pagar getPagaractual() {
        return pagaractual;
    }

    public static void setPagaractual(Pagar pagar) {
        pagaractual = pagar;
    }
      

    public static Recepcionista getRecepcionistaactual() {
        return recepcionistaactual;
    }

    public static void setRecepcionistaactual(Recepcionista recepcionista) {
       recepcionistaactual = recepcionista;
    }
      

    public static Incidente getIncidenteactual() {
        return incidenteactual;
    }

    public static void setIncidenteactual(Incidente incidente ) {
        incidenteactual = incidente;
    }
      

    public static Pqrs getPqrsactual() {
        return pqrsactual;
    }

    public static void setPqrsactual(Pqrs pqrs) {
      pqrsactual = pqrs;
    }
      
      

    public static Reserva getReservaactual() {
        return reservaactual;
    }

    public static void setReservaactual(Reserva reserva) {
     reservaactual = reserva;
    }

  

    public static Usuario getUsuarioactual() {
        return usuarioactual;
    }

    public static void setUsuarioactual(Usuario usuario) {
      usuarioactual = usuario;
    }
      

    public static habitacion getHabitacionActual() {
        return habitacionActual;
    }

    public static void setHabitacionActual(habitacion habitacion) {
      habitacionActual = habitacion;
    }
      
      

    public static alojamiento getAlojamientoActual() {
        return alojamientoActual;
    }

    public static void setAlojamientoActual(alojamiento alojamiento) {
        alojamientoActual = alojamiento;
    }
      
      

    public static gerente getGerenteActual() {
        return gerenteActual;
    }

    public static void setGerenteActual(gerente gerente) {
        gerenteActual = gerente;
    }
    
}
