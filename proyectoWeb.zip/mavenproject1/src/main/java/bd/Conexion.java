package bd;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import javax.swing.JOptionPane;
import java.sql.DriverManager;
/**
 *
 * @author Aprendiz
 */
public class Conexion {
    Connection con;
    private String url="jdbc:mysql://localhost:3306/proyecto";
    private String pass="";
    private String user="root";

    public Connection getCon() {
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            
           con=DriverManager.getConnection(url,user,pass);
//           JOptionPane.showMessageDialog(null,"conexion exitosa");
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e.toString(),"base de datos apagada"+ e.getMessage(),JOptionPane.ERROR_MESSAGE);
        }
        return con;
    }
    
    
}
