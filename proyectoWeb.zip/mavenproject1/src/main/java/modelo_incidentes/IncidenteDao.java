/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_incidentes;

import bd.Conexion;
import datos.datosguardados;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import modelo_alojamiento.alojamiento;
import modelo_pqrs.Pqrs;

/**
 *
 * @author Marely
 */
public class IncidenteDao implements crud_incidente {

    Conexion conetion = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    @Override
    public int hacerinforme(Object tr) {
        return 0;
    }

    @Override
    public List lisinformes(int id) {
        List<Incidente> informe = new ArrayList<>();
        String sql = "SELECT \n"
                + "    i.*,\n"
                + "    u.Nombre AS NombreUsuario\n"
                + "FROM \n"
                + "    incidentes i\n"
                + "JOIN \n"
                + "    reservas r ON i.reservaID = r.ReservaID\n"
                + "JOIN \n"
                + "    habitaciones h ON r.HabitacionID = h.HabitacionID\n"
                + "JOIN \n"
                + "    alojamientos a ON h.AlojamientoID = a.AlojamientoID\n"
                + "JOIN \n"
                + "    usuarioregistrado u ON r.UsuarioID = u.UsuarioID\n"
                + "WHERE \n"
                + "    a.AlojamientoID = ?";
        try {

            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();

            while (rs.next()) {

                int id1 = rs.getInt("incidenteID");
                String descripcion = rs.getString("Descripcion");
                String respuesta = rs.getString("respuesta");
                int idalojamiento = rs.getInt("reservaID");
                String nombre = rs.getString("NombreUsuario");

                Incidente informes = new Incidente();
                informes.setNombre(nombre);
                informes.setIncidenteid(id1);
                informes.setDescripcion(descripcion);
                informes.setResponder(respuesta);
                informes.setReservaid(idalojamiento);

                informe.add(informes);
                datosguardados.setIncidenteactual(informes);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString());
        }

        return informe;

    }

    public int responder(Incidente incidente) {
        String sql = "UPDATE incidentes SET respuesta=? WHERE incidenteID=?";
        try {

            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ps.setString(1, incidente.getResponder());
            ps.setInt(2, incidente.getIncidenteid());

            ps.executeUpdate();
            return 1;

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString());
            return 0;
        }
    }

    public int agregarincidente(Incidente incidente) {
        String sql = "INSERT INTO incidentes   (reservaID, Descripcion,respuesta) VALUES (?,?,?)  ";
        try {

            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ps.setInt(1, incidente.getReservaid());
            ps.setString(2, incidente.getDescripcion());
            ps.setString(3, "");
            ps.executeUpdate();
            return 1;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "error de insercion" + e.getMessage(), JOptionPane.ERROR_MESSAGE);
            return 0;
//        }
        }
    }

}
