/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_incidentes;

import java.util.List;

/**
 *
 * @author Marely
 */
public interface crud_incidente<informe> {
    
    public int hacerinforme(informe tr);
    public List<informe> lisinformes(int id);
    
}
