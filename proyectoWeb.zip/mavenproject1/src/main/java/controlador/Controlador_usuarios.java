/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controlador;

import datos.datosguardados;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;
import modelo_usuario.Usuario;
import modelo_usuario.usuarioDao;

/**
 *
 * @author Marely
 */
@WebServlet(name = "Controlador_usuarios", urlPatterns = {"/Controlador_usuarios"})
public class Controlador_usuarios extends HttpServlet {

    Usuario u = new Usuario();
    usuarioDao dao = new usuarioDao();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String menu = request.getParameter("menu");
        String accion = request.getParameter("accion");

        // JOptionPane.showMessageDialog(null, menu);
        // JOptionPane.showMessageDialog(null, accion);
        if (accion == null) {
            accion = "";
        }
        if (menu == null) {
            menu = "";
        }

        if (menu.equals("usuario")) {
            switch (accion) {
                // Caso "modificar":
                case "modificar":
                    // Obtener los parámetros del formulario de perfil
                    String nombre = request.getParameter("nombre");
                    String telefono = request.getParameter("telefono");
                    String correo = request.getParameter("email");
                    String contraseña = request.getParameter("contrase");

                    // Establecer los valores obtenidos en un objeto de usuario (u)
                    u.setContraseña(contraseña);
                    u.setNombre(nombre);
                    u.setTelefono(telefono);
                    u.setCorre(correo);

                    // Llamar al método setmodificarusuari del objeto DAO para actualizar la información del usuario
                    int resultado = dao.setmodificarusuari(u);
                    String aler = "";
                    if (resultado == 1) {
                        // Si la modificación se realiza correctamente, establecer un mensaje de éxito
                        aler = "Se modificó correctamente";

                        // Actualizar el objeto de usuario actual (u) en datosguardados y guardarlo en la sesión
                        u = datosguardados.getUsuarioactual();
                        HttpSession session = request.getSession();
                        session.setAttribute("persona", u);

                    } else {
                        // Si hay un error en la modificación, establecer un mensaje de error
                        aler = "Error en la modificación";
                    }
                    // Establecer el mensaje (aler) como atributo de la solicitud y redirigir a la página de perfil (perfil.jsp)
                    request.setAttribute("aler", aler);
                    request.getRequestDispatcher("perfil.jsp").forward(request, response);
                    break;

// Caso "inhabilitar":
                case "inhabilitar":
                    // Obtener el correo electrónico del usuario a inhabilitar
                    correo = request.getParameter("email");
                    u.setCorre(correo);

                    // Verificar si el usuario existe en la base de datos llamando al método setbuscar1 del objeto DAO
                    resultado = dao.setbuscar1(u);
                    if (resultado == 1) {
                        // Si el usuario existe, mostrar un mensaje de confirmación y llamar al método setinactivarusuari para inhabilitarlo
                        JOptionPane.showMessageDialog(null, "Se va a eliminar el correo: " + correo, "Eliminar Correo", JOptionPane.INFORMATION_MESSAGE);
                        resultado = dao.setinactivarusuari(u);
                        request.getRequestDispatcher("index_admin.jsp").forward(request, response);
                    } else {
                        // Si el usuario no existe, redirigir a una página específica para manejar errores relacionados con la inhabilitación de usuarios
                        request.getRequestDispatcher("inactivar_usuario.jsp").forward(request, response);
                    }
                    break;

            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
