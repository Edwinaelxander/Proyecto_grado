/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;
import modelo_pqrs.Pqrs;
import modelo_pqrs.PqrsDao;

/**
 *
 * @author Marely
 */
@WebServlet(name = "Controlador_pqrs", urlPatterns = {"/Controlador_pqrs"})
public class Controlador_pqrs extends HttpServlet {

    Pqrs pq = new Pqrs();
    PqrsDao dao = new PqrsDao();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String menu = request.getParameter("menu");
        String accion = request.getParameter("accion");

        //JOptionPane.showMessageDialog(null, menu);
        //JOptionPane.showMessageDialog(null, accion);
        if (menu.equals("pqrs")) {
            switch (accion) {
                case "registrar":
                    // Acción: Registrar una nueva PQRS (Petición, Queja, Reclamo o Sugerencia)

                    // Se obtienen los parámetros de la solicitud
                    String tipo = request.getParameter("tipoConsulta");
                    String descripcion = request.getParameter("texto");
                    String id = request.getParameter("idhotel");

                    // Si el ID del hotel es nulo, se establece como una cadena vacía
                    if (id == null) {
                        id = "";
                    }

                    // Se establecen los datos de la PQRS
                    pq.setTipo(tipo);
                    pq.setDescripcion(descripcion);
                    pq.setAlojamiento(id);

                    // Se realiza el registro de la PQRS y se obtiene el resultado
                    int resultado = dao.agregarpqrs(pq);

                    // Se establece un mensaje de alerta según el resultado del registro
                    String aler = "";
                    if (resultado == 1) {
                        aler = "Se registró la PQRS exitosamente";
                    } else {
                        aler = "Error al procesar tu PQRS";
                    }

                    // Se envía el mensaje de alerta como atributo de solicitud y se redirige a la página principal
                    request.setAttribute("aler", aler);
                    request.getRequestDispatcher("index.jsp").forward(request, response);
                    break;

                case "listar":
                    // Acción: Mostrar la lista de PQRS existentes

                    // Se obtienen todas las PQRS desde la base de datos
                    List pqrs = dao.pqrs();

                    // Se establece la lista de PQRS como atributo de solicitud y se redirige a la página de administración de PQRS
                    request.setAttribute("pqrs", pqrs);
                    request.getRequestDispatcher("pqrs_admin.jsp").forward(request, response);
                    break;

                case "responder":
                    // Acción: Responder a una PQRS existente

                    // Se obtiene el ID de la PQRS y la respuesta proporcionada
                    int id1 = Integer.parseInt(request.getParameter("id"));
                    String respuesta = request.getParameter("respuesta");

                    // Se establecen los datos de la respuesta
                    pq.setRespuesta(respuesta);
                    pq.setPqrsid(id1);

                    // Se realiza la respuesta a la PQRS y se obtiene el resultado
                    resultado = dao.responder(pq);

                    // Si la respuesta se realizó correctamente, se muestra un mensaje de éxito
                    if (resultado == 1) {
                        JOptionPane.showMessageDialog(null, "Se respondió correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    }

                    // Se redirige de vuelta a la página de listado de PQRS
                    request.getRequestDispatcher("Controlador_pqrs?menu=pqrs&accion=listar").forward(request, response);
                    break;
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
