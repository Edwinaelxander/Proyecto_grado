/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.text.SimpleDateFormat;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;
import modelo_pagos.Pagar;
import modelo_pagos.PagarDao;

/**
 *
 * @author Marely
 */
@WebServlet(name = "Controlador_pagos", urlPatterns = {"/Controlador_pagos"})
public class Controlador_pagos extends HttpServlet {

    Pagar p = new Pagar();
    PagarDao dao = new PagarDao();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String menu = request.getParameter("menu");
        String accion = request.getParameter("accion");

//        JOptionPane.showMessageDialog(null, menu);
//        JOptionPane.showMessageDialog(null, accion);
        if (accion == null) {
            accion = "";
        }
        if (menu == null) {
            menu = "";
        }

        if (menu.equals("pagos")) {
            switch (accion) {
                case "pagar":
                    // Acción: Procesar el pago de una reserva

                    // Se obtienen los parámetros de la solicitud
                    String nombre = request.getParameter("nombre");
                    String numero = request.getParameter("numero");
                    int mes = Integer.parseInt(request.getParameter("mes"));
                    int cvv = Integer.parseInt(request.getParameter("cvv"));
                    int año = Integer.parseInt(request.getParameter("fecha"));

                    // Se construye la fecha de expedición de la tarjeta de crédito
                    String fechaString = año + "-" + (mes < 10 ? "0" + mes : mes);
                    Date fecha = null;
                    try {
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
                        fecha = sdf.parse(fechaString);
                    } catch (Exception e) {
                        // Manejar cualquier error durante el proceso de conversión de fecha
                    }

                    // Se crea un objeto de tipo java.sql.Date para la fecha de expedición
                    java.sql.Date fecha1 = new java.sql.Date(fecha.getTime());

                    // Se establecen los datos del pago
                    p.setNombre(nombre);
                    p.setNumero_tarjeta(numero);
                    p.setFecha_expedicion(fecha1);
                    p.setCodigo(cvv);

                    // Se realiza el pago y se obtiene el resultado
                    int resultado = dao.hacerpago(p);

                    // Se establece un mensaje de alerta según el resultado del pago
                    String aler = "";
                    if (resultado == 1) {
                        aler = "Pago realizado correctamente";
                    } else {
                        aler = "Error en el pago";
                    }

                    // Se envía el mensaje de alerta como atributo de solicitud y se redirige a la página de confirmación de reserva
                    request.setAttribute("aler", aler);
                    request.getRequestDispatcher("Controlador_reservas?menu=reserva&accion=reservaefectiva").forward(request, response);
                    break;

                case "pagarrecepcionista":
                    // Acción: Procesar el pago de una reserva por parte del recepcionista

                    // Se obtienen los parámetros de la solicitud
                    nombre = request.getParameter("nombre");
                    numero = request.getParameter("numero");
                    mes = Integer.parseInt(request.getParameter("mes"));
                    cvv = Integer.parseInt(request.getParameter("cvv"));
                    año = Integer.parseInt(request.getParameter("fecha"));

                    // Se construye la fecha de expedición de la tarjeta de crédito
                    fechaString = año + "-" + (mes < 10 ? "0" + mes : mes);
                    fecha = null;
                    try {
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
                        fecha = sdf.parse(fechaString);
                    } catch (Exception e) {
                        // Manejar cualquier error durante el proceso de conversión de fecha
                    }

                    // Se crea un objeto de tipo java.sql.Date para la fecha de expedición
                    fecha1 = new java.sql.Date(fecha.getTime());

                    // Se establecen los datos del pago
                    p.setNombre(nombre);
                    p.setNumero_tarjeta(numero);
                    p.setFecha_expedicion(fecha1);
                    p.setCodigo(cvv);

                    // Se realiza el pago y se obtiene el resultado
                    resultado = dao.hacerpago(p);

                    // Se muestra un mensaje según el resultado del pago
                    if (resultado == 1) {
                        JOptionPane.showMessageDialog(null, "Pago realizado correctamente");
                    } else {
                        JOptionPane.showMessageDialog(null, "Error en el pago", "Error", JOptionPane.ERROR_MESSAGE);
                    }

                    // Se redirige a la página de confirmación de reserva para el recepcionista
                    request.getRequestDispatcher("Controlador_reservas?menu=reserva&accion=reservalocal").forward(request, response);
                    break;
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
