/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controlador;

import datos.datosguardados;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;
import modelo_alojamiento.alojamiento;
import modelo_incidentes.Incidente;
import modelo_incidentes.IncidenteDao;
import modelo_recepcionista.Recepcionista;

/**
 *
 * @author Marely
 */
@WebServlet(name = "Controlador_incidentes", urlPatterns = {"/Controlador_incidentes"})
public class Controlador_incidentes extends HttpServlet {

    Incidente i = new Incidente();
    IncidenteDao dao = new IncidenteDao();
    int id = 0;

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String menu = request.getParameter("menu");
        String accion = request.getParameter("accion");

        //JOptionPane.showMessageDialog(null, menu);
        // JOptionPane.showMessageDialog(null, accion);
        if (accion == null) {
            accion = "";
        }
        if (menu == null) {
            menu = "";
        }

        if (menu.equals("incidentes")) {
            switch (accion) {
                case "listar":
                    // Acción: Listar incidentes para el gerente

                    // Se obtiene el ID del alojamiento desde la solicitud
                     id = Integer.parseInt(request.getParameter("id"));

                    // Se obtienen los incidentes asociados al alojamiento desde la base de datos
                    List<Incidente> incidentes = dao.lisinformes(id);

                    // Se establecen los incidentes como atributo en la solicitud
                    request.setAttribute("incidentes", incidentes);

                    // Se redirige a la página de visualización de incidentes para el administrador
                    request.getRequestDispatcher("vistas_gerente/incidentes_admin.jsp").forward(request, response);
                    break;

                case "listar1":
                    // Acción: Listar incidentes para el recepcionista

                    // Se obtiene el alojamiento actual desde los datos guardados
                    alojamiento r = datosguardados.getAlojamientoActual();
                    id = r.getId();

                    // Se obtienen los incidentes asociados al alojamiento desde la base de datos
                    incidentes = dao.lisinformes(id);

                    // Se establecen los incidentes como atributo en la solicitud
                    request.setAttribute("incidentes", incidentes);

                    // Se redirige a la página de visualización de incidentes para el recepcionista
                    request.getRequestDispatcher("incidentes_recepcionista.jsp").forward(request, response);
                    break;

                case "responder":
                    // Acción: Responder a un incidente

                    // Se obtienen los parámetros de la solicitud
                    int id1 = Integer.parseInt(request.getParameter("id"));
                    String respuesta = request.getParameter("respuesta");

                    // Se establecen los datos de la respuesta
                    i.setResponder(respuesta);
                    i.setIncidenteid(id1);

                    // Se realiza la respuesta en la base de datos
                    int resultado = dao.responder(i);

                    // Se muestra un mensaje según el resultado de la respuesta
                    if (resultado == 1) {
                        JOptionPane.showMessageDialog(null, "Se modificó correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Error en la inserción", "Error", JOptionPane.ERROR_MESSAGE);
                    }

                    // Se redirige de vuelta a la página de listado de incidentes
                    request.getRequestDispatcher("Controlador_incidentes?menu=incidentes&accion=listar&id=" + id).forward(request, response);
                    break;

                case "registrar":
                    // Acción: Registrar un nuevo incidente

                    // Se obtienen los parámetros de la solicitud
                    String descripcion = request.getParameter("descripcion");
                    id = Integer.parseInt(request.getParameter("id"));

                    // Se establecen los datos del incidente
                    i.setDescripcion(descripcion);
                    i.setReservaid(id);

                    // Se agrega el incidente a la base de datos
                    resultado = dao.agregarincidente(i);
                    String aler = "";
                    if (resultado == 1) {
                        aler = "Se informó su incidente correctamente";
                    } else {
                        aler = "Error al registrar su incidente";
                    }

                    // Se establece un mensaje de alerta como atributo en la solicitud
                    request.setAttribute("aler", aler);

                    // Se redirige de vuelta a la página de finalización de reserva
                    request.getRequestDispatcher("Controlador_reservas?menu=reserva&accion=reservaterminada").forward(request, response);
                    break;
            }

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
