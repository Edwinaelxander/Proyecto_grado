/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controlador;

import datos.datosguardados;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;
import modelo_usuario.Usuario;
import modelo_usuario.usuarioDao;
import javax.swing.JOptionPane;
import modelo.admin.Administrador;
import modelo.admin.AdministradorDao;
import modelo_gerente.gerente;
import modelo_gerente.gerenteDao;
import modelo_recepcionista.Recepcionista;
import modelo_recepcionista.RecepcionistaDao;

/**
 *
 * @author Marely
 */
@WebServlet(name = "Controlador_inicio_sesion", urlPatterns = {"/Controlador_inicio_sesion"})
public class Controlador_inicio_sesion extends HttpServlet {

    private Usuario t = new Usuario();
    private usuarioDao dao = new usuarioDao();
    private Administrador tadmin = new Administrador();
    private AdministradorDao daoadmin = new AdministradorDao();

    private gerente tgerente = new gerente();
    private gerenteDao daogerente = new gerenteDao();

    private Recepcionista trecep = new Recepcionista();
    private RecepcionistaDao daorecep = new RecepcionistaDao();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String accion = request.getParameter("btningresar");

        if (accion == null) {
            accion = "";
        }

        if (accion.equalsIgnoreCase("Ingresar")) {
            // Acción: Iniciar sesión

            // Se obtienen los parámetros de la solicitud
            String email = request.getParameter("email");
            String pass = request.getParameter("password");

            // Se establecen los datos de inicio de sesión para diferentes tipos de usuarios
            t.setCorre(email);
            t.setContraseña(pass);
            tadmin.setCorreo(email);
            tadmin.setContraseña(pass);
            tgerente.setCorre(email);
            tgerente.setContraseña(pass);
            trecep.setCorreo(email);
            trecep.setContraseña(pass);

            // Se realizan búsquedas en la base de datos para verificar las credenciales
            int resultado = dao.setbuscar(t);
            int resultado2 = daoadmin.buscar(tadmin);
            int resultado3 = daogerente.setbuscar(tgerente);
            int resultado4 = daorecep.iniciarsesionrecepcionista(trecep);

            // Se maneja el resultado de la búsqueda y se redirige según el tipo de usuario
            if (resultado == 1) {
                // Si es un usuario regular, se inicia sesión y se redirige a la página de inicio
                HttpSession session = request.getSession();
                Usuario actual = datosguardados.getUsuarioactual();
                session.setAttribute("persona", actual);
                request.getRequestDispatcher("index.jsp").forward(request, response);
            } else if (resultado2 == 1) {
                // Si es un administrador, se inicia sesión y se redirige a la página de inicio de administrador
                HttpSession session = request.getSession();
                session.setAttribute("persona2", tadmin);
                request.getRequestDispatcher("index_admin.jsp").forward(request, response);
            } else if (resultado3 == 1) {
                // Si es un gerente, se inicia sesión y se redirige a la página de inicio de gerente
                HttpSession session = request.getSession();
                session.setAttribute("persona3", tgerente);
                request.getRequestDispatcher("vistas_gerente/principal_gerente.jsp").forward(request, response);
            } else if (resultado4 == 1) {
                // Si es un recepcionista, se inicia sesión y se redirige a la página de gestión de habitaciones
                HttpSession session = request.getSession();
                Recepcionista ractual = datosguardados.getRecepcionistaactual();
                session.setAttribute("recepcionista", ractual);
                request.getRequestDispatcher("Controlador_habitaciones?menu=habitaciones&accion=reservarecepcionista").forward(request, response);
            } else {
                // Si las credenciales son incorrectas, se muestra un mensaje de alerta y se redirige a la página de inicio de sesión
                String aler = "Credenciales incorrectas";
                request.setAttribute("aler", aler);
                request.getRequestDispatcher("inicio_de_sesion.jsp").forward(request, response);
            }
        }

        if (accion.equals("registrarse")) {
            // Acción: Registrar un nuevo usuario

            // Se obtienen los parámetros de la solicitud
            String nombre = request.getParameter("nombre");
            int cedula = Integer.parseInt(request.getParameter("cedula"));
            String telefono = request.getParameter("telefono");
            String correo = request.getParameter("email");
            String contraseña = request.getParameter("contrase");

            // Se establecen los datos del nuevo usuario
            t.setNombre(nombre);
            t.setCorre(correo);
            t.setCedula(cedula);
            t.setTelefono(telefono);
            t.setContraseña(contraseña);

            // Se realiza el registro del nuevo usuario en la base de datos
            int resultado = dao.setagregarusuari(t);

            // Se muestra un mensaje de alerta según el resultado del registro
            if (resultado == 1) {
                // Si el registro es exitoso, se redirige a la página de inicio
                request.getRequestDispatcher("index.jsp").forward(request, response);
            } else if (resultado == 3) {
                // Si el usuario ya está registrado, se muestra un mensaje de error y se redirige a la página de registro
                String a = "Usuario ya registrado";
                request.setAttribute("mensaje", a);
                request.getRequestDispatcher("registro_usuario.jsp").forward(request, response);
            } else {
                // Si hay algún error durante el registro, se redirige a la página de registro
                request.getRequestDispatcher("registro_usuario.jsp").forward(request, response);
            }
        }

        if (accion.equals("cerrar")) {
            // Acción: Cerrar sesión

            // Se invalida la sesión actual para cerrar sesión
            HttpSession session = request.getSession();
            session.invalidate();

            // Se redirige a la página de inicio
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
