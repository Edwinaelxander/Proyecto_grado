/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controlador;

import datos.datosguardados;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;
import modelo_alojamiento.alojamiento;
import modelo_habitaciones.habitacion;
import modelo_pagos.Pagar;
import modelo_reserva.Reserva;
import modelo_reserva.ReservaDao;
import modelo_usuario.Usuario;

/**
 *
 * @author Marely
 */
@WebServlet(name = "Controlador_reservas", urlPatterns = {"/Controlador_reservas"})
public class Controlador_reservas extends HttpServlet {

    private int num;
    Reserva r = new Reserva();
    ReservaDao dao = new ReservaDao();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String menu = request.getParameter("menu");
        String accion = request.getParameter("accion");

        // JOptionPane.showMessageDialog(null, menu);
        // JOptionPane.showMessageDialog(null, accion);
        if (accion == null) {
            accion = "";
        }
        if (menu == null) {
            menu = "";
        }

        if (menu.equals("reserva")) {
            switch (accion) {
                case "reservar":
                    // Acción: Realizar una reserva

                    // Se obtienen los datos de la reserva desde la solicitud
                    int habitacionid = Integer.parseInt(request.getParameter("habitacion_id"));
                    int habitaciones = Integer.parseInt(request.getParameter("cantidad_habitaciones").trim());
                    float precio1 = Float.parseFloat(request.getParameter("precio").trim());
                    SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
                    String fechaentrada1 = request.getParameter("fecha_entrada");
                    String fechaSalidad1 = request.getParameter("fecha_salida");
                    Date fechaEntrada = null,
                     fechaSalida = null;
                    try {
                        fechaEntrada = dateFormat.parse(fechaentrada1);
                        fechaSalida = dateFormat.parse(fechaSalidad1);
                    } catch (Exception e) {
                    }

                    java.sql.Date fechaentra = new java.sql.Date(fechaEntrada.getTime());
                    java.sql.Date fechasale = new java.sql.Date(fechaSalida.getTime());
                    float valor = precio1;

                    Calendar calSalida = Calendar.getInstance();
                    calSalida.setTime(fechasale);
                    Calendar calEntrada = Calendar.getInstance();
                    calEntrada.setTime(fechaentra);
                    long diferenciaMillis = calSalida.getTimeInMillis() - calEntrada.getTimeInMillis();
                    long diasDiferencia = diferenciaMillis / (1000 * 60 * 60 * 24);
                    double pagar = valor * habitaciones * diasDiferencia;

                    Pagar p = new Pagar();
                    p.setValorpagar(pagar);
                    datosguardados.setPagaractual(p);

                    int num = habitaciones;
                    r.setFechaentrada(fechaentra);
                    r.setFechasalida(fechasale);
                    r.setC_habitaciones(habitaciones);

                    // Se realiza la reserva para cada habitación
                    int resultado = 3;
                    int[] idsReserva = new int[num];
                    for (int i = 0; i < num; i++) {
                        resultado = dao.agregarreserva(r);

                        // Se obtiene el ID de la reserva actual
                        Reserva reservaActual = datosguardados.getReservaactual();
                        int idReserva = reservaActual.getIdreserva();
                        idsReserva[i] = idReserva;
                        p.setIdreserva(idsReserva);
                    }

                    // Se muestra un mensaje según el resultado de la reserva
                    if (resultado == 1) {
                        String aler = "Reserva insertada correctamente";
                        String aler1 = " " + pagar;
                        request.setAttribute("aler1", aler1);
                        request.setAttribute("aler", aler);
                    } else {
                        String aler = "Error de reserva";
                        request.setAttribute("aler", aler);
                        request.getRequestDispatcher("index.jsp").forward(request, response);
                    }
                    request.getRequestDispatcher("pagar.jsp").forward(request, response);
                    break;

                case "reservaactiva":
                    // Acción: Mostrar todas las reservas activas

                    // Se obtienen las reservas activas desde la base de datos
                    List reservaactiva = dao.reserva(1);

                    // Se establece la lista de reservas activas como atributo de solicitud y se redirige a la página correspondiente
                    request.setAttribute("reservaactiva", reservaactiva);
                    request.getRequestDispatcher("reservas_activas.jsp").forward(request, response);
                    break;

                case "reservaefectiva":
                    // Acción: Mostrar todas las reservas efectivas

                    // Se obtienen las reservas efectivas desde la base de datos
                    List reservaefectiva = dao.reserva(2);

                    // Se establece la lista de reservas efectivas como atributo de solicitud y se redirige a la página correspondiente
                    request.setAttribute("reservaactiva", reservaefectiva);
                    String aler = (String) request.getAttribute("aler1");
                    if (aler != null) {
                        request.setAttribute("aler", aler);
                    }
                    request.getRequestDispatcher("reservas_efectivas.jsp").forward(request, response);
                    break;

                case "reservaterminada":
                    // Acción: Mostrar todas las reservas terminadas

                    // Se obtienen las reservas terminadas desde la base de datos
                    List reservaterminada = dao.reserva(3);

                    // Se establece la lista de reservas terminadas como atributo de solicitud y se redirige a la página correspondiente
                    request.setAttribute("reservaactiva", reservaterminada);
                    request.getRequestDispatcher("reserva_terminada.jsp").forward(request, response);
                    break;

                case "informacion":
                    // Acción: Mostrar información detallada de una reserva

                    // Se obtienen los parámetros de la solicitud
                    String ab = request.getParameter("a");
                    int id = Integer.parseInt(request.getParameter("id"));
                    alojamiento a = new alojamiento();
                    habitacion t = new habitacion();

                    // Se obtiene información detallada de la reserva desde la base de datos
                    resultado = dao.detallereserva(r, a, t, id);

                    // Se establecen los atributos de solicitud y se redirige a la página correspondiente
                    request.setAttribute("menu", ab);
                    request.setAttribute("alojamiento", a);
                    request.setAttribute("habitacion", t);
                    request.setAttribute("reserva", r);

                    id = r.getIdreserva();
                    int[] ids = new int[]{id};

                    p = new Pagar();
                    p.setIdreserva(ids);
                    p.setValorpagar(t.getPrecio());
                    datosguardados.setPagaractual(p);
                    request.getRequestDispatcher("detalles_reserva.jsp").forward(request, response);
                    break;

                case "inhabilitar":
                    // Acción: Inhabilitar una reserva

                    // Se modifica el estado de la reserva para indicar que está inhabilitada
                    resultado = dao.modificarestadoreserva(1);

                    // Se muestra un mensaje según el resultado de la operación
                    if (resultado == 1) {
                        JOptionPane.showMessageDialog(null, "se inhbilito correctamente");
                    }
                    request.getRequestDispatcher("Controlador_reservas?menu=reserva&accion=reservaefectiva").forward(request, response);
                    break;

                case "modificar":
                    // Acción: Modificar una reserva

                    // Se obtienen los parámetros de la solicitud
                    String f_entrada = request.getParameter("f_entrada");
                    String f_salida = request.getParameter("f_salidad");

                    // Se parsean las fechas
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    try {
                        Date fecha_entrada = sdf.parse(f_entrada);
                        Date fecha_salida = sdf.parse(f_salida);

                        // Se convierten las fechas al tipo java.sql.Date
                        java.sql.Date sql_fecha_entrada = new java.sql.Date(fecha_entrada.getTime());
                        java.sql.Date sql_fecha_salida = new java.sql.Date(fecha_salida.getTime());

                        // Se establecen las fechas en el objeto de reserva
                        r.setFechaentrada(sql_fecha_entrada);
                        r.setFechasalida(sql_fecha_salida);

                    } catch (Exception e) {
                        JOptionPane.showConfirmDialog(null, e.toString());
                    }

                    // Se modifica la reserva en la base de datos
                    aler = "";
                    resultado = dao.modificarreserva(r);

                    // Se muestra un mensaje según el resultado de la operación
                    if (resultado == 1) {
                        aler = "se modifico correctamente";
                    } else {
                        aler = "Error de modificacion";
                    }
                    request.setAttribute("aler1", aler);
                    request.getRequestDispatcher("Controlador_reservas?menu=reserva&accion=reservaefectiva").forward(request, response);
                    break;

                case "reservarrecepcionista":
                    // Acción: Realizar una reserva desde el rol de recepcionista

                    // Se obtienen los parámetros de la solicitud
                    habitacionid = Integer.parseInt(request.getParameter("habitacion_id"));
                    habitaciones = Integer.parseInt(request.getParameter("cantidad_habitaciones").trim());
                    precio1 = Float.parseFloat(request.getParameter("precio").trim());
                    dateFormat = new SimpleDateFormat("MM-dd-yyyy");
                    fechaentrada1 = request.getParameter("fecha_entrada");
                    fechaSalidad1 = request.getParameter("fecha_salida");
                    fechaEntrada = null;

                    fechaSalida = null;
                    try {
                        fechaEntrada = dateFormat.parse(fechaentrada1);
                        fechaSalida = dateFormat.parse(fechaSalidad1);
                    } catch (Exception e) {
                    }

                    fechaentra = new java.sql.Date(fechaEntrada.getTime());
                    fechasale = new java.sql.Date(fechaSalida.getTime());
                    valor = precio1;

                    calSalida = Calendar.getInstance();
                    calSalida.setTime(fechasale);

                    calEntrada = Calendar.getInstance();
                    calEntrada.setTime(fechaentra);

                    diferenciaMillis = calSalida.getTimeInMillis() - calEntrada.getTimeInMillis();
                    diasDiferencia = diferenciaMillis / (1000 * 60 * 60 * 24);
                    pagar = valor * habitaciones * diasDiferencia;

                    p = new Pagar();
                    p.setValorpagar(pagar);
                    datosguardados.setPagaractual(p);

                    num = habitaciones;
                    r.setFechaentrada(fechaentra);
                    r.setFechasalida(fechasale);
                    r.setC_habitaciones(habitaciones);

                    // Se realiza la reserva para cada habitación
                    resultado = 3;
                    idsReserva = new int[num];
                    for (int i = 0; i < num; i++) {
                        resultado = dao.reservarecepcionista(r);

                        // Se obtiene el ID de la reserva actual
                        Reserva reservaActual = datosguardados.getReservaactual();
                        Pagar pa = new Pagar();

                        int idReserva = reservaActual.getIdreserva();
                        idsReserva[i] = idReserva;
                        pa.setIdreserva(idsReserva);
                    }

                    // Se muestra un mensaje según el resultado de la reserva
                    if (resultado == 1) {
                        aler = "Reserva insertada correctamente";
                        String aler1 = "" + pagar;
                        request.setAttribute("aler1", aler1);
                        request.setAttribute("aler", aler);
                    } else {
                        aler = "Error de reserva";
                        request.setAttribute("aler", aler);
                        request.getRequestDispatcher("principal_recepcionista.jsp").forward(request, response);
                    }
                    request.getRequestDispatcher("pagar_recepcionista.jsp").forward(request, response);
                    break;

                case "online":
                    // Acción: Mostrar todas las reservas virtuales

                    // Se obtienen las reservas virtuales desde la base de datos
                    List listareservavirtuales = dao.reservasVirtuales();

                    // Se establece la lista de reservas virtuales como atributo de solicitud y se redirige a la página correspondiente
                    request.setAttribute("listareservavirtuales", listareservavirtuales);
                    request.getRequestDispatcher("reservavirtuales.jsp").forward(request, response);
                    break;

                case "local":
                    // Acción: Mostrar todas las reservas presenciales

                    // Se obtienen las reservas presenciales desde la base de datos
                    List listareservalocal = dao.reservaspresenciales(1);

                    // Se establece la lista de reservas presenciales como atributo de solicitud y se redirige a la página correspondiente
                    request.setAttribute("listareservalocal", listareservalocal);
                    request.getRequestDispatcher("reservalocal.jsp").forward(request, response);
                    break;

                case "activa":
                    // Acción: Mostrar todas las reservas activas

                    // Se obtienen las reservas activas desde la base de datos
                    List listareservaactiva = dao.reservaspresenciales(2);

                    // Se establece la lista de reservas activas como atributo de solicitud y se redirige a la página correspondiente
                    request.setAttribute("listareservaactiva", listareservaactiva);
                    request.getRequestDispatcher("reservaactiva.jsp").forward(request, response);
                    break;

                case "terminada":
                    // Acción: Mostrar todas las reservas terminadas

                    // Se obtienen las reservas terminadas desde la base de datos
                    List listareservaterminada = dao.reservaspresenciales(3);

                    // Se establece la lista de reservas terminadas como atributo de solicitud y se redirige a la página correspondiente
                    request.setAttribute("listareservaterminada", listareservaterminada);
                    request.getRequestDispatcher("reservaterminada.jsp").forward(request, response);
                    break;

                case "checkin":
                    // Acción: Realizar el check-in de una reserva

                    // Se obtiene el ID de la reserva desde la solicitud
                    id = Integer.parseInt(request.getParameter("id"));

                    // Se modifica el estado de la reserva para indicar que está en proceso de check-in
                    resultado = dao.modificarestadoreserva(2);

                    // Se muestra un mensaje según el resultado de la operación
                    if (resultado == 1) {
                        JOptionPane.showMessageDialog(null, "check-in correctamente");
                    }
                    request.getRequestDispatcher("Controlador_reservas?menu=reserva&accion=activa").forward(request, response);
                    break;

                case "checkout":
                    // Acción: Realizar el check-out de una reserva

                    // Se obtiene el ID de la reserva desde la solicitud
                    id = Integer.parseInt(request.getParameter("id"));

                    // Se modifica el estado de la reserva para indicar que está en proceso de check-out
                    resultado = dao.modificarestadoreserva(3);

                    // Se muestra un mensaje según el resultado de la operación
                    if (resultado == 1) {
                        JOptionPane.showMessageDialog(null, "check-out correctamente");
                    }
                    request.getRequestDispatcher("Controlador_reservas?menu=reserva&accion=activa").forward(request, response);
                    break;

            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
