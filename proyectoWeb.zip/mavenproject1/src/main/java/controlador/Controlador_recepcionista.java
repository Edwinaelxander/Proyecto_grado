/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;
import modelo_recepcionista.Recepcionista;
import modelo_recepcionista.RecepcionistaDao;

/**
 *
 * @author Marely
 */
@WebServlet(name = "Controlador_recepcionista", urlPatterns = {"/Controlador_recepcionista"})
public class Controlador_recepcionista extends HttpServlet {

    Recepcionista r = new Recepcionista();
    RecepcionistaDao dao = new RecepcionistaDao();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String menu = request.getParameter("menu");
        String accion = request.getParameter("accion");
        //  JOptionPane.showMessageDialog(null, menu);
        // JOptionPane.showMessageDialog(null, accion);
        if (accion == null) {
            accion = "";
        }
        if (menu == null) {
            menu = "";
        }

        if (menu.equals("recepcionista")) {
            switch (accion) {
                case "listar":
                    // Acción: Listar todos los recepcionistas

                    // Se obtienen todos los recepcionistas desde la base de datos
                    List recepcionistas = dao.recepcionistas();

                    // Se establece la lista de recepcionistas como atributo de solicitud y se redirige a la página de administración de recepcionistas
                    request.setAttribute("recepcionista", recepcionistas);
                    request.getRequestDispatcher("vistas_gerente/recepcionistas_gerente.jsp").forward(request, response);
                    break;

                case "editar":
                    // Acción: Mostrar formulario de edición de un recepcionista

                    // Se obtiene el ID del recepcionista a editar
                    int id = Integer.parseInt(request.getParameter("id"));

                    // Se busca el recepcionista por su ID
                    Recepcionista r = dao.recepcionistaid(id);

                    // Se establece el recepcionista como atributo de solicitud y se redirige al formulario de listado de recepcionistas
                    request.setAttribute("r", r);
                    request.getRequestDispatcher("Controlador_recepcionista?menu=recepcionista&accion=listar").forward(request, response);
                    break;

                case "modificar":
                    // Acción: Modificar los datos de un recepcionista

                    // Se obtienen los datos modificados del recepcionista desde la solicitud
                    id = Integer.parseInt(request.getParameter("id"));
                    String email = request.getParameter("email");
                    String contraseña = request.getParameter("cont");
                    String telefono = request.getParameter("telefono");

                    // Se establecen los nuevos datos del recepcionista
                    this.r.setContraseña(contraseña);
                    this.r.setCorreo(email);
                    this.r.setTelefono(telefono);
                    this.r.setRecepcionistaid(id);

                    // Se realiza la modificación del recepcionista y se obtiene el resultado
                    int resultado = dao.modificarrecepcionista(this.r);

                    // Si la modificación se realizó correctamente, se muestra un mensaje de éxito
                    if (resultado == 1) {
                        JOptionPane.showMessageDialog(null, "Se modificó correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                        request.getRequestDispatcher("Controlador_recepcionista?menu=recepcionista&accion=listar").forward(request, response);
                    } else {
                        JOptionPane.showMessageDialog(null, "Error en la inserción", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    break;

                case "registrar":
                    // Acción: Registrar un nuevo recepcionista

                    // Se obtienen los datos del nuevo recepcionista desde la solicitud
                    String nom = request.getParameter("nombre");
                    int cedula = Integer.parseInt(request.getParameter("cedula"));
                    email = request.getParameter("email");
                    contraseña = request.getParameter("cont");
                    telefono = request.getParameter("telefono");

                    // Se establecen los datos del nuevo recepcionista
                    this.r.setContraseña(contraseña);
                    this.r.setCorreo(email);
                    this.r.setTelefono(telefono);
                    this.r.setNombre(nom);
                    this.r.setCedula(cedula);

                    // Se realiza el registro del nuevo recepcionista y se obtiene el resultado
                    resultado = dao.agregarrecepcionista(this.r);

                    // Se muestra un mensaje según el resultado del registro
                    if (resultado == 1) {
                        JOptionPane.showMessageDialog(null, "Se insertó correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                        request.getRequestDispatcher("Controlador_recepcionista?menu=recepcionista&accion=listar").forward(request, response);
                    } else if (resultado == 3) {
                        JOptionPane.showMessageDialog(null, "Recepcionista ya está registrado", "Error", JOptionPane.ERROR_MESSAGE);
                        request.getRequestDispatcher("Controlador_recepcionista?menu=recepcionista&accion=listar").forward(request, response);
                    } else {
                        JOptionPane.showMessageDialog(null, "Error en la inserción", "Error", JOptionPane.ERROR_MESSAGE);
                        request.getRequestDispatcher("Controlador_recepcionista?menu=recepcionista&accion=listar").forward(request, response);
                    }
                    break;

                case "eliminar":
                    // Acción: Inhabilitar un recepcionista

                    // Se obtiene el ID del recepcionista a inhabilitar
                    id = Integer.parseInt(request.getParameter("id"));

                    // Se establece el ID del recepcionista
                    this.r.setRecepcionistaid(id);

                    // Se realiza la inhabilitación del recepcionista y se obtiene el resultado
                    resultado = dao.inhabilitarrecepcionista(this.r);

                    // Se muestra un mensaje según el resultado de la inhabilitación
                    if (resultado == 1) {
                        JOptionPane.showMessageDialog(null, "Se inhabilitó correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                        request.getRequestDispatcher("Controlador_recepcionista?menu=recepcionista&accion=listar").forward(request, response);
                    } else {
                        JOptionPane.showMessageDialog(null, "Error en la inhabilitación", "Error", JOptionPane.ERROR_MESSAGE);
                        request.getRequestDispatcher("Controlador_recepcionista?menu=recepcionista&accion=listar").forward(request, response);
                    }
                    break;

            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
