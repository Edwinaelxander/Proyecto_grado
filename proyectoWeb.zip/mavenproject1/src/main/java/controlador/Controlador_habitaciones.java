/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controlador;

import datos.datosguardados;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;
import modelo_alojamiento.alojamiento;
import modelo_alojamiento.alojamientoDao;
import modelo_habitaciones.habitacion;
import modelo_habitaciones.habitacionDao;

/**
 *
 * @author Marely
 */
@WebServlet(name = "Controlador_habitaciones", urlPatterns = {"/Controlador_habitaciones"})
public class Controlador_habitaciones extends HttpServlet {

    public habitacion hab = new habitacion();
    habitacionDao dao = new habitacionDao();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String menu = request.getParameter("menu");
        String accion = request.getParameter("accion");
//       JOptionPane.showMessageDialog(null, menu);
//           JOptionPane.showMessageDialog(null, accion);
        if (accion == null) {
            accion = "";
        }
        if (menu == null) {
            menu = "";
        }

        if (menu.equals("habitaciones")) {
            switch (accion) {
                case "detalles":
                    // Acción: Mostrar detalles de un alojamiento específico

                    // Se obtiene el ID del alojamiento desde los parámetros de la solicitud
                    int id = Integer.parseInt(request.getParameter("id"));

                    // Se busca el alojamiento en la base de datos según su ID
                    alojamientoDao dao1 = new alojamientoDao();
                    alojamiento alo = dao1.buscarid(id);

                    // Se establece el objeto alojamiento en el atributo de solicitud para enviarlo a la página JSP
                    request.setAttribute("alojamiento", alo);

                    // Se obtienen todas las habitaciones disponibles
                    List habitaciones = dao.habitaciones();

                    // Se establece la lista de habitaciones en el atributo de solicitud para enviarla a la página JSP
                    request.setAttribute("habitaciones", habitaciones);

                    // Se redirige a la página JSP para mostrar los detalles del alojamiento
                    request.getRequestDispatcher("detalles_hotel.jsp").forward(request, response);
                    break;

                case "listar":
                    // Acción: Mostrar todas las habitaciones disponibles (para el rol de gerente)

                    // Se obtienen todas las habitaciones disponibles
                    habitaciones = dao.habitaciones();

                    // Se establece la lista de habitaciones en el atributo de solicitud para enviarla a la página JSP
                    request.setAttribute("habitaciones", habitaciones);

                    // Se redirige a la página JSP para mostrar todas las habitaciones disponibles
                    request.getRequestDispatcher("vistas_gerente/habitaciones_gerente.jsp").forward(request, response);
                    break;

                case "listar1":
                    // Acción: Mostrar todas las habitaciones disponibles (para el rol de recepcionista)

                    // Se obtienen todas las habitaciones disponibles
                    habitaciones = dao.habitaciones();

                    // Se establece la lista de habitaciones en el atributo de solicitud para enviarla a la página JSP
                    request.setAttribute("habitaciones", habitaciones);

                    // Se redirige a la página JSP para mostrar todas las habitaciones disponibles
                    request.getRequestDispatcher("habitaciones_recepcionista.jsp").forward(request, response);
                    break;

                case "editar":
                    // Acción: Editar una habitación específica (para el rol de gerente)

                    // Se obtiene el ID de la habitación desde los parámetros de la solicitud
                    id = Integer.parseInt(request.getParameter("id"));

                    // Se busca la habitación en la base de datos según su ID
                    habitacion a = dao.habitacionesid(id);

                    // Se establece la habitación en el atributo de solicitud para enviarla a la página JSP de listado de habitaciones del gerente
                    request.setAttribute("a", a);

                    // Se redirige a la página JSP de listado de habitaciones del gerente para mostrar la habitación que se va a editar
                    request.getRequestDispatcher("Controlador_habitaciones?menu=habitaciones&accion=listar").forward(request, response);
                    break;

                case "editar1":
                    // Acción: Editar una habitación específica (para el rol de recepcionista)

                    // Se obtiene el ID de la habitación desde los parámetros de la solicitud
                    id = Integer.parseInt(request.getParameter("id"));

                    // Se busca la habitación en la base de datos según su ID
                    a = dao.habitacionesid(id);

                    // Se establece la habitación en el atributo de solicitud para enviarla a la página JSP de listado de habitaciones del recepcionista
                    request.setAttribute("a", a);

                    // Se redirige a la página JSP de listado de habitaciones del recepcionista para mostrar la habitación que se va a editar
                    request.getRequestDispatcher("Controlador_habitaciones?menu=habitaciones&accion=listar1").forward(request, response);
                    break;
                case "modificar":
                    // Acción: Modificar una habitación (para el rol de gerente)

                    // Se obtienen los parámetros de la solicitud
                    String tipo = request.getParameter("tipo");
                    int cantidad = Integer.parseInt(request.getParameter("cantidad"));
                    float precio = Float.parseFloat(request.getParameter("precio"));
                    String servicios = request.getParameter("servicios");
                    int cantidad_habitaciones = Integer.parseInt(request.getParameter("cantidad_habitaciones"));
                    id = Integer.parseInt(request.getParameter("id"));

                    // Se establecen los valores de la habitación a modificar
                    hab.setTipo(tipo);
                    hab.setCantidad(cantidad);
                    hab.setPrecio(precio);
                    hab.setServicios(servicios);
                    hab.setCantidad_habitaciones(cantidad_habitaciones);
                    hab.setHabitacionid(id);

                    // Se realiza la modificación en la base de datos
                    int resultado = dao.modificarhabitacion(hab);

                    // Se muestra un mensaje según el resultado de la modificación
                    if (resultado == 1) {
                        JOptionPane.showMessageDialog(null, "Se modificó correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Error en la modificación", "Error", JOptionPane.ERROR_MESSAGE);
                    }

                    // Se redirige de vuelta al listado de habitaciones del gerente
                    request.getRequestDispatcher("Controlador_habitaciones?menu=habitaciones&accion=listar").forward(request, response);
                    break;

                case "modificar1":
                    // Acción: Modificar una habitación (para el rol de recepcionista)

                    // Se obtienen los parámetros de la solicitud
                    tipo = request.getParameter("tipo");
                    cantidad = Integer.parseInt(request.getParameter("cantidad"));
                    precio = Float.parseFloat(request.getParameter("precio"));
                    servicios = request.getParameter("servicios");
                    cantidad_habitaciones = Integer.parseInt(request.getParameter("cantidad_habitaciones"));
                    id = Integer.parseInt(request.getParameter("id"));

                    // Se establecen los valores de la habitación a modificar
                    hab.setTipo(tipo);
                    hab.setCantidad(cantidad);
                    hab.setPrecio(precio);
                    hab.setServicios(servicios);
                    hab.setCantidad_habitaciones(cantidad_habitaciones);
                    hab.setHabitacionid(id);

                    // Se realiza la modificación en la base de datos
                    int resultado1 = dao.modificarhabitacion(hab);

                    // Se muestra un mensaje según el resultado de la modificación
                    if (resultado1 == 1) {
                        // Aquí se podría mostrar un mensaje de éxito si se desea
                    } else {
                        JOptionPane.showMessageDialog(null, "Error en la modificación", "Error", JOptionPane.ERROR_MESSAGE);
                    }

                    // Se redirige de vuelta al listado de habitaciones del recepcionista
                    request.getRequestDispatcher("Controlador_habitaciones?menu=habitaciones&accion=listar1").forward(request, response);
                    break;

                case "eliminar":
                    // Acción: Inhabilitar una habitación (para el rol de gerente)

                    // Se obtiene el ID de la habitación desde los parámetros de la solicitud
                    id = Integer.parseInt(request.getParameter("id"));
                    hab.setHabitacionid(id);

                    // Se realiza la inhabilitación en la base de datos
                    resultado = dao.inactivar(hab);

                    // Se muestra un mensaje según el resultado de la inhabilitación
                    if (resultado == 1) {
                        JOptionPane.showMessageDialog(null, "Se inhabilitó correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Error en la inhabilitación", "Error", JOptionPane.ERROR_MESSAGE);
                    }

                    // Se redirige de vuelta al listado de habitaciones
                    request.getRequestDispatcher("Controlador_habitaciones?menu=habitaciones&accion=listar").forward(request, response);
                    break;

                case "eliminar1":
                    // Acción: Inhabilitar una habitación (para el rol de recepcionista)

                    // Se obtiene el ID de la habitación desde los parámetros de la solicitud
                    id = Integer.parseInt(request.getParameter("id"));
                    hab.setHabitacionid(id);

                    // Se realiza la inhabilitación en la base de datos
                    resultado = dao.inactivar(hab);

                    // Se muestra un mensaje según el resultado de la inhabilitación
                    if (resultado == 1) {
                        JOptionPane.showMessageDialog(null, "Se inhabilitó correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Error en la inhabilitación", "Error", JOptionPane.ERROR_MESSAGE);
                    }

                    // Se redirige de vuelta al listado de habitaciones
                    request.getRequestDispatcher("Controlador_habitaciones?menu=habitaciones&accion=listar1").forward(request, response);
                    break;

                case "registrar":
                    // Acción: Registrar una nueva habitación (para el rol de gerente)

                    // Se obtienen los parámetros de la solicitud
                    tipo = request.getParameter("tipo");
                    String vista = request.getParameter("vista");
                    cantidad = Integer.parseInt(request.getParameter("cantidad"));
                    precio = Float.parseFloat(request.getParameter("precio"));
                    servicios = request.getParameter("servicios");
                    cantidad_habitaciones = Integer.parseInt(request.getParameter("cantidad_habitaciones"));

                    // Se establecen los valores de la nueva habitación
                    hab.setTipo(tipo);
                    hab.setVista(vista);
                    hab.setCantidad(cantidad);
                    hab.setPrecio(precio);
                    hab.setServicios(servicios);
                    hab.setCantidad_habitaciones(cantidad_habitaciones);

                    // Se verifica la inserción en la base de datos
                    resultado = dao.verificarparainsertar(hab);

                    // Se muestra un mensaje según el resultado de la verificación
                    if (resultado == 1) {
                        JOptionPane.showMessageDialog(null, "Se insertó correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    } else if (resultado == 3) {
                        JOptionPane.showMessageDialog(null, "La cantidad de habitaciones que estás intentando registrar supera la capacidad máxima del hotel. Por favor, revisa la cantidad de habitaciones disponibles y ajusta tu registro en consecuencia.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Error en la inserción", "Error", JOptionPane.ERROR_MESSAGE);
                    }

                    // Se redirige de vuelta al listado de habitaciones del gerente
                    request.getRequestDispatcher("Controlador_habitaciones?menu=habitaciones&accion=listar").forward(request, response);
                    break;

                case "registrar1":
                    // Acción: Registrar una nueva habitación (para el rol de recepcionista)

                    // Se obtienen los parámetros de la solicitud
                    tipo = request.getParameter("tipo");
                    vista = request.getParameter("vista");
                    cantidad = Integer.parseInt(request.getParameter("cantidad"));
                    precio = Float.parseFloat(request.getParameter("precio"));
                    servicios = request.getParameter("servicios");
                    cantidad_habitaciones = Integer.parseInt(request.getParameter("cantidad_habitaciones"));

                    // Se establecen los valores de la nueva habitación
                    hab.setTipo(tipo);
                    hab.setVista(vista);
                    hab.setCantidad(cantidad);
                    hab.setPrecio(precio);
                    hab.setServicios(servicios);
                    hab.setCantidad_habitaciones(cantidad_habitaciones);

                    // Se verifica la inserción en la base de datos
                    resultado = dao.verificarparainsertar(hab);

                    // Se muestra un mensaje según el resultado de la verificación
                    if (resultado == 1) {
                        JOptionPane.showMessageDialog(null, "Se insertó correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    } else if (resultado == 3) {
                        JOptionPane.showMessageDialog(null, "La cantidad de habitaciones que estás intentando registrar supera la capacidad máxima del hotel. Por favor, revisa la cantidad de habitaciones disponibles y ajusta tu registro en consecuencia.");
                    } else {
                        JOptionPane.showMessageDialog(null, "Error en la inserción", "Error", JOptionPane.ERROR_MESSAGE);
                    }

                    // Se redirige de vuelta al listado de habitaciones del recepcionista
                    request.getRequestDispatcher("Controlador_habitaciones?menu=habitaciones&accion=listar1").forward(request, response);
                    break;

                case "reservarecepcionista":
                    // Acción: Reservar habitación (para el rol de recepcionista)

                    // Se obtiene el alojamiento actual desde los datos guardados en la sesión
                    dao1 = new alojamientoDao();
                    alojamiento alojamientoid = datosguardados.getAlojamientoActual();
                    alo = dao1.buscarid(alojamientoid.getId());

                    // Se establecen los atributos necesarios en la solicitud
                    request.setAttribute("alojamiento", alo);
                    habitaciones = dao.habitaciones();
                    request.setAttribute("habitaciones", habitaciones);

                    // Se redirige a la página principal del recepcionista
                    request.getRequestDispatcher("principal_recepcionista.jsp").forward(request, response);
                    break;
            }
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
