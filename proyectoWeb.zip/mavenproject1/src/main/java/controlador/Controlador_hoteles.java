/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controlador;

import datos.datosguardados;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.swing.JOptionPane;
import modelo_alojamiento.alojamiento;
import modelo_alojamiento.alojamientoDao;
import modelo_gerente.gerente;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 *
 * @author Marely
 */
@WebServlet(name = "Controlador_hoteles", urlPatterns = {"/Controlador_hoteles"})
public class Controlador_hoteles extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        alojamiento alo = new alojamiento();
        alojamientoDao dao = new alojamientoDao();

        String menu = request.getParameter("menu");
        String accion = request.getParameter("accion");

//         JOptionPane.showMessageDialog(null, menu);
//         JOptionPane.showMessageDialog(null, accion);
        if (accion == null) {
            accion = "";
        }
        if (menu == null) {
            menu = "";
        }

        if (menu.equals("hoteles")) {
            switch (accion) {

                case "consultar":
                    // Acción: Consultar lista de hoteles

                    // Se obtienen los hoteles desde la base de datos
                    List hoteles = dao.obtenerAlojamientos();

                    // Se establecen los hoteles como atributo en la solicitud
                    request.setAttribute("hoteles", hoteles);

                    // Se redirige a la página de consulta de hoteles del gerente
                    request.getRequestDispatcher("vistas_gerente/consultar_hoteles.jsp").forward(request, response);
                    break;

                case "registrar":
                    // Acción: Registrar un nuevo hotel

                    // Se crea una lista para almacenar los campos del formulario y la imagen
                    ArrayList<String> lista = new ArrayList<>();

                    try {
                        // Se utiliza ServletFileUpload para manejar la carga de archivos
                        FileItemFactory file = new DiskFileItemFactory();
                        ServletFileUpload fileUpload = new ServletFileUpload(file);

                        // Se obtienen los items de la solicitud
                        List items = fileUpload.parseRequest(request);

                        // Se recorren los items para procesarlos
                        for (int i = 0; i < items.size(); i++) {
                            FileItem fileItem = (FileItem) items.get(i);
                            if (!fileItem.isFormField()) {
                                // Si el item no es un campo de formulario, se trata como una imagen y se guarda en alo
                                byte[] fileBytes = fileItem.get();
                                alo.setImagen(fileBytes);
                            } else {
                                // Si es un campo de formulario, se agrega a la lista
                                lista.add(fileItem.getString());
                            }
                        }

                        // Se obtienen los valores del formulario desde la lista
                        alo.setNit(Integer.parseInt(lista.get(0)));
                        alo.setNombre(lista.get(1));
                        alo.setCorreo(lista.get(3));
                        alo.setTelefono(lista.get(5));
                        alo.setDireccion(lista.get(6));
                        alo.setHabticacionesc(Integer.parseInt(lista.get(4)));
                        alo.setDescripcion(lista.get(2));
                    } catch (Exception e) {
                        // Se muestra un mensaje de error si ocurre una excepción
                        JOptionPane.showMessageDialog(null, e.toString());
                    }

                    // Se obtiene el ID del gerente actual y se establece como gerente del hotel
                    gerente miGerente = datosguardados.getGerenteActual();
                    int gerenteID = miGerente.getGerenteid();
                    alo.setGerente(gerenteID);

                    // Se agrega el hotel a la base de datos
                    int resultado = dao.agregaralojamiento(alo);

                    // Se muestra un mensaje según el resultado de la inserción
                    if (resultado == 1) {
                        JOptionPane.showMessageDialog(null, "Se insertó correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Error en la inserción", "Error", JOptionPane.ERROR_MESSAGE);
                    }

                    // Se redirige de vuelta a la página de consulta de hoteles del gerente
                    request.getRequestDispatcher("Controlador_hoteles?menu=hoteles&accion=consultar").forward(request, response);
                    break;

                case "modificar":
                    // Acción: Modificar un hotel

                    // Se obtienen los parámetros del formulario
                    String des = request.getParameter("descripcion");
                    String dir = request.getParameter("direccion");
                    String cor = request.getParameter("correo");
                    String tel = request.getParameter("telefono");
                    int id = Integer.parseInt(request.getParameter("id"));

                    // Se establecen los valores del hotel a modificar
                    alo.setCorreo(cor);
                    alo.setDescripcion(des);
                    alo.setDireccion(dir);
                    alo.setTelefono(tel);
                    alo.setId(id);

                    // Se realiza la modificación en la base de datos
                    int num = dao.modificaralojamiento(alo);

                    // Se muestra un mensaje según el resultado de la modificación
                    if (num == 1) {
                        String aler = "hotel modificado correctamente";
                        request.setAttribute("aler", aler);
                    } else {
                        String aler = "No se pudo modificar";
                        request.setAttribute("aler", aler);
                    }

                    // Se redirige de vuelta a la página de consulta de hoteles del gerente
                    request.getRequestDispatcher("Controlador_hoteles?menu=hoteles&accion=consultar").forward(request, response);
                    break;

                case "eliminar":
                    // Acción: Inhabilitar un hotel

                    // Se obtiene el ID del hotel a inhabilitar
                    int id1 = Integer.parseInt(request.getParameter("id"));
                    alo.setId(id1);

                    // Se realiza la inhabilitación en la base de datos
                    num = dao.inactivaralojamiento(alo);

                    // Se muestra un mensaje según el resultado de la inhabilitación
                    if (num == 1) {
                        String aler = "hotel inhabilitado correctamente";
                        request.setAttribute("aler", aler);
                    } else {
                        String aler = "No se pudo inhabilitar";
                        request.setAttribute("aler", aler);
                    }

                    // Se redirige de vuelta a la página de consulta de hoteles del gerente
                    request.getRequestDispatcher("Controlador_hoteles?menu=hoteles&accion=consultar").forward(request, response);
                    break;

                case "buscar":
                    // Acción: Buscar un hotel

                    // Se obtiene el término de búsqueda desde el formulario
                    String buscar = request.getParameter("buscar");

                    // Se realiza la búsqueda en la base de datos
                    alo = dao.buscar(buscar);

                    // Se establece el hotel encontrado como atributo en la solicitud
                    request.setAttribute("alo", alo);

                    // Se redirige a la página principal
                    request.getRequestDispatcher("index.jsp").forward(request, response);
                    break;

                case "buscarcantidad":
                    // Acción: Buscar hoteles por cantidad de habitaciones

                    // Se obtiene la cantidad de habitaciones desde el formulario
                    int cantidad = Integer.parseInt(request.getParameter("cantidad"));

                    // Se realiza la búsqueda en la base de datos
                    List alojamientocantidad = dao.buscarporhabitaciones(cantidad);

                    // Se establece el resultado de la búsqueda como atributo en la solicitud
                    request.setAttribute("alojamientocantidad", alojamientocantidad);

                    // Se redirige a la página principal
                    request.getRequestDispatcher("index.jsp").forward(request, response);
                    break;

                default:

                    request.getRequestDispatcher("Controlador_hoteles?menu=hoteles&accion=consultar").forward(request, response);
                    break;
            }
        }

    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
