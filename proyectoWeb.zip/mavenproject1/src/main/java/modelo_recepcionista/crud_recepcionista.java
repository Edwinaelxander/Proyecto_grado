/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package modelo_recepcionista;

/**
 *
 * @author Marely
 */
public interface crud_recepcionista {
    public int agregarrecepcionista(Recepcionista r);
    public int modificarrecepcionista(Recepcionista r);
    public int inhabilitarrecepcionista(Recepcionista r);
    
}
