/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_pqrs;

import bd.Conexion;
import datos.datosguardados;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import modelo_usuario.Usuario;

/**
 *
 * @author Marely
 */
public class PqrsDao implements Crud_pqrs {

    Conexion conetion = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    @Override
    public int agregarpqrs(Pqrs tr) {
        String sql = "INSERT INTO pqrs (UsuarioID, Tipo, Descripcion, Alojamiento, estado) VALUES(?,?,?,?,?)";

        try {

            if (tr.getAlojamiento() == null) {
                tr.setAlojamiento("");
            }
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            Usuario usu = datosguardados.getUsuarioactual();

            if (usu == null) {
                ps.setNull(1, java.sql.Types.INTEGER);
            } else {
                ps.setInt(1, usu.getIdusuario());
            }

            ps.setString(2, tr.getTipo());
            ps.setString(3, tr.getDescripcion());
            ps.setString(4, tr.getAlojamiento());
            ps.setInt(5, 0);

            ps.executeUpdate();
            return 1;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "error de insercion" + e.getMessage(), JOptionPane.ERROR_MESSAGE);
            return 0;
        }

    }

    public List pqrs() {
        List<Pqrs> pqrs = new ArrayList<>();

        String sql = "SELECT pqrs.*, u.nombre AS NombreUsuario FROM pqrs  "
                + "  JOIN   usuarioregistrado u ON pqrs.UsuarioID = u.UsuarioID;";

        try {

            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {

                Pqrs pq = new Pqrs();
                pq.setPqrsid(rs.getInt("PQRSID"));
                pq.setNombre(rs.getString("NombreUsuario"));
                pq.setTipo(rs.getString("Tipo"));
                pq.setDescripcion(rs.getString("Descripcion"));
                pq.setAlojamiento(rs.getString("Alojamiento"));
                pq.setRespuesta(rs.getString("respuesta"));

                pqrs.add(pq);

                datosguardados.setPqrsactual(pq);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return pqrs;

    }

    public int responder(Pqrs p) {

        String sql = "UPDATE pqrs SET respuesta=? WHERE PQRSID=?";

        try {

            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ps.setString(1, p.getRespuesta());
            ps.setInt(2, p.getPqrsid());

            ps.executeUpdate();
            return 1;

        } catch (Exception e) {
            System.out.print(e.toString() + "error en responder " + e.getMessage());
            return 0;
        }
    }

}
