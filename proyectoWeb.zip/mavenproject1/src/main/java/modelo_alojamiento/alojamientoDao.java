/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_alojamiento;

import bd.Conexion;
import datos.datosguardados;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import modelo_gerente.gerente;

/**
 *
 * @author Marely
 */
public class alojamientoDao implements crud_alojamiento {

    Conexion conetion = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    @Override
    public int agregaralojamiento(alojamiento tr) {
        String sql = "INSERT INTO alojamientos (Nit, nombre,descripcion, cantidad_habitaciones, CorreoContacto,Telefono,direccion,GerenteID,estado,Foto) VALUES(?,?,?,?,?,?,?,?,?,?)";
        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ps.setInt(1, tr.getNit());
            ps.setString(2, tr.getNombre());
            ps.setString(3, tr.getDescripcion());
            ps.setInt(4, tr.getHabticacionesc());
            ps.setString(5, tr.getCorreo());
            ps.setString(6, tr.getTelefono());
            ps.setString(7, tr.getDireccion());
            ps.setInt(8, tr.getGerente());
            ps.setInt(9, 0);
            ps.setBytes(10, tr.getImagen());

            ps.executeUpdate();
            return 1;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "error de insercion" + e.getMessage(), JOptionPane.ERROR_MESSAGE);
            return 0;
        }
    }

    @Override
    public int modificaralojamiento(alojamiento tr) {
        String sql = "UPDATE alojamientos SET  descripcion=?, CorreoContacto=?, Telefono=? WHERE AlojamientoID=?";

        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);

            ps.setString(1, tr.getDescripcion());

            ps.setString(2, tr.getCorreo());
            ps.setString(3, tr.getTelefono());
            ps.setInt(4, tr.getId());
            ps.executeUpdate();
            return 1;

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString());
            return 0;
        }
    }

    @Override
    public int inactivaralojamiento(alojamiento tr) {
        String sql = "UPDATE alojamientos SET estado=?  WHERE AlojamientoID=?";

        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);

            ps.setInt(1, 1);
            ps.setInt(2, tr.getId());
            ps.executeUpdate();
            return 1;

        } catch (Exception e) {
            System.out.print(e.toString() + "error de eliminacion " + e.getMessage());
            return 0;
        }

    }

    @Override
    public List obtenerAlojamientos() {
        List<alojamiento> alojamientos = new ArrayList<>();
        String sql = "SELECT * FROM alojamientos WHERE estado='0' AND GerenteID=? ";
        String sql2 = "SELECT * FROM alojamientos WHERE estado='0'  ";
        try {
            gerente g = datosguardados.getGerenteActual();
            con = conetion.getCon();

            if (g != null && g.getGerenteid() != 0) {
                ps = con.prepareStatement(sql);
                ps.setInt(1, g.getGerenteid());
            } else {
                ps = con.prepareStatement(sql2);
            }

            rs = ps.executeQuery();
            while (rs.next()) {

                String nombre = rs.getString("nombre");
                String direccion = rs.getString("direccion");
                String descripcion = rs.getString("descripcion");
                int id = rs.getInt("AlojamientoID");
                String correo = rs.getString("CorreoContacto");
                String telefono = rs.getString("Telefono");
                byte[] imagen = rs.getBytes("Foto");

                alojamiento alojamiento = new alojamiento();
                alojamiento.setDescripcion(descripcion);
                alojamiento.setNombre(nombre);
                alojamiento.setDireccion(direccion);
                alojamiento.setId(id);
                alojamiento.setCorreo(correo);
                alojamiento.setTelefono(telefono);
                alojamiento.setImagen(imagen);
                datosguardados.setAlojamientoActual(alojamiento);

                alojamientos.add(alojamiento);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return alojamientos;
    }

    public List buscarporhabitaciones(int cantidad) {
        List<alojamiento> alojamientos = new ArrayList<>();

        String sql2 = "SELECT a.*, MAX(h.HabitacionID) AS HabitacionID FROM alojamientos a JOIN habitaciones h ON a.AlojamientoID = h.AlojamientoID WHERE h.cantidad = ? AND h.Disponibilidad =0 GROUP BY a.AlojamientoID;";
        try {
            gerente g = datosguardados.getGerenteActual();
            con = conetion.getCon();
            ps = con.prepareStatement(sql2);
            ps.setInt(1, cantidad);

            rs = ps.executeQuery();
            while (rs.next()) {

                String nombre = rs.getString("nombre");
                String direccion = rs.getString("direccion");
                String descripcion = rs.getString("descripcion");
                int id = rs.getInt("AlojamientoID");
                String correo = rs.getString("CorreoContacto");
                String telefono = rs.getString("Telefono");
                byte[] imagen = rs.getBytes("Foto");

                alojamiento alojamiento = new alojamiento();
                alojamiento.setDescripcion(descripcion);
                alojamiento.setNombre(nombre);
                alojamiento.setDireccion(direccion);
                alojamiento.setId(id);
                alojamiento.setCorreo(correo);
                alojamiento.setTelefono(telefono);
                alojamiento.setImagen(imagen);
                datosguardados.setAlojamientoActual(alojamiento);

                alojamientos.add(alojamiento);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return alojamientos;
    }

    public alojamiento buscar(String a) {
        alojamiento alojamiento = new alojamiento();
        String sql = "SELECT * FROM alojamientos WHERE Nombre=?";
        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ps.setString(1, a);
            rs = ps.executeQuery();
            rs.next();

            String nombre1 = rs.getString("nombre");
            String direccion = rs.getString("direccion");
            int id = rs.getInt("AlojamientoID");
            String correo = rs.getString("CorreoContacto");
            String telefono = rs.getString("Telefono");
            byte[] imagen = rs.getBytes("Foto");
            String descripcion = rs.getString("descripcion");

            alojamiento.setNombre(nombre1);
            alojamiento.setDireccion(direccion);
            alojamiento.setId(id);
            alojamiento.setDescripcion(descripcion);
            alojamiento.setCorreo(correo);
            alojamiento.setTelefono(telefono);
            alojamiento.setImagen(imagen);
            datosguardados.setAlojamientoActual(alojamiento);

        } catch (SQLException e) {

        }
        return alojamiento;

    }

    public alojamiento buscarid(int id) {
        alojamiento alojamiento = new alojamiento();
        String sql = "SELECT * FROM alojamientos WHERE AlojamientoID=" + id;
        try {

            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {

                String nombre = rs.getString("nombre");
                String direccion = rs.getString("direccion");
                String descripcion = rs.getString("descripcion");

                String correo = rs.getString("CorreoContacto");
                String telefono = rs.getString("Telefono");
                byte[] imagen = rs.getBytes("Foto");

                alojamiento.setDescripcion(descripcion);
                alojamiento.setNombre(nombre);
                alojamiento.setDireccion(direccion);
                alojamiento.setId(id);
                alojamiento.setCorreo(correo);
                alojamiento.setTelefono(telefono);
                alojamiento.setImagen(imagen);
                datosguardados.setAlojamientoActual(alojamiento);
            }

        } catch (Exception e) {

        }
        return alojamiento;
    }

    public int suma() {
        String sqlhabitaciones = "SELECT SUM(cantidad_habitaciones) AS total_habitaciones FROM habitaciones WHERE AlojamientoID =?";
        String sqlhotel = "SELECT cantidad_habitaciones FROM alojamientos WHERE AlojamientoID =?";
        return 1;
    }
}
