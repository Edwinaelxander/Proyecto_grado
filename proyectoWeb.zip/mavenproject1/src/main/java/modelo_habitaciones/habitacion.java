/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_habitaciones;

/**
 *
 * @author Marely
 */
public class habitacion {
    private String tipo;
    private String vista;
    private int cantidad;
    private float precio;
    private String servicios;
    private int habitacionid;
    private int alojamientoid;
    private int cantidad_habitaciones;

   
    public habitacion(String tipo, String vista, int cantidad, float precio, String servicios, int habitacionid, int alojamientoid) {
        this.tipo = tipo;
        this.vista = vista;
        this.cantidad = cantidad;
        this.precio = precio;
        this.servicios = servicios;
        this.habitacionid = habitacionid;
        this.alojamientoid = alojamientoid;
    }

    
    public habitacion() {
    }

    public int getCantidad_habitaciones() {
        return cantidad_habitaciones;
    }

    public void setCantidad_habitaciones(int cantidad_habitaciones) {
        this.cantidad_habitaciones = cantidad_habitaciones;
    }

    
    public int getAlojamientoid() {
        return alojamientoid;
    }

    public void setAlojamientoid(int alojamientoid) {
        this.alojamientoid = alojamientoid;
    }

    
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getVista() {
        return vista;
    }

    public void setVista(String vista) {
        this.vista = vista;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public String getServicios() {
        return servicios;
    }

    public void setServicios(String servicios) {
        this.servicios = servicios;
    }

    public int getHabitacionid() {
        return habitacionid;
    }

    public void setHabitacionid(int habitacionid) {
        this.habitacionid = habitacionid;
    }
    
    
}
