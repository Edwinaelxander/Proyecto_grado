/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_habitaciones;

import java.util.List;

/**
 *
 * @author Marely
 */
public interface Crud_habitacion<Habitacion> {
    
    public int agregarhabitacion(habitacion tr);
    public int modificarhabitacion(habitacion tr);
    public List<Habitacion> habitaciones();
    public int  info(habitacion tr);
    public int inactivar(habitacion tr);
    
    
}
