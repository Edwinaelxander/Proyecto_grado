$(document).ready(function () {
    // Funcionalidad del botón Responder
    

    // Funcionalidad del botón "sin responder"
    $('.btn-filter[data-target="redd"]').on('click', function () {
        $('.table tr').hide(); // Oculta todas las filas

        // Muestra solo las filas que no tienen el botón de Responder
        $('.table tr:has(.btn-responder)').fadeIn('slow');
    });

    // Funcionalidad del botón Todos
    $('.btn-filter[data-target="all"]').on('click', function () {
        $('.table tr').fadeIn('slow'); // Muestra todas las filas
    });

    // Desactivar los enlaces
    $('a[href="#"]').on('click', function (e) {
        e.preventDefault();
    });
});