<?php

class Conectar{
 private $server;
 private $user;
 private $password;
 private $bd;
 private $acceso;


  function __construct(){
              
    include "configuracion.php";
        $this->server=$server;
        $this->user=$user;
        $this->password=$password;
        $this->bd=$bd;

    }
    
    public function conectar1(){

        $this->acceso = mysqli_connect($this->server,$this->user,$this->password,$this->bd);
        if ($this->acceso) {
            echo "conexion exitosa";
        }else{  
            echo "no se pudo conectar";
        }
        

    }

    public function desconetar(){
        mysqli_close($this->acceso);
        echo "base de datos apagada";
    }
}

?>