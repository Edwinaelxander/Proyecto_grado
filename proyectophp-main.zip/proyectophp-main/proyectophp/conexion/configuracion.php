<?php 

 $server="localhost";
 $user="root";
 $password="";
 $bd="desercion";


?>