/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package efectos;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.UIManager;

/**
 *
 * @author Marely
 */
public class Botonhover extends MouseAdapter {

    private final JPanel panel;
    private final Color colorTextoOriginal;
    private final int MOVIMIENTO = 4; // Cantidad de movimiento en píxeles

    // Inicialización configurando color original
    public Botonhover(JPanel panel) {
        this.panel = panel;
        this.colorTextoOriginal = panel.getForeground();
    }

    // Cada vez que pasa el mouse sobre un componente del panel, cambia color y mueve el componente hacia arriba
    @Override
    public void mouseEntered(MouseEvent e) {
        Component componente = e.getComponent();
        moverComponente(componente, componente.getX(), componente.getY() - MOVIMIENTO); // Movimiento hacia arriba
        componente.setBackground(Color.RED);
        componente.setForeground(Color.orange);
    }

    // Cada vez que sale el mouse del componente, vuelve a su estado original y posición original
    @Override
    public void mouseExited(MouseEvent e) {
        Component componente = e.getComponent();
        moverComponente(componente, componente.getX(), componente.getY() + MOVIMIENTO); // Movimiento hacia abajo
        componente.setBackground(panel.getBackground());
        componente.setForeground(colorTextoOriginal);
    }

    // Método para mover un componente a una posición específica
    private void moverComponente(Component componente, int x, int y) {
        Timer timer = new Timer(5, (actionEvent) -> {
            int newX = componente.getX();
            int newY = componente.getY();

            if (newY < y) { // Cambiar dirección del movimiento hacia arriba
                newY++;
            } else if (newY > y) { // Cambiar dirección del movimiento hacia abajo
                newY--;
            }

            componente.setLocation(newX, newY);

            if (newY == y) { // Detener el timer cuando el componente llegue a la posición deseada
                ((Timer) actionEvent.getSource()).stop();
            }
        });
        timer.start();
    }

    // Método para aplicar el efecto hover a todos los botones dentro del panel
    public void aplicarEfectoHover() {
        for (Component componente : panel.getComponents()) {
            if (componente instanceof JButton) {
                componente.addMouseListener(this);
            }
        }
    }
}