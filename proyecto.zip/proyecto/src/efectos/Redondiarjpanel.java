/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package efectos;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JPanel;

/**
 *
 * @author Marely
 */
public class Redondiarjpanel extends JPanel {

    public Redondiarjpanel() {
    }
    
   
 @Override
protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D) g.create();
    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    int width = getWidth();
    int height = getHeight();

    // Establecer el color del borde
    g2.setColor(Color.ORANGE);

    // Dibujar el borde redondeado
    g2.draw(new RoundRectangle2D.Double(0, 0, width - 1, height - 1, 30, 30));

    g2.dispose();
}
}
