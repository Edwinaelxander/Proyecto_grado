/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package efectos;
import java.awt.Color;
/**
 *
 * @author Marely
 */
public class Colores {
    
    
     public static Color color(Color color, int increment) {
        int red = color.getRed() + increment;
        int green = color.getGreen() + increment;
        int blue = color.getBlue() + increment;
red = Math.min(red, 255);
        green = Math.min(green, 255);
        blue = Math.min(blue, 255);

        return new Color(red, green, blue);
    }
}
