/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package efectos;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Shape;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JButton;

/**
 *
 * @author Marely
 */
public class Redondiarboton extends JButton{
     public Redondiarboton(String label) {
        super(label);
        // Hacemos el botón transparente
        setContentAreaFilled(false);
        setFocusPainted(false);
        // Reducimos el margen para que el botón sea más redondo
        setMargin(new Insets(10, 20, 10, 20));
    }

    // Sobreescribimos el método paintComponent para dibujar el botón redondo
    protected void paintComponent(Graphics g) {
        if (getModel().isArmed()) {
            g.setColor(Color.gray);
        } else {
            g.setColor(getBackground());
        }
        // Dibujamos el botón redondo
        g.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 30, 30);
        // Llamamos al método paintComponent de la clase padre para que pinte el contenido del botón
        super.paintComponent(g);
    }

    // Sobreescribimos el método paintBorder para que no se pinte el borde del botón
    protected void paintBorder(Graphics g) {
        g.setColor(getForeground());
        g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 30, 30);
    }

    // Sobreescribimos el método contains para que los clics dentro del botón se consideren siempre dentro del área redonda
    public boolean contains(int x, int y) {
        if (shape == null || !shape.getBounds().equals(getBounds())) {
            shape = new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 30, 30);
        }
        return shape.contains(x, y);
    }

    // Forma redonda del botón
    private Shape shape;
    
}
