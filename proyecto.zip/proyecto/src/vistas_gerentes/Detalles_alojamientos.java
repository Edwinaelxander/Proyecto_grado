/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_gerentes;

import controlador.Controlador_alojamiento;
import datos.datosguardados;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;
import modelo_alojamiento.alojamiento;
import ventanas_emergentes.Inactivar_alojamiento;

/**
 *
 * @author Marely
 */
public class Detalles_alojamientos extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio, alojamiento, informes, yo, modificar, inactivar, habitaciones,recepcionista;
    JPanel panelalojamientos = new JPanel(new BorderLayout());
    JTextArea descripcion;
    Font font = new Font("Arial", Font.BOLD, 13);

    public Detalles_alojamientos() {

        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel cabecera = new JPanel(new BorderLayout());

      
        TitledBorder titledBorder = BorderFactory.createTitledBorder("HOTEL");
        titledBorder.setTitleFont(new Font("Arial", Font.BOLD, 30));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.CENTER);

        cabecera.setBorder(titledBorder);
        cabecera.setPreferredSize(new Dimension(450, 560));
        cabecera.setBackground(Color.WHITE);

        JPanel cru1 = new JPanel(new BorderLayout());

        cru1.setBackground(Color.WHITE);
        JPanel cru = new JPanel(new GridLayout(2, 2, 10, 10));
        cru.setPreferredSize(new Dimension(450, 80));

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 50));
        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));

        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima1 = new ImageIcon("alojamiento.PNG");
        alojamiento = new JButton("alojamiento", ima1);
        alojamiento.setContentAreaFilled(false);
        alojamiento.setVerticalTextPosition(JButton.BOTTOM);
        alojamiento.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("informe.PNG");
        informes = new JButton("informe", ima2);
        informes.setContentAreaFilled(false);
        informes.setVerticalTextPosition(JButton.BOTTOM);
        informes.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);

        modificar = new JButton("modificar");
        modificar.setBackground(Color.orange);
        inactivar = new JButton("inactivar");
        inactivar.setBackground(Color.orange);
        habitaciones = new JButton("habitaciones");
//        habitaciones.setBackground(Color.orange);
        recepcionista=new JButton("recepcionistas");
        recepcionista.addActionListener(this);

        cru.add(habitaciones);
        cru.add(recepcionista );
        cru.add(modificar);        
        cru.add(inactivar);

        cru1.add(cru, BorderLayout.SOUTH);

        principal.add(inicio);
        principal.add(alojamiento);
        principal.add(informes);
        principal.add(yo);

        navegador.add(principal);

        panelalojamientos = new JPanel(new GridLayout(0, 1, 2, 10));
        cabecera.add(panelalojamientos);
     
        inicializar();
        contenedor.add(cabecera, BorderLayout.NORTH);
        contenedor.add(cru1, BorderLayout.CENTER);
        contenedor.add(navegador, BorderLayout.SOUTH);

        setSize(500, 800);

        inicio.addActionListener(this);
        alojamiento.addActionListener(this);
        informes.addActionListener(this);
        yo.addActionListener(this);
        habitaciones.addActionListener(this);
        modificar.addActionListener(this);
        inactivar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == alojamiento) {
            dispose();
            Registrar_alojamiento a = new Registrar_alojamiento();
            Controlador_alojamiento b = new Controlador_alojamiento(a);
            a.setVisible(true);

        }
        if (e.getSource() == informes) {
            dispose();
            Incidente_gerente a = new Incidente_gerente();
            a.setVisible(true);

        }
        if (e.getSource() == inicio) {
            dispose();
            Principal_gerente a = new Principal_gerente();
            a.setVisible(true);
        }
        if (e.getSource() == yo) {
            dispose();
            Salir_gerente a = new Salir_gerente();
            a.setVisible(true);

        }

        if (e.getSource() == habitaciones) {
            dispose();
            Habitaciones a = new Habitaciones();
            a.setVisible(true);
//            alojamiento alo = datosguardados.getAlojamientoActual();
        }
        if (e.getSource() == modificar) {
            dispose();
            Modificar_alojamiento a = new Modificar_alojamiento();
            Controlador_alojamiento b = new Controlador_alojamiento(a);
            a.setVisible(true);
        }

        if (e.getSource() == inactivar) {
            dispose();
            Inactivar_alojamiento a = new Inactivar_alojamiento();
            Controlador_alojamiento b = new Controlador_alojamiento(a);
            a.setVisible(true);
        }
        if(e.getSource()==recepcionista){
            dispose();
            recepcionista_lista a=new recepcionista_lista();
            a.setVisible(true);
        }
    }

    private void inicializar() {
        alojamiento alojamiento1 = datosguardados.getAlojamientoActual();

//System.out.println(alojamiento1.getNombre());
//System.out.println(alojamiento1.getDireccion());
        JLabel labelId = new JLabel("NOMBRE: " + alojamiento1.getNombre());
        JLabel labelDireccion = new JLabel("DIRECCION: " + alojamiento1.getDireccion());
        descripcion = new JTextArea("DESCRIPCION: " + alojamiento1.getDescripcion());
        descripcion.setEditable(false);
        descripcion.setFont(font);

        descripcion.setFocusable(false);
        descripcion.setBackground(null);

        JPanel panelDetalles = new JPanel(new GridLayout(3, 1));
        panelDetalles.add(labelId);
        panelDetalles.add(descripcion);
        panelDetalles.add(labelDireccion);

        panelalojamientos.add(panelDetalles, BorderLayout.NORTH);

        panelalojamientos.revalidate();
    }

}
