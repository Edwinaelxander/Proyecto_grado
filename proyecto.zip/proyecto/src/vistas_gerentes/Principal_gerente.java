/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_gerentes;

import controlador.Controlador_alojamiento;
import datos.datosguardados;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;
import modelo_alojamiento.alojamiento;
import modelo_alojamiento.alojamientoDao;
import vistas_admind.Perfil_admin;

/**
 *
 * @author Marely
 */
public class Principal_gerente extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio, alojamient, informes, yo, notificar;
    JPanel panelalojamientos = new JPanel(new BorderLayout());
    private JTextArea labelDescripcion, labelNombre, labelDireccion;
    private alojamiento alojamientoSeleccionado;
    Font font = new Font("Arial", Font.BOLD, 13);
    private JLabel labelImagen;

    public Principal_gerente() {

        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel cabecera = new JPanel(new BorderLayout());
        TitledBorder titledBorder = BorderFactory.createTitledBorder("HOTELES");
        titledBorder.setTitleFont(new Font("Arial", Font.BOLD, 30));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.CENTER);

        cabecera.setBorder(titledBorder);
        cabecera.setPreferredSize(new Dimension(450, 500));
        cabecera.setBackground(Color.WHITE);

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 10));

        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));

        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima1 = new ImageIcon("alojamiento.PNG");
        alojamient = new JButton("alojamiento", ima1);
        alojamient.setContentAreaFilled(false);
        alojamient.setVerticalTextPosition(JButton.BOTTOM);
        alojamient.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("informe.PNG");
        informes = new JButton("informe", ima2);
        informes.setContentAreaFilled(false);
        informes.setVerticalTextPosition(JButton.BOTTOM);
        informes.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);

        notificar = new JButton("notificar");
        notificar.setBackground(Color.orange);

        principal.add(inicio);
        principal.add(alojamient);
        principal.add(informes);
        principal.add(yo);

        navegador.add(principal);

        panelalojamientos = new JPanel(new GridLayout(0, 2, 2, 10));

        panelalojamientos.setBackground(Color.WHITE);
        panelalojamientos.setPreferredSize(new Dimension(400, 1000));
        cabecera.add(notificar, BorderLayout.SOUTH);
        JScrollPane scrollPane = new JScrollPane(panelalojamientos, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        cabecera.add(scrollPane);
        inicializar();

        contenedor.add(cabecera, BorderLayout.CENTER);
        contenedor.add(navegador, BorderLayout.SOUTH);
        contenedor.setBackground(Color.BLUE);

        setSize(500, 800);

        inicio.addActionListener(this);
        alojamient.addActionListener(this);
        informes.addActionListener(this);
        yo.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == alojamient) {
            dispose();
            Registrar_alojamiento a = new Registrar_alojamiento();
            Controlador_alojamiento b = new Controlador_alojamiento(a);
            a.setVisible(true);

        }
        if (e.getSource() == informes) {
            dispose();
            Incidente_gerente a = new Incidente_gerente();
            a.setVisible(true);

        }
        if (e.getSource() == yo) {
            dispose();
            Salir_gerente a = new Salir_gerente();
            a.setVisible(true);

        }

    }

    private void inicializar() {
        alojamientoDao alo = new alojamientoDao();

        List<alojamiento> Alojamiento = alo.obtenerAlojamientos();

        for (alojamiento alojamientos : Alojamiento) {
            JPanel panelAlojamiento = new JPanel(new FlowLayout());

            panelAlojamiento.setBorder(BorderFactory.createLineBorder(Color.BLACK));
            labelNombre = new JTextArea("HOTEL: " + alojamientos.getNombre());
            labelNombre.setEditable(false);
            labelNombre.setFont(font);
            labelNombre.setFocusable(false);
            labelNombre.setBackground(null);
            labelNombre.setPreferredSize(new Dimension(200, 50));
            labelNombre.setLineWrap(true);
            labelNombre.setWrapStyleWord(true);

            labelDescripcion = new JTextArea("DESCRIPCION: " + alojamientos.getDescripcion());
            labelDescripcion.setEditable(false);
            labelDescripcion.setFont(font);
            labelDescripcion.setFocusable(false);
            labelDescripcion.setBackground(null);
            labelDescripcion.setPreferredSize(new Dimension(200, 90));
            labelDescripcion.setLineWrap(true);
            labelDescripcion.setWrapStyleWord(true);

            labelImagen = new JLabel();

            labelDireccion = new JTextArea("DIRECCION: " + alojamientos.getDireccion());
            labelDireccion.setEditable(false);
            labelDireccion.setFont(font);
            labelDireccion.setFocusable(false);
            labelDireccion.setBackground(null);
            labelDireccion.setPreferredSize(new Dimension(200, 50));
            labelDireccion.setLineWrap(true);
            labelDireccion.setWrapStyleWord(true);

            byte[] imagenBytes = alojamientos.getImagen();
            Image imagen = Toolkit.getDefaultToolkit().createImage(imagenBytes);
            ImageIcon imagenIcono = new ImageIcon(imagen.getScaledInstance(150, 100, Image.SCALE_SMOOTH));
            labelImagen.setIcon(imagenIcono);

            panelAlojamiento.add(labelImagen, BorderLayout.NORTH);
            panelAlojamiento.add(labelNombre);
            panelAlojamiento.add(labelDescripcion);
            panelAlojamiento.add(labelDireccion);

            panelalojamientos.add(panelAlojamiento, BorderLayout.CENTER);
            panelAlojamiento.addMouseListener(new MouseAdapter() {

                @Override
                public void mouseClicked(MouseEvent e) {
                    alojamientoSeleccionado = alojamientos;
                    dispose();
                    datosguardados.setAlojamientoActual(alojamientoSeleccionado);

                    Detalles_alojamientos a = new Detalles_alojamientos();
                    a.setVisible(true);

                    System.out.println(alojamientos.getId());

                }
            });
            labelDescripcion.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    alojamientoSeleccionado = alojamientos;
                    dispose();
                    datosguardados.setAlojamientoActual(alojamientoSeleccionado);

                    Detalles_alojamientos a = new Detalles_alojamientos();
                    a.setVisible(true);

                    System.out.println(alojamientos.getId());
                }
            });
        }
        panelalojamientos.revalidate();

    }

}
