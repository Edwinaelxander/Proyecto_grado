/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_gerentes;

import controlador.Controlador_alojamiento;
import controlador.Controlador_habitacion;
import datos.datosguardados;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;
import modelo_alojamiento.alojamiento;
import modelo_habitaciones.habitacion;
import modelo_habitaciones.habitacionDao;

/**
 *
 * @author Marely
 */
public class Habitaciones extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio, alojamiento, informes, yo, registrar;
    JPanel panelhabitaciones = new JPanel(new BorderLayout());

    private habitacion habitacionselecionada;

    private JLabel tipo, precio;

    public Habitaciones() {

        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel cabecera = new JPanel(new BorderLayout());
        TitledBorder titledBorder = BorderFactory.createTitledBorder("HABITACIONES");
        titledBorder.setTitleFont(new Font("Arial", Font.BOLD, 30));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.CENTER);

        cabecera.setBorder(titledBorder);
        cabecera.setPreferredSize(new Dimension(500, 500));
        cabecera.setBackground(Color.WHITE);

        JPanel cru1 = new JPanel(new BorderLayout());

        cru1.setBackground(Color.WHITE);
        JPanel cru = new JPanel(new GridLayout(1, 3, 10, 50));
        cru.setPreferredSize(new Dimension(450, 80));

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 50));
        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));

        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima1 = new ImageIcon("alojamiento.PNG");
        alojamiento = new JButton("alojamiento", ima1);
        alojamiento.setContentAreaFilled(false);
        alojamiento.setVerticalTextPosition(JButton.BOTTOM);
        alojamiento.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("informe.PNG");
        informes = new JButton("informe", ima2);
        informes.setContentAreaFilled(false);
        informes.setVerticalTextPosition(JButton.BOTTOM);
        informes.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);

        principal.add(inicio);
        principal.add(alojamiento);
        principal.add(informes);
        principal.add(yo);

        navegador.add(principal);

        panelhabitaciones = new JPanel(new GridLayout(0, 1, 2, 10));
        cabecera.add(panelhabitaciones, BorderLayout.CENTER);
        JScrollPane scrollPane = new JScrollPane(cabecera, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        inicializar();

        registrar = new JButton("registrar habitacion");
        registrar.setBackground(Color.ORANGE);
        cabecera.add(registrar, BorderLayout.SOUTH);

        contenedor.add(scrollPane, BorderLayout.CENTER);

        contenedor.add(navegador, BorderLayout.SOUTH);
       
        
        setSize(500, 800);

        inicio.addActionListener(this);
        alojamiento.addActionListener(this);
        informes.addActionListener(this);
        yo.addActionListener(this);
        registrar.addActionListener(this);

    }

    private void inicializar() {
        habitacionDao alo = new habitacionDao();
        new GridLayout(0, 1);

        List<habitacion> Habitacion = alo.habitaciones();

        for (habitacion habitaciones : Habitacion) {
            JPanel panelHabitacion = new JPanel(new FlowLayout());
            panelHabitacion.setBorder(BorderFactory.createLineBorder(Color.BLACK));

            tipo = new JLabel("TIPO " + habitaciones.getTipo());
            float precios=habitaciones.getPrecio();
            precio = new JLabel("PRECIO: $" + precios);

            panelHabitacion.add(tipo);
            panelHabitacion.add(precio);

            panelhabitaciones.add(panelHabitacion, BorderLayout.CENTER);
            panelHabitacion.addMouseListener(new MouseAdapter() {

                @Override
                public void mouseClicked(MouseEvent e) {
                    habitacionselecionada = habitaciones;
                    dispose();
                    datosguardados.setHabitacionActual(habitacionselecionada);
                    Detalles_habitacion a = new Detalles_habitacion();
                    Controlador_habitacion b = new Controlador_habitacion(a, habitacionselecionada);
                    a.setVisible(true);

                    habitacion s = datosguardados.getHabitacionActual();
                    System.out.print(s.getHabitacionid());
                    System.out.println(habitacionselecionada.getCantidad());
                }

            });

        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == alojamiento) {
            dispose();
            Registrar_alojamiento a = new Registrar_alojamiento();
            Controlador_alojamiento b = new Controlador_alojamiento(a);
            a.setVisible(true);

        }
        if (e.getSource() == informes) {
            dispose();
            Incidente_gerente a = new Incidente_gerente();
            a.setVisible(true);

        }
        if (e.getSource() == inicio) {
            dispose();
            Principal_gerente a = new Principal_gerente();
            a.setVisible(true);
        }
        if (e.getSource() == yo) {
            dispose();
            Salir_gerente a = new Salir_gerente();
            a.setVisible(true);

        }
        if (e.getSource() == registrar) {
            dispose();
            Registrar_habitaciones a = new Registrar_habitaciones();
            Controlador_habitacion b = new Controlador_habitacion(a);
            a.setVisible(true);
        }
    }

}
