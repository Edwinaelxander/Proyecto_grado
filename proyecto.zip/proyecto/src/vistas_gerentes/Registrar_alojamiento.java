/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_gerentes;

import Db.Conexion;
import controlador.Controlador_alojamiento;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

/**
 *
 * @author Marely
 */
public class Registrar_alojamiento extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio, alojamiento, informes, yo, registrar, foto;
    public JLabel nit, telefono, nombre, correo, direccion, fo,c_habitaciones,descripcion;
    public JTextField nit_TX, nombre_TX, correo_TX, direccion_TX, telefono_TX, foto_TX,c_habitaciones_TX;
    public JTextArea descripcionarea;
    public  File archivoSeleccionado;

    public Registrar_alojamiento() {

        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 50));

        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));

        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima1 = new ImageIcon("alojamiento.PNG");
        alojamiento = new JButton("alojamiento", ima1);
        alojamiento.setContentAreaFilled(false);
        alojamiento.setVerticalTextPosition(JButton.BOTTOM);
        alojamiento.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("informe.PNG");
        informes = new JButton("informe", ima2);
        informes.setContentAreaFilled(false);
        informes.setVerticalTextPosition(JButton.BOTTOM);
        informes.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);

        principal.add(inicio);
        principal.add(alojamiento);
        principal.add(informes);
        principal.add(yo);

        navegador.add(principal);

        contenedor.add(navegador, BorderLayout.SOUTH);

        JPanel formularioregistraralojamiento = new JPanel();
        formularioregistraralojamiento.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel registraralojamiento = new JPanel(new GridLayout(17, 1, 2, 10));
        TitledBorder titledBorder = BorderFactory.createTitledBorder("REGISTRAR ALOJAMIENTO");
        titledBorder.setTitleFont(new Font("Arial", Font.BOLD, 30));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.CENTER);

        registraralojamiento.setBorder(titledBorder);
        registraralojamiento.setPreferredSize(new Dimension(450, 900));
        registraralojamiento.setBackground(Color.WHITE);

        nombre = new JLabel("nombre");
        nit = new JLabel("nit:");
        telefono = new JLabel("telefono");
        correo = new JLabel("correo");
        direccion = new JLabel("direccion");
        c_habitaciones=new JLabel("cantidad de habitaciones");
        descripcion=new JLabel("Descripcion");

        fo = new JLabel("foto del sitio");

        nombre_TX = new JTextField(10);
        nit_TX = new JTextField(10);
        telefono_TX = new JTextField(10);
        correo_TX = new JTextField(50);
        direccion_TX = new JTextField(50);
        c_habitaciones_TX=new JTextField(10);

        descripcionarea=new JTextArea(20,20);
        Icon a = new ImageIcon("imagenes.PNG");
        foto = new JButton("", a);
        registrar = new JButton("registrar");
        registrar.setBackground(Color.orange);
                JScrollPane scrollPane1 = new JScrollPane(descripcionarea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);


        registraralojamiento.add(nit);
        registraralojamiento.add(nit_TX);
        registraralojamiento.add(nombre);
        registraralojamiento.add(nombre_TX);
        registraralojamiento.add(descripcion);
        registraralojamiento.add(scrollPane1);
        registraralojamiento.add(correo);
        registraralojamiento.add(correo_TX);
        registraralojamiento.add(c_habitaciones);
        registraralojamiento.add(c_habitaciones_TX);
        registraralojamiento.add(telefono);
        registraralojamiento.add(telefono_TX);
        registraralojamiento.add(direccion);
        registraralojamiento.add(direccion_TX);
        registraralojamiento.add(fo);
        registraralojamiento.add(foto);
        registraralojamiento.add(registrar);

        formularioregistraralojamiento.add(registraralojamiento);

        JScrollPane scrollPane = new JScrollPane(formularioregistraralojamiento, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        contenedor.add(scrollPane, BorderLayout.CENTER);

       
        
        setSize(500, 800);
        inicio.addActionListener(this);
        alojamiento.addActionListener(this);
        informes.addActionListener(this);
        yo.addActionListener(this);
        foto.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == alojamiento) {
            dispose();
            Registrar_alojamiento a = new Registrar_alojamiento();
            Controlador_alojamiento b = new Controlador_alojamiento(a);
            a.setVisible(true);

        }
        if (e.getSource() == informes) {
            dispose();
            Incidente_gerente a = new Incidente_gerente();
            a.setVisible(true);

        }
        if (e.getSource() == inicio) {
            dispose();
            Principal_gerente a = new Principal_gerente();
            a.setVisible(true);
        }
        if (e.getSource() == yo) {
            dispose();
            Salir_gerente a = new Salir_gerente();
            a.setVisible(true);

        }
        
        if(e.getSource()==foto){
            JFileChooser selectorArchivos = new JFileChooser();
                int resultado = selectorArchivos.showOpenDialog(Registrar_alojamiento.this);
                if (resultado == JFileChooser.APPROVE_OPTION) {
                     archivoSeleccionado = selectorArchivos.getSelectedFile();
                  // mostrarImagen(archivoSeleccionado);
                }
        }

    }

}
