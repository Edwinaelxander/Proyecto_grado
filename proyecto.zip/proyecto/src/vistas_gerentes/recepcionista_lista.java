/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_gerentes;

import controlador.Controlador_alojamiento;
import controlador.Controlador_recepcionista;
import datos.datosguardados;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;
import modelo_alojamiento.alojamiento;
import modelo_recepcionista.Recepcionista;
import modelo_recepcionista.RecepcionistaDao;
import modelo_reserva.ReservaDao;

/**
 *
 * @author Marely
 */
public class recepcionista_lista extends JFrame implements ActionListener {
 public RecepcionistaDao dao = new RecepcionistaDao();
    private int id = 0;
    private Container contenedor;
    public JButton inicio, alojamient, informes, yo, registrar, modificar, eliminar;
    JPanel panelalojamientos = new JPanel(new BorderLayout());
    private alojamiento alojamientoSeleccionado;

    public recepcionista_lista() {
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel cabecera = new JPanel(new BorderLayout());
        TitledBorder titledBorder = BorderFactory.createTitledBorder("RECEPCIONISTAS");
        titledBorder.setTitleFont(new Font("Arial", Font.BOLD, 30));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.CENTER);

        cabecera.setBorder(titledBorder);
        cabecera.setPreferredSize(new Dimension(450, 500));
        cabecera.setBackground(Color.WHITE);

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 10));

        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));

        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima1 = new ImageIcon("alojamiento.PNG");
        alojamient = new JButton("alojamiento", ima1);
        alojamient.setContentAreaFilled(false);
        alojamient.setVerticalTextPosition(JButton.BOTTOM);
        alojamient.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("informe.PNG");
        informes = new JButton("informe", ima2);
        informes.setContentAreaFilled(false);
        informes.setVerticalTextPosition(JButton.BOTTOM);
        informes.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);

        principal.add(inicio);
        principal.add(alojamient);
        principal.add(informes);
        principal.add(yo);

        navegador.add(principal);

        contenedor.add(navegador, BorderLayout.SOUTH);
        setSize(500, 800);

        panelalojamientos = new JPanel(new GridLayout(0, 2, 10, 10));

        panelalojamientos.setBackground(Color.WHITE);
        cabecera.add(panelalojamientos, BorderLayout.CENTER);

        registrar = new JButton("registar recepcionistas");
        registrar.setBackground(Color.orange);
        registrar.addActionListener(this);
        registrar.setPreferredSize(new Dimension(400, 60));
        cabecera.add(registrar, BorderLayout.SOUTH);

        JScrollPane scrollPane = new JScrollPane(panelalojamientos, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        cabecera.add(scrollPane);
        inicializar();
        contenedor.add(cabecera, BorderLayout.CENTER);

        inicio.addActionListener(this);
        alojamient.addActionListener(this);
        informes.addActionListener(this);
        yo.addActionListener(this);

    }

    private void inicializar() {
        RecepcionistaDao dao = new RecepcionistaDao();

        List<Recepcionista> recepcionista = dao.recepcionistas();

        for (Recepcionista recepcionistas : recepcionista) {
            JPanel panelAlojamiento = new JPanel(new GridLayout(5, 1));

            panelAlojamiento.setBorder(BorderFactory.createLineBorder(Color.BLACK));

            JLabel nombre = new JLabel("NOMBRE: " + recepcionistas.getNombre());
            JLabel cedula = new JLabel("CEDULA: " + recepcionistas.getCedula());
            JLabel correo = new JLabel("CORREO: " + recepcionistas.getCorreo());
            JLabel telefono = new JLabel("TELEFONO: " + recepcionistas.getTelefono());
            id = recepcionistas.getRecepcionistaid();
            String contraseña1 = recepcionistas.getContraseña();
            modificar = new JButton("modificar");

            eliminar = new JButton("eliminar");
            eliminar.setBackground(Color.red.brighter());

            JPanel crud = new JPanel(new GridLayout(1, 2));
            crud.add(modificar);
            crud.add(eliminar);

            panelAlojamiento.add(nombre);
            panelAlojamiento.add(cedula);
            panelAlojamiento.add(correo);
            panelAlojamiento.add(telefono);
            panelAlojamiento.add(crud);

            panelalojamientos.add(panelAlojamiento, BorderLayout.CENTER);
            modificar.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    int idRecepcionista = recepcionistas.getRecepcionistaid();
                    String correo = recepcionistas.getCorreo();
                    String contraseña = contraseña1;
                    String telefono = recepcionistas.getTelefono();
                    Recepcionista re = new Recepcionista();
                    re.setContraseña(contraseña);
                    re.setCorreo(correo);
                    re.setRecepcionistaid(idRecepcionista);
                    re.setTelefono(telefono);
                    datosguardados.setRecepcionistaactual(re);

                    Modificar_recepcionista a = new Modificar_recepcionista();
                    Controlador_recepcionista b = new Controlador_recepcionista(a);
                    a.setVisible(true);

                    System.out.println(contraseña);
                }
            });

            eliminar.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    int resultado = JOptionPane.showConfirmDialog(null, "¿Estás seguro de querer ihnabilitar este recepcionista?", "Confirmación", JOptionPane.YES_NO_OPTION);
                    if (resultado == JOptionPane.YES_OPTION) {
                        int idRecepcionista = recepcionistas.getRecepcionistaid();
                        System.out.println(idRecepcionista);
                        Recepcionista re = new Recepcionista();
                        re.setRecepcionistaid(idRecepcionista);
                        int resultado2 = dao.inhabilitarrecepcionista(re);
                        if (resultado2 == 1) {
                            JOptionPane.showMessageDialog(null, "eliminacion exitosamente");
                        }
                    }
                }
                }
            );

            }
        panelalojamientos.revalidate();
        }

        @Override
        public void actionPerformed
        (ActionEvent e
        
        
            ) {
        if (e.getSource() == alojamient) {
                dispose();
                Registrar_alojamiento a = new Registrar_alojamiento();
                Controlador_alojamiento b = new Controlador_alojamiento(a);
                a.setVisible(true);

            }
            if (e.getSource() == informes) {
                dispose();
                Incidente_gerente a = new Incidente_gerente();
                a.setVisible(true);

            }
            if (e.getSource() == inicio) {
                dispose();
                Principal_gerente a = new Principal_gerente();
                a.setVisible(true);
            }
            if (e.getSource() == yo) {
                dispose();
                Salir_gerente a = new Salir_gerente();
                a.setVisible(true);

            }
            if (e.getSource() == registrar) {
                dispose();
                registrar_recepcionista a = new registrar_recepcionista();
                Controlador_recepcionista b = new Controlador_recepcionista(a);
                a.setVisible(true);
            }

        }

    }
