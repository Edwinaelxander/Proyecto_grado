/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_gerentes;

import controlador.Controlador_alojamiento;
import datos.datosguardados;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;
import modelo_alojamiento.alojamiento;
import modelo_incidentes.Incidente;
import modelo_pqrs.Pqrs;

/**
 *
 * @author Marely
 */
public class Detalles_incidente extends JFrame implements ActionListener{
    
    private Container contenedor;
    public JButton inicio, alojamiento, informes, yo,enviar;
    private JLabel responde;
    public  JTextArea mensaje;
    JPanel panelinformes =new JPanel(new BorderLayout());
     Incidente i;

    public Detalles_incidente(Incidente informe1) {
          contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel cabecera = new JPanel(new BorderLayout());

        
        JPanel responder = new JPanel(new GridLayout(3, 1, 10, 10));
        responder.setPreferredSize(new Dimension(450, 300));
        responder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        
        JPanel principal1 = new JPanel(new GridLayout(1, 4, 10, 10));
        TitledBorder titledBorder = BorderFactory.createTitledBorder("informe");
        titledBorder.setTitleFont(new Font("Arial", Font.BOLD, 30));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.CENTER);

        cabecera.setBorder(titledBorder);
        cabecera.setPreferredSize(new Dimension(450, 500));
        cabecera.setBackground(Color.WHITE);

       

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 50));
        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(400, 100));

        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima1 = new ImageIcon("alojamiento.PNG");
        alojamiento = new JButton("alojamiento", ima1);
        alojamiento.setContentAreaFilled(false);
        alojamiento.setVerticalTextPosition(JButton.BOTTOM);
        alojamiento.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("informe.PNG");
        informes = new JButton("informe", ima2);
        informes.setContentAreaFilled(false);
        informes.setVerticalTextPosition(JButton.BOTTOM);
        informes.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);
        
       principal.add(inicio);
        principal.add(alojamiento);
        principal.add(informes);
        principal.add(yo);
        navegador.add(principal);
        contenedor.add(navegador, BorderLayout.SOUTH);
        
        responde=new JLabel("responder");
        mensaje=new JTextArea(10,20);
        enviar=new JButton("enviar");

        responder.add(responde);
        responder.add(mensaje);
        responder.add(enviar);
        
          panelinformes = new JPanel(new GridLayout(0, 1, 2, 10));
        JScrollPane scrollPane = new JScrollPane(cabecera, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        cabecera.add(panelinformes,BorderLayout.NORTH);
        cabecera.add(responder,BorderLayout.SOUTH);
        
        
        inicializar(informe1);
        contenedor.add(scrollPane, BorderLayout.CENTER);
        
        
        
       
        setSize(500, 800);
        inicio.addActionListener(this);
        alojamiento.addActionListener(this);
        informes.addActionListener(this);
        yo.addActionListener(this);
        enviar.addActionListener(this);

    }
    
      private void inicializar(Incidente informe1) {
       
           
        JLabel labelId = new JLabel("INFORME #: " + informe1.getIncidenteid());
        JLabel labelDescripcion = new JLabel("DESCRIPCION: " + informe1.getDescripcion());

        JPanel panelDetalles = new JPanel(new GridLayout(2, 1));
        panelDetalles.add(labelId);
        panelDetalles.add(labelDescripcion);

        panelinformes.add(panelDetalles, BorderLayout.NORTH);

       

    }

    @Override
    public void actionPerformed(ActionEvent e) {
   if (e.getSource() == alojamiento) {
            dispose();
            Registrar_alojamiento a = new Registrar_alojamiento();
            Controlador_alojamiento b = new Controlador_alojamiento(a);
            a.setVisible(true);

        }
        if (e.getSource() == informes) {
            dispose();
            Incidente_gerente a = new Incidente_gerente();
            a.setVisible(true);

        }
        if (e.getSource() == inicio) {
            dispose();
            Principal_gerente a = new Principal_gerente();
            a.setVisible(true);
        }
        if (e.getSource() == yo) {
            dispose();
            Salir_gerente a = new Salir_gerente();
            a.setVisible(true);
    }

    
    }
    
    
}
