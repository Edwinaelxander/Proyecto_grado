/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_gerentes;

import Db.Conexion;
import controlador.Controlador_alojamiento;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

/**
 *
 * @author Marely
 */
public class Registrar_habitaciones extends JFrame implements ActionListener{

    private Container contenedor;
    public JButton inicio, alojamiento, informes, yo, registrar, foto;
    public JLabel tipo,vista,cantidad,precio,servicio,c_habitaciones;
    public JTextField tipo_TX,vista_TX,cantidad_TX,precio_TX,c_habitaciones_TX;
    public JTextArea areaservicios ;

    public Registrar_habitaciones() {
        Conexion con = new Conexion();
        con.getCon();
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 50));
        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));

        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima1 = new ImageIcon("alojamiento.PNG");
        alojamiento = new JButton("alojamiento", ima1);
        alojamiento.setContentAreaFilled(false);
        alojamiento.setVerticalTextPosition(JButton.BOTTOM);
        alojamiento.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("informe.PNG");
        informes = new JButton("informe", ima2);
        informes.setContentAreaFilled(false);
        informes.setVerticalTextPosition(JButton.BOTTOM);
        informes.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);

        principal.add(inicio);
        principal.add(alojamiento);
        principal.add(informes);
        principal.add(yo);

        navegador.add(principal);

        contenedor.add(navegador, BorderLayout.SOUTH);

        JPanel formularioregistraralojamiento = new JPanel();
        formularioregistraralojamiento.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel registraralojamiento = new JPanel(new GridLayout(7, 6, 2, 10));
        TitledBorder titledBorder = BorderFactory.createTitledBorder("REGISTRAR HABITACIONES");
        titledBorder.setTitleFont(new Font("Arial", Font.BOLD, 30));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.CENTER);

        registraralojamiento.setBorder(titledBorder);
        registraralojamiento.setPreferredSize(new Dimension(450, 600));
        registraralojamiento.setBackground(Color.WHITE);

        vista = new JLabel("tipo de vista");
        tipo = new JLabel("tipo de habitacion:");
        cantidad = new JLabel("cantidad de huespedes");
        precio=new JLabel("precio");
        servicio=new JLabel("incluye");
        c_habitaciones=new JLabel("cantidad de habitaciones");
     
      

        vista_TX= new JTextField(10);
        tipo_TX= new JTextField(10);
        cantidad_TX = new JTextField(10);
        precio_TX = new JTextField(50);
        c_habitaciones_TX=new JTextField(50);

         areaservicios = new JTextArea(12, 1);
        JScrollPane scrollPane1 = new JScrollPane(areaservicios, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

      
        registrar = new JButton("registrar");
        registrar.setBackground(Color.orange);

        registraralojamiento.add(tipo);
        registraralojamiento.add(tipo_TX);
        registraralojamiento.add(vista);
        registraralojamiento.add(vista_TX);
        registraralojamiento.add(cantidad);
        registraralojamiento.add(cantidad_TX);
        registraralojamiento.add(precio);
        registraralojamiento.add(precio_TX);
        registraralojamiento.add(servicio);        
        registraralojamiento.add(scrollPane1);
        registraralojamiento.add(c_habitaciones);
        registraralojamiento.add(c_habitaciones_TX);
        registraralojamiento.add(registrar);
        
       
        

        formularioregistraralojamiento.add(registraralojamiento);

        JScrollPane scrollPane = new JScrollPane(formularioregistraralojamiento, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        contenedor.add(scrollPane, BorderLayout.CENTER);

       
        setSize(500, 800);
     inicio.addActionListener(this);
        alojamiento.addActionListener(this);
        informes.addActionListener(this);
        yo.addActionListener(this);
        registrar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
          if (e.getSource() == alojamiento) {
            dispose();
            Registrar_alojamiento a = new Registrar_alojamiento();
            Controlador_alojamiento b=new Controlador_alojamiento(a);
            a.setVisible(true);

        }
        if (e.getSource() == informes) {
            dispose();
            Incidente_gerente a = new Incidente_gerente();
            
            a.setVisible(true);

        }
        if(e.getSource()==inicio){
            dispose();
            Principal_gerente a=new Principal_gerente();
            a.setVisible(true);
        }
        if(e.getSource()==yo){
            dispose();
            Salir_gerente a=new Salir_gerente();
            a.setVisible(true);
            
        }

    }

}
