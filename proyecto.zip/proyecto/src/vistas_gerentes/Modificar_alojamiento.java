/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_gerentes;

import controlador.Controlador_alojamiento;
import datos.datosguardados;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import modelo_alojamiento.alojamiento;

/**
 *
 * @author Marely
 */
public class Modificar_alojamiento extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio, alojamiento, informes, yo, modificar, confirmar, cancelar;
    public JLabel telefono, nombre, correo, descripcion;
    public JTextField nombre_TX, correo_TX, telefono_TX, descripcion_TX;

    public Modificar_alojamiento() {

        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 50));

        JPanel navegador = new JPanel();
//        navegador.setBackground(Color.WHITE);
        principal.setPreferredSize(new Dimension(450, 100));

        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima1 = new ImageIcon("alojamiento.PNG");
        alojamiento = new JButton("alojamiento", ima1);
        alojamiento.setContentAreaFilled(false);
        alojamiento.setVerticalTextPosition(JButton.BOTTOM);
        alojamiento.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("informe.PNG");
        informes = new JButton("informe", ima2);
        informes.setContentAreaFilled(false);
        informes.setVerticalTextPosition(JButton.BOTTOM);
        informes.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);

        principal.add(inicio);
        principal.add(alojamiento);
        principal.add(informes);
        principal.add(yo);

        navegador.add(principal);

        contenedor.add(navegador, BorderLayout.SOUTH);

        JPanel cabecera = new JPanel();
        cabecera.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        TitledBorder titledBorder = BorderFactory.createTitledBorder("MODIFICAR ALOJAMIENTO");
        titledBorder.setTitleFont(new Font("Arial", Font.BOLD, 30));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.CENTER);
        cabecera.setBorder(titledBorder);
        cabecera.setPreferredSize(new Dimension(500, 700));
        cabecera.setBackground(Color.WHITE);

        JPanel modificaralojamiento = new JPanel(new GridLayout(11, 1, 5, 10));
        modificaralojamiento.setPreferredSize(new Dimension(450, 550));
        modificaralojamiento.setBackground(Color.WHITE);

        nombre = new JLabel("nombre");
        correo = new JLabel("correo");
        telefono = new JLabel("telefono");
        descripcion = new JLabel("descripcion");
        alojamiento alo = datosguardados.getAlojamientoActual();

        nombre_TX = new JTextField(10);
        nombre_TX.setText(alo.getNombre());
        nombre_TX.setEditable(false);
        correo_TX = new JTextField(10);
        correo_TX.setText(alo.getCorreo());
        correo_TX.setEditable(false);
        telefono_TX = new JTextField(10);
        telefono_TX.setText(alo.getTelefono());
        telefono_TX.setEditable(false);
        descripcion_TX = new JTextField();
        descripcion_TX.setText(alo.getDescripcion());
        descripcion_TX.setEditable(false);

        confirmar = new JButton("Confirmar");
        confirmar.setVisible(false);
        confirmar.setBackground(Color.orange);
        cancelar = new JButton("Cancelar");
        cancelar.setVisible(false);
        cancelar.addActionListener(this);

        modificar = new JButton("modificar");

        modificaralojamiento.add(nombre);
        modificaralojamiento.add(nombre_TX);
        modificaralojamiento.add(descripcion);
        modificaralojamiento.add(descripcion_TX);
        modificaralojamiento.add(correo);
        modificaralojamiento.add(correo_TX);
        modificaralojamiento.add(telefono);
        modificaralojamiento.add(telefono_TX);
        modificaralojamiento.add(confirmar);
        modificaralojamiento.add(cancelar);
        modificaralojamiento.add(modificar);
        cabecera.add(modificaralojamiento);

        contenedor.add(cabecera, BorderLayout.CENTER);

        setSize(500, 800);
        inicio.addActionListener(this);
        alojamiento.addActionListener(this);
        informes.addActionListener(this);
        yo.addActionListener(this);
        modificar.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == alojamiento) {
            dispose();
            Registrar_alojamiento a = new Registrar_alojamiento();
            Controlador_alojamiento b = new Controlador_alojamiento(a);
            a.setVisible(true);

        }
        if (e.getSource() == informes) {
            dispose();
            Incidente_gerente a = new Incidente_gerente();
            a.setVisible(true);

        }
        if (e.getSource() == inicio) {
            dispose();
            Principal_gerente a = new Principal_gerente();
            a.setVisible(true);
        }
        if (e.getSource() == yo) {
            dispose();
            Salir_gerente a = new Salir_gerente();
            a.setVisible(true);

        }

        if (e.getSource() == modificar) {
            nombre_TX.setEditable(true);
            correo_TX.setEditable(true);
            telefono_TX.setEditable(true);
            descripcion_TX.setEditable(true);
            confirmar.setVisible(true);
            cancelar.setVisible(true);
        }
        if (e.getSource() == cancelar) {
            nombre_TX.setEditable(false);
            correo_TX.setEditable(false);
            telefono_TX.setEditable(false);
            descripcion_TX.setEditable(false);

            confirmar.setVisible(false);
            cancelar.setVisible(false);
        }
    }

}
