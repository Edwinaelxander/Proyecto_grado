/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_gerentes;

import controlador.Controlador_alojamiento;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

/**
 *
 * @author Marely
 */
public class registrar_recepcionista extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio, alojamient, informes, yo, registrar;
    public JLabel nombre, cedula, correo, telefono, contraseña;
    public JTextField nombre_TX, cedula_TX, correo_TX, telefono_TX, contraseña_TX;

    public registrar_recepcionista() {
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel cabecera = new JPanel(new BorderLayout());
        TitledBorder titledBorder = BorderFactory.createTitledBorder("RECEPCIONISTAS");
        titledBorder.setTitleFont(new Font("Arial", Font.BOLD, 30));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.CENTER);

        cabecera.setBorder(titledBorder);
        cabecera.setPreferredSize(new Dimension(450, 500));
        cabecera.setBackground(Color.WHITE);

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 10));

        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));

        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima1 = new ImageIcon("alojamiento.PNG");
        alojamient = new JButton("alojamiento", ima1);
        alojamient.setContentAreaFilled(false);
        alojamient.setVerticalTextPosition(JButton.BOTTOM);
        alojamient.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("informe.PNG");
        informes = new JButton("informe", ima2);
        informes.setContentAreaFilled(false);
        informes.setVerticalTextPosition(JButton.BOTTOM);
        informes.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);

        principal.add(inicio);
        principal.add(alojamient);
        principal.add(informes);
        principal.add(yo);

        navegador.add(principal);

        contenedor.add(navegador, BorderLayout.SOUTH);

        JPanel register = new JPanel(new GridLayout(11, 1));
        registrar = new JButton("registrar");

        nombre = new JLabel("NOMBRE: ");
        cedula = new JLabel("CEDULA: ");
        correo = new JLabel("CORREO: ");
        telefono = new JLabel("TELEFONO: ");
        contraseña = new JLabel("CONTRASEÑA");

        nombre_TX = new JTextField();
        cedula_TX = new JTextField();
        correo_TX = new JTextField();
        telefono_TX = new JTextField();
        contraseña_TX = new JTextField();

        register.add(nombre);
        register.add(nombre_TX);
        register.add(cedula);
        register.add(cedula_TX);
        register.add(telefono);
        register.add(telefono_TX);
        register.add(correo);
        register.add(correo_TX);
        register.add(contraseña);
        register.add(contraseña_TX);
        register.add(registrar);
        cabecera.add(register);

        contenedor.add(cabecera, BorderLayout.CENTER);
        setSize(500, 800);
        inicio.addActionListener(this);
        alojamient.addActionListener(this);
        informes.addActionListener(this);
        yo.addActionListener(this);

    }

    public static void main(String[] args) {
        registrar_recepcionista a = new registrar_recepcionista();
        a.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == alojamient) {
            dispose();
            Registrar_alojamiento a = new Registrar_alojamiento();
            Controlador_alojamiento b = new Controlador_alojamiento(a);
            a.setVisible(true);

        }
        if (e.getSource() == informes) {
            dispose();
            Incidente_gerente a = new Incidente_gerente();
            a.setVisible(true);

        }
        if (e.getSource() == inicio) {
            dispose();
            Principal_gerente a = new Principal_gerente();
            a.setVisible(true);
        }
        if (e.getSource() == yo) {
            dispose();
            Salir_gerente a = new Salir_gerente();
            a.setVisible(true);

        }
    }
}
