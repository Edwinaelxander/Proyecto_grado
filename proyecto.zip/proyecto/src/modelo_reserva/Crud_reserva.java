/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package modelo_reserva;

import java.util.List;

/**
 *
 * @author Marely
 */
public interface Crud_reserva<reserva> {
    public int agregarreserva(Reserva tr);
    public int modificarreserva(Reserva tr);
    public int modificarestadoreserva(int a);
    public List<Reserva> reserva(int a);
    
}
