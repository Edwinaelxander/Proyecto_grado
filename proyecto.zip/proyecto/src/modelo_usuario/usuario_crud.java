/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_usuario;

/**
 *
 * @author Marely
 */
public interface usuario_crud {
    
    public int setagregarusuari(Usuario tr);
    public int setmodificarusuari(Usuario tr);
    public int setinactivarusuari(Usuario tr);
    public int setbuscar(Usuario tr);
    public int setbuscar1(Usuario tr);
    
}
