/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_usuario;

import Db.Conexion;
import datos.datosguardados;
import inicios_gui.Inicio;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import modelo_gerente.gerente;

/**
 *
 * @author Marely
 */
public class usuarioDao implements usuario_crud {

    Conexion conetion = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    @Override
    public int setagregarusuari(Usuario tr) {
        String sql = "INSERT INTO usuarioregistrado (nombre, cedula, telefono, `correo electronico`, contraseña, estado) VALUES(?,?,?,?,?,?)";

        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ps.setString(1, tr.getNombre());
            ps.setInt(2, tr.getCedula());
            ps.setString(3, tr.getTelefono());
            ps.setString(4, tr.getCorre());
            ps.setString(5, tr.getContraseña());
            ps.setInt(6, 0);
            ps.executeUpdate();
            return 1;
        } catch (java.sql.SQLIntegrityConstraintViolationException e) {

            return 3;
        } catch (Exception q) {
            q.printStackTrace();
            JOptionPane.showMessageDialog(null, q.toString(), "error de insercion" + q.getMessage(), JOptionPane.ERROR_MESSAGE);
            return 0;
        }
    }

    @Override
    public int setmodificarusuari(Usuario tr) {
        String sql = "UPDATE usuarioregistrado SET Nombre=?, telefono=?,  `correo electronico`=?, contraseña=?  WHERE  UsuarioID=?";
        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            Usuario usu = datosguardados.getUsuarioactual();

            ps.setString(1, tr.getNombre());
            ps.setString(2, tr.getTelefono());
            ps.setString(3, tr.getCorre());
            ps.setString(4, tr.getContraseña());
            ps.setInt(5, usu.getIdusuario());

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {

                datosguardados.setUsuarioactual(tr);
                return 1;
            } else {
                return 0;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "error de actualiacion 1 " + e.getMessage(), JOptionPane.ERROR_MESSAGE);
            return 0;
        }
    }

    @Override
    public int setinactivarusuari(Usuario tr) {
        String sql = "UPDATE usuarioregistrado SET estado=?  WHERE `correo electronico`=?";

        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ps.setInt(1, 1);
            ps.setString(2, tr.getCorre());

            ps.executeUpdate();
            return 1;

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "error de eliminacion" + e.getMessage(), JOptionPane.ERROR_MESSAGE);
            return 0;
        }
    }

    @Override
    public int setbuscar(Usuario tr) {
        String sql = "SELECT * FROM usuarioregistrado WHERE `correo electronico`=? AND contraseña=? AND estado=0";
        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ps.setString(1, tr.getCorre());
            ps.setString(2, tr.getContraseña());

            rs = ps.executeQuery();
            if (rs.next()) {

                tr.setIdusuario(rs.getInt("UsuarioID"));
                tr.setNombre(rs.getString("nombre"));
                tr.setTelefono(rs.getString("telefono"));
                tr.setCorre(rs.getString("correo electronico"));
                tr.setContraseña(rs.getString("contraseña"));

                datosguardados.setUsuarioactual(tr);

                return 1;

            } else {
                return 0;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "error de busquedad" + e.getMessage(), JOptionPane.ERROR_MESSAGE);
            return 0;
        }

    }

    @Override
    public int setbuscar1(Usuario tr) {
        String sql = "SELECT * FROM usuarioregistrado WHERE `correo electronico`=?";
        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ps.setString(1, tr.getCorre());

            rs = ps.executeQuery();
            if (rs.next()) {

                return 1;
            } else {

                return 0;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "error de busquedad" + e.getMessage(), JOptionPane.ERROR_MESSAGE);
            return 0;
        }
    }

    public int tbuscarcorreo(Usuario usu) {
        String sql = "SELECT * FROM usuarioregistrado WHERE `correo electronico`=? AND cedula=?";
        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ps.setString(1, usu.getCorre());
            ps.setInt(2, usu.getCedula());

            rs = ps.executeQuery();
            if (rs.next()) {

                return 1;
            } else {
                return 0;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "error de busquedad" + e.getMessage(), JOptionPane.ERROR_MESSAGE);
            return 0;
        }
    }

    public int modificarusuario(Usuario s) {
        String sql = "UPDATE usuarioregistrado SET contraseña=?  WHERE  cedula=?";
        try {
            Usuario u = datosguardados.getUsuarioactual();
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ps.setString(1, s.getContraseña());
            ps.setInt(2, u.getCedula());

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                String sqlSelect = "SELECT * FROM usuarioregistrado WHERE cedula=?";
                ps = con.prepareStatement(sqlSelect);
                ps.setInt(1, u.getCedula());
               rs = ps.executeQuery();

                if (rs.next()) {

                    s.setIdusuario(rs.getInt("UsuarioID"));
                    s.setNombre(rs.getString("nombre"));
                    s.setTelefono(rs.getString("telefono"));
                    s.setCorre(rs.getString("correo electronico"));
                    s.setContraseña(rs.getString("contraseña"));

                    datosguardados.setUsuarioactual(s);
                    return 1;
                } else {
                    return 0;
                }

            } else {
                return 0;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "error de busquedad 11" + e.getMessage(), JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            return 0;
        }

    }

}
