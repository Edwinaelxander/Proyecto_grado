/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_usuario;

import controlador.Controlador_pagar;
import efectos.Botonhover;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import modelo_alojamiento.alojamiento;
import modelo_habitaciones.habitacion;
import modelo_reserva.Reserva;
import modelo_reserva.ReservaDao;
import org.jdesktop.swingx.JXDatePicker;

/**
 *
 * @author Marely
 */
public class Detalle_miviaje_usuario extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio, descubrir, viaje, yo, pagar, cancelar, modificar, confirmar, cancelarf;
    public JLabel   numhabitaciones,habitacionlabel;
    public JLabel ID ,fechaEntradaLabel, fechaSalidaLabel, tipoHabitacionLabel, vistaHabitacionLabel, precioHabitacionLabel, nombreAlojamientoLabel, direccionAlojamientoLabel;
    public JTextField tipoHabitacion, vistaHabitacion,habitacion, precioHabitacion, nombreAlojamiento, direccionAlojamiento,   numHabitaciones1;
    JPanel paneldescripcion = new JPanel(new BorderLayout());
    public JXDatePicker fechaSalida, fechaEntrada;
    Reserva reserva = new Reserva();
    alojamiento aloja = new alojamiento();
    habitacion hab = new habitacion();
    public int num;

    public Detalle_miviaje_usuario(int num) {
        this.num = num;
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel cabecera = new JPanel(new BorderLayout());
        cabecera.setPreferredSize(new Dimension(450, 600));
        cabecera.setBackground(Color.WHITE);
        cabecera.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 10));
        principal.setBackground(Color.white);
        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));
        navegador.setBackground(Color.white);
        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima1 = new ImageIcon("buscar.PNG");
        descubrir = new JButton("buscar", ima1);
        descubrir.setContentAreaFilled(false);
        descubrir.setVerticalTextPosition(JButton.BOTTOM);
        descubrir.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("corazon.PNG");
        viaje = new JButton("mi viaje", ima2);
        viaje.setContentAreaFilled(false);
        viaje.setVerticalTextPosition(JButton.BOTTOM);
        viaje.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);

        inicio.addActionListener(this);
        descubrir.addActionListener(this);
        viaje.addActionListener(this);
        yo.addActionListener(this);
        viaje.setBorderPainted(false);
        descubrir.setBorderPainted(false);
        yo.setBorderPainted(false);
        inicio.setBorderPainted(false);

        principal.add(inicio);
        principal.add(descubrir);
        principal.add(viaje);
        principal.add(yo);
        Botonhover efectoHover = new Botonhover(principal);
        efectoHover.aplicarEfectoHover();

        navegador.add(principal);
        contenedor.add(navegador, BorderLayout.SOUTH);

        pagar = new JButton("Pagar");
        pagar.setVisible(false);
        pagar.addActionListener(this);

        cancelar = new JButton("Cancelar reserva");
        cancelar.setVisible(false);
        cancelar.addActionListener(this);

        modificar = new JButton("Modificar");
        modificar.setVisible(false);
        modificar.addActionListener(this);

        confirmar = new JButton("Confirmar");
        confirmar.setVisible(false);
        confirmar.addActionListener(this);

        cancelarf = new JButton("Cancelar");
        cancelarf.setVisible(false);
        cancelarf.addActionListener(this);

        paneldescripcion = new JPanel(new GridLayout(0, 1));
        cabecera.add(paneldescripcion);
        JScrollPane scrollPane = new JScrollPane(cabecera, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        contenedor.add(scrollPane, BorderLayout.CENTER);
        detallesreserva();

        setSize(500, 800);
    }

    public static void main(String[] args) {
        Detalle_miviaje_usuario a = new Detalle_miviaje_usuario(1);
        a.setVisible(true);
    }

    private void detallesreserva() {

        
       ID=new JLabel(""); 
        fechaEntradaLabel = new JLabel("Fecha de Entrada: ");
        fechaSalidaLabel = new JLabel("Fecha de Salida: ");
        
        numhabitaciones = new JLabel("Numero de habitacion: ");
        tipoHabitacionLabel = new JLabel("Tipo de Habitación: ");
        vistaHabitacionLabel = new JLabel("Vista de la Habitación: ");
        precioHabitacionLabel = new JLabel("Precio de la Habitación: ");
        nombreAlojamientoLabel = new JLabel("Nombre del Alojamiento: ");
        direccionAlojamientoLabel = new JLabel("Dirección del Alojamiento: ");

        fechaEntrada = new JXDatePicker();
        fechaEntrada.setDate(new Date());
        fechaEntrada.setFormats(new SimpleDateFormat("dd/MM/yyyy"));
        fechaSalida = new JXDatePicker();
        fechaSalida.setDate(new Date());
        fechaSalida.setFormats(new SimpleDateFormat("dd/MM/yyyy"));
        tipoHabitacion = new JTextField();
        vistaHabitacion = new JTextField();
        precioHabitacion = new JTextField();
        nombreAlojamiento = new JTextField();
        direccionAlojamiento = new JTextField();
        
     
        numHabitaciones1 = new JTextField();
        fechaEntrada.setEditable(false);
        fechaSalida.setEditable(false);
        tipoHabitacion.setEditable(false);
        vistaHabitacion.setEditable(false);
        precioHabitacion.setEditable(false);
        nombreAlojamiento.setEditable(false);
        direccionAlojamiento.setEditable(false);
        
        
        numHabitaciones1.setEditable(false);

        JPanel crud = new JPanel(new GridLayout(1, 3));

        crud.add(modificar);
        crud.add(pagar);
        crud.add(cancelar);

        JPanel panel = new JPanel(new GridLayout(19, 1));
        
      
        panel.add(fechaEntradaLabel);
        panel.add(fechaEntrada);
        panel.add(fechaSalidaLabel);
        panel.add(fechaSalida);
    
        panel.add(numhabitaciones);
        panel.add(numHabitaciones1);
        panel.add(tipoHabitacionLabel);
        panel.add(tipoHabitacion);
        panel.add(vistaHabitacionLabel);
        panel.add(vistaHabitacion);
        panel.add(precioHabitacionLabel);
        panel.add(precioHabitacion);
        panel.add(nombreAlojamientoLabel);
        panel.add(nombreAlojamiento);
        panel.add(direccionAlojamientoLabel);
        panel.add(direccionAlojamiento);
        panel.add(confirmar);
        panel.add(cancelarf);
        panel.add(crud);

        if (num == 1) {
            pagar.setVisible(true);
             modificar.setVisible(true);

        }
        if (num == 2) {
            cancelar.setVisible(true);
           

        }
        cancelarf.addActionListener(this);

        paneldescripcion.add(panel, BorderLayout.CENTER);

    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == inicio) {
            dispose();
            inicio_usuario a = new inicio_usuario();
            a.setVisible(true);
        }

        if (e.getSource() == yo) {
            dispose();
            perfil a = new perfil();
            a.setVisible(true);
        }
        if (e.getSource() == viaje) {
            dispose();
            miviaje_usuario a = new miviaje_usuario();
            a.setVisible(true);
        }
        if (e.getSource() == pagar) {
            dispose();
            pagar_usuario a = new pagar_usuario();
            Controlador_pagar b = new Controlador_pagar(a);
            a.setVisible(true);
        }

        if (e.getSource() == modificar) {
            confirmar.setVisible(true);
            fechaEntrada.setEditable(true);
            fechaSalida.setEditable(true);
          
            
            
            modificar.setVisible(false);
            pagar.setVisible(false);
            cancelarf.setVisible(true);

        }
        
        if(e.getSource()==cancelarf){
              confirmar.setVisible(false);
            fechaEntrada.setEditable(false);
            fechaSalida.setEditable(false);
            
            
            
            modificar.setVisible(true);
            pagar.setVisible(true);
            cancelarf.setVisible(false);
        }
        

    }
}
