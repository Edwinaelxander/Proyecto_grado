/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_usuario;

import controlador.Controlador_pqrs;
import controlador.Controlador_usuarios;
import datos.datosguardados;
import efectos.Botonhover;
import inicios_gui.Inicio;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import modelo_pqrs.Pqrs;
import modelo_usuario.Usuario;

/**
 *
 * @author Marely
 */
public class perfil extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio, descubrir, viaje, yo, cerrar, informacion, compartir, puntos, configuracion, pqrs;

    public perfil() {

        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 10));

        JPanel navegador = new JPanel();
       principal.setBackground(Color.white);
        principal.setPreferredSize(new Dimension(450, 100));
        navegador.setBackground(Color.white);
     
          Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima1 = new ImageIcon("buscar.PNG");
        descubrir = new JButton("buscar", ima1);
        descubrir.setContentAreaFilled(false);
        descubrir.setVerticalTextPosition(JButton.BOTTOM);
        descubrir.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("corazon.PNG");
        viaje = new JButton("mi viaje", ima2);
        viaje.setContentAreaFilled(false);
        viaje.setVerticalTextPosition(JButton.BOTTOM);
        viaje.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);
        
        inicio.addActionListener(this);
        descubrir.addActionListener(this);
        viaje.addActionListener(this);
        yo.addActionListener(this);

        viaje.setBorderPainted(false);
        descubrir.setBorderPainted(false);
        yo.setBorderPainted(false);
        inicio.setBorderPainted(false);

        principal.add(inicio);
        principal.add(descubrir);
        principal.add(viaje);
        principal.add(yo);
        Botonhover efectoHover = new Botonhover(principal);
        efectoHover.aplicarEfectoHover();

        navegador.add(principal);
        contenedor.add(navegador, BorderLayout.SOUTH);

        JPanel cabecera = new JPanel(new BorderLayout());

        JPanel perfil = new JPanel(new GridLayout(6, 1));

        Icon ima4 = new ImageIcon("persona.PNG");
        Icon ima5 = new ImageIcon("compartir.PNG");
        Icon ima6 = new ImageIcon("cupon.PNG");
        Icon ima7 = new ImageIcon("configuracion.PNG");
        Icon ima8 = new ImageIcon("pqrs.PNG");

        informacion = new JButton("informacion personal", ima4);
        informacion.addActionListener(this);
        compartir = new JButton("compartir reserva", ima5);
        puntos = new JButton("puntos y cupones", ima6);
        configuracion = new JButton("configuracion", ima7);
        pqrs = new JButton("PQRS", ima8);
        pqrs.addActionListener(this);
        cerrar = new JButton("cerrar sesion");
        cerrar.setBackground(Color.red);
        cerrar.addActionListener(this);
        Usuario a=datosguardados.getUsuarioactual();
        if(a==null){
            cerrar.setText("Iniciar sesion");
            cerrar.setBackground(Color.orange);
        }

        perfil.add(informacion);
        perfil.add(compartir);
        perfil.add(puntos);
        perfil.add(configuracion);
        perfil.add(pqrs);
        perfil.add(cerrar);
        cabecera.add(perfil);

        contenedor.add(cabecera, BorderLayout.CENTER);

        setSize(500, 800);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == inicio) {
            dispose();
            inicio_usuario a = new inicio_usuario();
            a.setVisible(true);
        }

        if (e.getSource() == informacion) {
            dispose();
            datos_usuario a = new datos_usuario();
            Controlador_usuarios b=new Controlador_usuarios(a);
            a.setVisible(true);
        }
        if (e.getSource() == cerrar) {
            dispose();
            Usuario u=new Usuario();
            u=null;
            datosguardados.setUsuarioactual(u);
            Inicio a = new Inicio();
            a.setVisible(true);
        }
        
        if(e.getSource()== pqrs){
            dispose();
            Pqrs_usuario b=new Pqrs_usuario();
            Controlador_pqrs a=new Controlador_pqrs(b);
            b.setVisible(true);
        }
          if (e.getSource() == viaje) {
            Usuario usu = datosguardados.getUsuarioactual();
            if (usu == null) {
                dispose();
                Inicio inicio = new Inicio();
                inicio.setVisible(true);

            } else {
                dispose();
                miviaje_usuario a = new miviaje_usuario();
                a.setVisible(true);
            }
        }
           
        if(e.getSource()==descubrir){
            dispose();
            buscar a=new buscar();
            a.setVisible(true);
        }
    }

}
