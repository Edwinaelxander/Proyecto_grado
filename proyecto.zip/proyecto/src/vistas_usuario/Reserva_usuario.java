/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_usuario;

import datos.datosguardados;
import efectos.Botonhover;
import inicios_gui.Inicio;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import modelo_habitaciones.habitacion;
import modelo_usuario.Usuario;
import org.jdesktop.swingx.JXDatePicker;

/**
 *
 * @author Marely
 */
public class Reserva_usuario extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio, descubrir, viaje, yo, pagar;
    public JLabel calendariosalidad, calendarioentrada, personas, habitaciones;
    public JTextField personas_TX, habitaciones_TX;
    public JXDatePicker fechasalidad, fechaentrada;

    Font font = new Font("Futura ", Font.BOLD, 16);

    public Reserva_usuario() {

        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 10));
        principal.setBackground(Color.white);
        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));
        navegador.setBackground(Color.white);
        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima1 = new ImageIcon("buscar.PNG");
        descubrir = new JButton("buscar", ima1);
        descubrir.setContentAreaFilled(false);
        descubrir.setVerticalTextPosition(JButton.BOTTOM);
        descubrir.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("corazon.PNG");
        viaje = new JButton("mi viaje", ima2);
        viaje.setContentAreaFilled(false);
        viaje.setVerticalTextPosition(JButton.BOTTOM);
        viaje.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);
        inicio.addActionListener(this);
        descubrir.addActionListener(this);
        viaje.addActionListener(this);
        yo.addActionListener(this);

        viaje.setBorderPainted(false);
        descubrir.setBorderPainted(false);
        yo.setBorderPainted(false);
        inicio.setBorderPainted(false);

        principal.add(inicio);
        principal.add(descubrir);
        principal.add(viaje);
        principal.add(yo);

        navegador.add(principal);
        contenedor.add(navegador, BorderLayout.SOUTH);
        Botonhover efectoHover = new Botonhover(principal);
        efectoHover.aplicarEfectoHover();

        JPanel cabecera = new JPanel(new BorderLayout());
        TitledBorder titledBorder1 = BorderFactory.createTitledBorder("RESERVAR");
        titledBorder1.setTitleFont(new Font("Serif", Font.BOLD, 30));
        titledBorder1.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder1.setTitleJustification(TitledBorder.CENTER);

        cabecera.setBorder(titledBorder1);

        JPanel reservas = new JPanel(new GridLayout(9, 1));

        calendariosalidad = new JLabel("fecha Salida:");

        calendarioentrada = new JLabel("Fecha Entrada:");
        personas = new JLabel("Cantidad maxima de huespedes por habitacion:");
        habitaciones = new JLabel("Cantidad de habitaciones:");

        personas_TX = new JTextField(20);
        habitacion h = datosguardados.getHabitacionActual();
        personas_TX.setText("" + h.getCantidad());
        personas_TX.setEditable(false);
        habitaciones_TX = new JTextField(20);

        pagar = new JButton("pagar");
        pagar.setBackground(Color.orange);
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);

        fechasalidad = new JXDatePicker();
        fechasalidad.setDate(cal.getTime());
        fechasalidad.setFormats(new SimpleDateFormat("dd/MM/yyyy"));

        fechaentrada = new JXDatePicker();
        fechaentrada.setDate(new Date());
        fechaentrada.setFormats(new SimpleDateFormat("dd/MM/yyyy"));

        reservas.add(calendarioentrada);
        reservas.add(fechaentrada);
        reservas.add(calendariosalidad);
        reservas.add(fechasalidad);
        reservas.add(personas);
        reservas.add(personas_TX);
        reservas.add(habitaciones);
        reservas.add(habitaciones_TX);
        reservas.add(pagar);

        cabecera.add(reservas);
        contenedor.add(cabecera, BorderLayout.CENTER);

        setSize(500, 800);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == inicio) {
            dispose();
            inicio_usuario a = new inicio_usuario();
            a.setVisible(true);
        }

        if (e.getSource() == yo) {
            dispose();
            perfil a = new perfil();
            a.setVisible(true);
        }
        if (e.getSource() == viaje) {
            Usuario usu = datosguardados.getUsuarioactual();
            if (usu == null) {
                dispose();
                Inicio inicio = new Inicio();
                inicio.setVisible(true);

            } else {
                dispose();
                miviaje_usuario a = new miviaje_usuario();
                a.setVisible(true);
            }
        }
        if (e.getSource() == descubrir) {
            dispose();
            buscar a = new buscar();
            a.setVisible(true);
        }
    }
}
