/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_usuario;

import controlador.Controlador_pagar;
import datos.datosguardados;
import efectos.Botonhover;
import inicios_gui.Inicio;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import org.jdesktop.swingx.JXDatePicker;
import javax.swing.border.TitledBorder;
import modelo_usuario.Usuario;

/**
 *
 * @author Marely
 */
public class pagar_usuario extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio, descubrir, viaje, yo, pagar;
    public JLabel nombre, numero, fecha, codigo;
    public JTextField nombre_TX, numero_TX, codigo_TX;
    public JXDatePicker fechatarjeta;

    public pagar_usuario() {

        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 10));

        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));
        navegador.setBackground(Color.white);
        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima1 = new ImageIcon("buscar.PNG");
        descubrir = new JButton("buscar", ima1);
        descubrir.setContentAreaFilled(false);
        descubrir.setVerticalTextPosition(JButton.BOTTOM);
        descubrir.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("corazon.PNG");
        viaje = new JButton("mi viaje", ima2);
        viaje.setContentAreaFilled(false);
        viaje.setVerticalTextPosition(JButton.BOTTOM);
        viaje.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);

        inicio.addActionListener(this);
        descubrir.addActionListener(this);
        viaje.addActionListener(this);
        yo.addActionListener(this);
        viaje.setBorderPainted(false);
        descubrir.setBorderPainted(false);
        yo.setBorderPainted(false);
        inicio.setBorderPainted(false);

        principal.add(inicio);
        principal.add(descubrir);
        principal.add(viaje);
        principal.add(yo);
        Botonhover efectoHover = new Botonhover(principal);
        efectoHover.aplicarEfectoHover();

        navegador.add(principal);
        contenedor.add(navegador, BorderLayout.SOUTH);

        JPanel cabecera = new JPanel(new BorderLayout());
        TitledBorder titledBorder1 = BorderFactory.createTitledBorder("PAGAR");
        titledBorder1.setTitleFont(new Font("Arial", Font.BOLD, 30));
        titledBorder1.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder1.setTitleJustification(TitledBorder.CENTER);

        cabecera.setBorder(titledBorder1);

        JPanel pagarreserva = new JPanel(new GridLayout(9, 1));

        pagar = new JButton("Pagar");

        nombre = new JLabel("Nombre:");
        numero = new JLabel("Número de tarjeta:");
        fecha = new JLabel("Fecha de expedicion:");
        codigo = new JLabel("cvc:");

        nombre_TX = new JTextField(20);
        numero_TX = new JTextField(20);

        codigo_TX = new JTextField(20);

        fechatarjeta = new JXDatePicker();
        fechatarjeta.setDate(new Date());
        fechatarjeta.setFormats(new SimpleDateFormat("MM/yyyy"));

        pagarreserva.add(nombre);
        pagarreserva.add(nombre_TX);
        pagarreserva.add(numero);
        pagarreserva.add(numero_TX);
        pagarreserva.add(fecha);
        pagarreserva.add(fechatarjeta);
        pagarreserva.add(codigo);
        pagarreserva.add(codigo_TX);
        pagarreserva.add(pagar, BorderLayout.CENTER);
        cabecera.add(pagarreserva);
        contenedor.add(cabecera, BorderLayout.CENTER);

        setSize(500, 800);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == pagar) {
            // JOptionPane.showConfirmDialog(null, "estas seguro de hacer reserva");
        }
        if (e.getSource() == inicio) {
            dispose();
            inicio_usuario a = new inicio_usuario();
            a.setVisible(true);
        }

        if (e.getSource() == yo) {
            dispose();
            perfil a = new perfil();
            a.setVisible(true);
        }
          if (e.getSource() == viaje) {
            Usuario usu = datosguardados.getUsuarioactual();
            if (usu == null) {
                dispose();
                Inicio inicio = new Inicio();
                inicio.setVisible(true);

            } else {
                dispose();
                miviaje_usuario a = new miviaje_usuario();
                a.setVisible(true);
            }
        }
        if(e.getSource()==descubrir){
            dispose();
            buscar a=new buscar();
            a.setVisible(true);
        }

    }
     public static void main(String[] args) {
        pagar_usuario a=new pagar_usuario();
        Controlador_pagar b=new Controlador_pagar(a);
        a.setVisible(true);
    }

}
