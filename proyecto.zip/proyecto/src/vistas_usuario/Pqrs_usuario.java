/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_usuario;

import datos.datosguardados;
import efectos.Botonhover;
import inicios_gui.Inicio;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import modelo_usuario.Usuario;

/**
 *
 * @author Marely
 */
public class Pqrs_usuario extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio, descubrir, viaje, yo, enviar;
    public JLabel tipo, descripcion, alojamiento;
    public JTextField alojamiento_Tx;
    public JTextArea descripcion_area;
    public JComboBox<String> tipo_box;

    public Pqrs_usuario() {
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());
        JPanel cabecera = new JPanel(new BorderLayout());
        TitledBorder titledBorder1 = BorderFactory.createTitledBorder("PQRS");
        titledBorder1.setTitleFont(new Font("Serif", Font.BOLD, 30));
        titledBorder1.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder1.setTitleJustification(TitledBorder.CENTER);

        cabecera.setBorder(titledBorder1);

        cabecera.setPreferredSize(new Dimension(800, 500));

        JPanel panel = new JPanel(new GridLayout(7, 1));
        panel.setPreferredSize(new Dimension(500, 100));

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 10));
        principal.setBackground(Color.white);
        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));
        navegador.setBackground(Color.white);

        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima1 = new ImageIcon("buscar.PNG");
        descubrir = new JButton("buscar", ima1);
        descubrir.setContentAreaFilled(false);
        descubrir.setVerticalTextPosition(JButton.BOTTOM);
        descubrir.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("corazon.PNG");
        viaje = new JButton("mi viaje", ima2);
        viaje.setContentAreaFilled(false);
        viaje.setVerticalTextPosition(JButton.BOTTOM);
        viaje.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);

        viaje.setBorderPainted(false);
        descubrir.setBorderPainted(false);
        yo.setBorderPainted(false);
        inicio.setBorderPainted(false);
        inicio.addActionListener(this);
        yo.addActionListener(this);
        descubrir.addActionListener(this);

        principal.add(inicio);
        principal.add(descubrir);
        principal.add(viaje);
        principal.add(yo);

        Botonhover efectoHover = new Botonhover(principal);
        efectoHover.aplicarEfectoHover();

        navegador.add(principal);

        tipo = new JLabel("Tipo:");
        descripcion = new JLabel("Descripción:");
        alojamiento = new JLabel("Nombre del alojamiento(opcional)");
        alojamiento_Tx = new JTextField();
//        alojamiento_Tx.setPreferredSize(new Dimension(450, 50));
        descripcion_area = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(descripcion_area, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        enviar = new JButton("Enviar");

        tipo_box = new JComboBox<>();
        tipo_box.addItem("Pregunta");
        tipo_box.addItem("Quejas");
        tipo_box.addItem("Reclamo");
        tipo_box.addItem("Sugerencia");

        panel.add(tipo);
        panel.add(tipo_box);
        panel.add(descripcion);
        panel.add(scrollPane);
        panel.add(alojamiento);
        panel.add(alojamiento_Tx);
        panel.add(enviar);

        cabecera.add(panel);
        contenedor.add(cabecera, BorderLayout.CENTER);
        contenedor.add(navegador, BorderLayout.SOUTH);

        setSize(500, 800);

    }

    public static void main(String[] args) {

        Pqrs_usuario i = new Pqrs_usuario();
        i.setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == inicio) {
            dispose();
            inicio_usuario a = new inicio_usuario();
            a.setVisible(true);
        }

        if (e.getSource() == yo) {
            dispose();
            perfil a = new perfil();
            a.setVisible(true);
        }
         if (e.getSource() == viaje) {
            Usuario usu = datosguardados.getUsuarioactual();
            if (usu == null) {
                dispose();
                Inicio inicio = new Inicio();
                inicio.setVisible(true);

            } else {
                dispose();
                miviaje_usuario a = new miviaje_usuario();
                a.setVisible(true);
            }
        }
        if(e.getSource()==descubrir){
            dispose();
            buscar a=new buscar();
            a.setVisible(true);
        }
    }
}
