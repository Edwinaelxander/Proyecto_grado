/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_usuario;

import datos.datosguardados;
import efectos.Botonhover;
import inicios_gui.Inicio;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import modelo_alojamiento.alojamiento;
import modelo_comentario.Comentario;
import modelo_comentario.ComentarioDao;
import modelo_usuario.Usuario;

/**
 *
 * @author Marely
 */
public class alojamiento_usuario extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio, descubrir, viaje, yo, reservar, habitaciones, enviar;
    public JLabel comentari, calificacion;
    public JTextField comentario_TX, calificacion_TX;
    JPanel panelalojamientos = new JPanel(new BorderLayout());
    JPanel panelcomentari = new JPanel(new BorderLayout());
    Font font = new Font("Arial", Font.PLAIN, 14);

    public alojamiento_usuario() {

        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 10));
        principal.setBackground(Color.white);
        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));
        navegador.setBackground(Color.white);

        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima1 = new ImageIcon("buscar.PNG");
        descubrir = new JButton("buscar", ima1);
        descubrir.setContentAreaFilled(false);
        descubrir.setVerticalTextPosition(JButton.BOTTOM);
        descubrir.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("corazon.PNG");
        viaje = new JButton("mi viaje", ima2);
        viaje.setContentAreaFilled(false);
        viaje.setVerticalTextPosition(JButton.BOTTOM);
        viaje.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);
        inicio.addActionListener(this);
        descubrir.addActionListener(this);
        viaje.addActionListener(this);
        yo.addActionListener(this);
        viaje.setBorderPainted(false);
        descubrir.setBorderPainted(false);
        descubrir.addActionListener(this);
        yo.setBorderPainted(false);
        inicio.setBorderPainted(false);

        principal.add(inicio);
        principal.add(descubrir);
        principal.add(viaje);
        principal.add(yo);

        Botonhover efectoHover = new Botonhover(principal);
        efectoHover.aplicarEfectoHover();

        navegador.add(principal);
        contenedor.add(navegador, BorderLayout.SOUTH);

        JPanel cabecera = new JPanel(new BorderLayout());
        TitledBorder titledBorder1 = BorderFactory.createTitledBorder("HOTEL");
        titledBorder1.setTitleFont(new Font("Serif", Font.BOLD, 30));
        titledBorder1.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder1.setTitleJustification(TitledBorder.CENTER);

        cabecera.setBorder(titledBorder1);
        cabecera.setBackground(Color.white);
        panelalojamientos = new JPanel(new GridLayout(1, 1, 2, 10));
        panelalojamientos.setPreferredSize(new Dimension(400,100));
        panelalojamientos.setBackground(Color.white);
        cabecera.add(panelalojamientos, BorderLayout.NORTH);

        inicializar();

        comentari = new JLabel("haz tu comentario");
        comentari.setFont(font);
        comentario_TX = new JTextField(20);
        calificacion = new JLabel("calificacion");
        calificacion.setFont(font);
        calificacion_TX = new JTextField(20);
        enviar = new JButton("enviar");
        JPanel comentario = new JPanel(new GridLayout(3, 2));
          comentario.setMinimumSize(new Dimension(400, 100));
        comentario.setMaximumSize(new Dimension(400, 100));
      
        comentario.add(comentari);
        comentario.add(comentario_TX);
        comentario.add(calificacion);
        comentario.add(calificacion_TX);
        comentario.add(enviar);
        comentario.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        reservar = new JButton("reservar ahora");
        reservar.setBackground(Color.orange);
        reservar.addActionListener(this);
        habitaciones = new JButton("habitaciones");
        habitaciones.addActionListener(this);
        habitaciones.setBackground(Color.orange);

        JPanel a = new JPanel(new GridLayout(1, 0));
        a.setPreferredSize(new Dimension(200, 50));
        // a.add(reservar);
        a.add(habitaciones);

        panelcomentari = new JPanel(new GridLayout(0, 1, 2, 10));
        panelcomentari.setBackground(Color.WHITE);
        TitledBorder titledBorder = BorderFactory.createTitledBorder("COMENTARIOS");
        titledBorder.setTitleFont(new Font("Arial", Font.BOLD, 20));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.LEFT);

        panelcomentari.setBorder(titledBorder);
        panelcomentari.setPreferredSize(new Dimension(450, 900));

        panelcomentari.add(comentario, BorderLayout.SOUTH);
        comentarios();

        cabecera.add(a, BorderLayout.SOUTH);

        JScrollPane scrollPane = new JScrollPane(panelcomentari, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        cabecera.add(scrollPane, BorderLayout.CENTER);
        //contenedor.add(scrollPane, BorderLayout.CENTER);

        contenedor.add(cabecera, BorderLayout.CENTER);
        contenedor.setBackground(Color.white);
        setSize(500, 800);
    }

    private void inicializar() {
        alojamiento alojamiento1 = datosguardados.getAlojamientoActual();

        JLabel labelId = new JLabel("NOMBRE: " + alojamiento1.getNombre());
        JLabel labelDireccion = new JLabel("DIRECCION: " + alojamiento1.getDireccion());
        JTextArea descripcion = new JTextArea(alojamiento1.getDescripcion());
        descripcion.setEditable(false);
        descripcion.setFont(font);
        descripcion.setFocusable(false);
        descripcion.setBackground(null);
        descripcion.setLineWrap(true);
        descripcion.setWrapStyleWord(true);

        labelId.setFont(font);
        labelDireccion.setFont(font);

        JPanel panelDetalles = new JPanel(new GridLayout(3, 1));
        panelDetalles.add(labelId);
        panelDetalles.add(descripcion);
        panelDetalles.add(labelDireccion);
        panelDetalles.setBackground(Color.white);

        panelalojamientos.add(panelDetalles, BorderLayout.NORTH);

        panelalojamientos.revalidate();
    }

    private void comentarios() {
        ComentarioDao alo = new ComentarioDao();
        new GridLayout(0, 1);

        List<Comentario> comentario = alo.obtenercomentarios();

        for (Comentario comentarios : comentario) {
            JPanel panelcomentarios = new JPanel(new GridLayout(3, 1));
            panelcomentarios.setBorder(BorderFactory.createLineBorder(Color.BLACK));

            JLabel nombre = new JLabel("USUARIO:   " + comentarios.getNombre());
            JTextArea comentari = new JTextArea("COMENTARIO:   " + comentarios.getComentario());
            JLabel calificacion = new JLabel("CALIFICACION:   " + comentarios.getCalificacion());
            comentari.setEditable(false);
            comentari.setFont(font);
            comentari.setFocusable(false);
            comentari.setBackground(null);

            comentari.setLineWrap(true);
            comentari.setWrapStyleWord(true);

            panelcomentarios.add(nombre);
            panelcomentarios.add(comentari);
            panelcomentarios.add(calificacion);

            panelcomentari.add(panelcomentarios, BorderLayout.CENTER);
        }
        panelcomentari.revalidate();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == habitaciones) {
            dispose();
            Habitaciones_usuario a = new Habitaciones_usuario();
            a.setVisible(true);
        }

        if (e.getSource() == inicio) {
            dispose();
            inicio_usuario a = new inicio_usuario();
            a.setVisible(true);
        }

        if (e.getSource() == yo) {
            dispose();
            perfil a = new perfil();
            a.setVisible(true);
        }
        if (e.getSource() == viaje) {
            Usuario usu = datosguardados.getUsuarioactual();
            if (usu == null) {
                dispose();
                Inicio inicio = new Inicio();
                inicio.setVisible(true);

            } else {
                dispose();
                miviaje_usuario a = new miviaje_usuario();
                a.setVisible(true);
            }
        }
        if (e.getSource() == descubrir) {
            dispose();
            buscar a = new buscar();
            a.setVisible(true);
        }
        if (e.getSource() == descubrir) {
            dispose();
            buscar a = new buscar();
            a.setVisible(true);
        }

    }
}
