/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_usuario;

import controlador.Controlador_habitacion;
import datos.datosguardados;
import efectos.Botonhover;
import efectos.Redondiarjpanel;
import inicios_gui.Inicio;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;
import modelo_habitaciones.habitacion;
import modelo_habitaciones.habitacionDao;
import modelo_usuario.Usuario;
import vistas_gerentes.Detalles_habitacion;

/**
 *
 * @author Marely
 */
public class Habitaciones_usuario extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio, descubrir, viaje, yo, reservar;
    JPanel panelhabitaciones = new JPanel(new BorderLayout());
    private habitacion habitacionselecionada;
    Font font = new Font("Arial", Font.PLAIN, 14);

    public Habitaciones_usuario() {
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 10));
        principal.setBackground(Color.white);
        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));
        navegador.setBackground(Color.white);
        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima1 = new ImageIcon("buscar.PNG");
        descubrir = new JButton("buscar", ima1);
        descubrir.setContentAreaFilled(false);
        descubrir.setVerticalTextPosition(JButton.BOTTOM);
        descubrir.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("corazon.PNG");
        viaje = new JButton("mi viaje", ima2);
        viaje.setContentAreaFilled(false);
        viaje.setVerticalTextPosition(JButton.BOTTOM);
        viaje.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);

        inicio.addActionListener(this);
        descubrir.addActionListener(this);
        viaje.addActionListener(this);
        yo.addActionListener(this);
//        reservar.addActionListener(this);

        viaje.setBorderPainted(false);
        descubrir.setBorderPainted(false);
        yo.setBorderPainted(false);
        inicio.setBorderPainted(false);

        principal.add(inicio);
        principal.add(descubrir);
        principal.add(viaje);
        principal.add(yo);
        Botonhover efectoHover = new Botonhover(principal);
        efectoHover.aplicarEfectoHover();

        navegador.add(principal);
        contenedor.add(navegador, BorderLayout.SOUTH);

        JPanel cabecera = new JPanel(new BorderLayout());

        TitledBorder titledBorder = BorderFactory.createTitledBorder("HABITACIONES");
        titledBorder.setTitleFont(new Font("Serif", Font.BOLD, 30));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.CENTER);

        cabecera.setBorder(titledBorder);
//        cabecera.setPreferredSize(new Dimension(500, 500));
        cabecera.setBackground(Color.WHITE);

        panelhabitaciones = new JPanel(new GridLayout(0, 1, 2, 10));
        cabecera.add(panelhabitaciones, BorderLayout.CENTER);
        panelhabitaciones.setBackground(Color.white);

        JScrollPane scrollPane = new JScrollPane(cabecera, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        inicializar();
        contenedor.add(scrollPane, BorderLayout.CENTER);

        setSize(500, 800);
    }

    private void inicializar() {
        habitacionDao alo = new habitacionDao();
        new GridLayout(0, 1);

        List<habitacion> Habitacion = alo.habitaciones();

        for (habitacion habitaciones : Habitacion) {
            Redondiarjpanel panelHabitacion = new Redondiarjpanel();
            panelHabitacion.setBackground(Color.white);
            panelHabitacion.setLayout(new GridLayout(2,1));
            
            JLabel tipo = new JLabel("TIPO " + habitaciones.getTipo());
            System.err.println(habitaciones.getPrecio());
            JLabel precio = new JLabel("PRECIO: $" + habitaciones.getPrecio());
            tipo.setFont(font);
            precio.setFont(font);

            panelHabitacion.add(tipo);
            panelHabitacion.add(precio);

            panelhabitaciones.add(panelHabitacion, BorderLayout.CENTER);
            panelHabitacion.addMouseListener(new MouseAdapter() {

                @Override
                public void mouseClicked(MouseEvent e) {
                    habitacionselecionada = habitaciones;
                    dispose();
                    datosguardados.setHabitacionActual(habitacionselecionada);
                    detalles_habitacion_usuario a = new detalles_habitacion_usuario();
                    Controlador_habitacion b = new Controlador_habitacion(a);
                    a.setVisible(true);
//                    habitacion s = datosguardados.getHabitacionActual();

                }

                @Override
                public void mouseEntered(MouseEvent e) {
                    panelHabitacion.setBackground(Color.orange);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    panelHabitacion.setBackground(Color.WHITE);
                }

            });

        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == inicio) {
            dispose();
            inicio_usuario a = new inicio_usuario();
            a.setVisible(true);
        }

        if (e.getSource() == yo) {
            dispose();
            perfil a = new perfil();
            a.setVisible(true);
        }
          if (e.getSource() == viaje) {
            Usuario usu = datosguardados.getUsuarioactual();
            if (usu == null) {
                dispose();
                Inicio inicio = new Inicio();
                inicio.setVisible(true);

            } else {
                dispose();
                miviaje_usuario a = new miviaje_usuario();
                a.setVisible(true);
            }
        }
        if(e.getSource()==descubrir){
            dispose();
            buscar a=new buscar();
            a.setVisible(true);
        }
    }
}
