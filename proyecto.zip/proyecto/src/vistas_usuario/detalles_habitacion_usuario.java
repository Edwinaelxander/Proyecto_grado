/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_usuario;

import Db.Conexion;
import controlador.Controlador_reserva;
import datos.datosguardados;
import efectos.Botonhover;
import inicios_gui.Inicio;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import modelo_habitaciones.habitacion;
import modelo_usuario.Usuario;

/**
 *
 * @author Marely
 */
public class detalles_habitacion_usuario extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio, descubrir, viaje, yo, reservar;
    public JLabel tipo, rtipo, rvista, vista, rcantidad, cantidad, rprecio, precio, rservicio;
    public JTextArea servicio;
    JPanel paneldescripcion = new JPanel(new BorderLayout());
    Font font = new Font("Serif", Font.PLAIN, 16);

    public detalles_habitacion_usuario() {

        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel cabecera = new JPanel(new BorderLayout());
        cabecera.setPreferredSize(new Dimension(450, 650));
        cabecera.setBackground(Color.WHITE);
        cabecera.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 10));
        principal.setBackground(Color.white);
        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));
        navegador.setBackground(Color.white);
        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima1 = new ImageIcon("buscar.PNG");
        descubrir = new JButton("buscar", ima1);
        descubrir.setContentAreaFilled(false);
        descubrir.setVerticalTextPosition(JButton.BOTTOM);
        descubrir.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("corazon.PNG");
        viaje = new JButton("mi viaje", ima2);
        viaje.setContentAreaFilled(false);
        viaje.setVerticalTextPosition(JButton.BOTTOM);
        viaje.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);

        inicio.addActionListener(this);
        descubrir.addActionListener(this);
        viaje.addActionListener(this);
        yo.addActionListener(this);
        viaje.setBorderPainted(false);
        descubrir.setBorderPainted(false);
        yo.setBorderPainted(false);
        inicio.setBorderPainted(false);

        principal.add(inicio);
        principal.add(descubrir);
        principal.add(viaje);
        principal.add(yo);
        Botonhover efectoHover = new Botonhover(principal);
        efectoHover.aplicarEfectoHover();

        navegador.add(principal);
        contenedor.add(navegador, BorderLayout.SOUTH);

        reservar = new JButton("reservar ahora");
        reservar.setBackground(Color.orange);
        reservar.addActionListener(this);

        cabecera.add(reservar, BorderLayout.SOUTH);

        paneldescripcion = new JPanel(new GridLayout(0, 1));
        cabecera.add(paneldescripcion);
        JScrollPane scrollPane = new JScrollPane(cabecera, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        contenedor.add(scrollPane, BorderLayout.NORTH);
        buscar();

        setSize(500, 800);
    }

    private void buscar() {

        habitacion a = datosguardados.getHabitacionActual();
        tipo = new JLabel();
        tipo.setFont(font);
        rtipo = new JLabel(a.getTipo());

        vista = new JLabel();
        vista.setFont(font);
        rvista = new JLabel(a.getVista());

        cantidad = new JLabel();
        cantidad.setFont(font);
        rcantidad = new JLabel("" + a.getCantidad());

        precio = new JLabel();
        precio.setFont(font);
        System.err.println(a.getPrecio());
        rprecio = new JLabel("$" + a.getPrecio());

        servicio = new JTextArea();
        servicio.setFont(font);
        servicio.setEditable(false);
        servicio.setBackground(null);
        JScrollPane scrollPane = new JScrollPane(servicio, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        rservicio = new JLabel(a.getServicios());

        JPanel panelDetalles = new JPanel(new GridLayout(5, 1));

        panelDetalles.add(tipo);

        panelDetalles.add(vista);

        panelDetalles.add(cantidad);
        panelDetalles.add(precio);
        panelDetalles.add(scrollPane);

        paneldescripcion.add(panelDetalles, BorderLayout.CENTER);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == reservar) {
            Usuario usu = datosguardados.getUsuarioactual();
            if (usu == null) {
                dispose();
                Inicio i = new Inicio();
                i.setVisible(true);
            }else{
                dispose();
            Reserva_usuario a = new Reserva_usuario();
            Controlador_reserva b = new Controlador_reserva(a);
            a.setVisible(true);
                
            }
            
            
        }

        if (e.getSource() == inicio) {
            dispose();
            inicio_usuario a = new inicio_usuario();
            a.setVisible(true);
        }

        if (e.getSource() == yo) {
            dispose();
            perfil a = new perfil();
            a.setVisible(true);
        }

        if (e.getSource() == viaje) {
            dispose();
            miviaje_usuario a = new miviaje_usuario();
            a.setVisible(true);
        }
        if(e.getSource()==descubrir){
            dispose();
            buscar a=new buscar();
            a.setVisible(true);
        }

    }

}
