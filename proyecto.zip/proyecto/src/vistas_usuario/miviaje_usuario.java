/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_usuario;

import controlador.Controlador_comentarios;
import controlador.Controlador_reserva;
import datos.datosguardados;
import efectos.Botonhover;
import efectos.Redondiarboton;
import efectos.Redondiarjpanel;
import inicios_gui.Inicio;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;
import modelo_habitaciones.habitacion;
import modelo_reserva.Reserva;
import modelo_reserva.ReservaDao;
import modelo_usuario.Usuario;

/**
 *
 * @author Marely
 */
public class miviaje_usuario extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio, descubrir, viaje, yo, efectiva, activa, terminada;
    public JLabel nombrealojamiento, direccion, telefono;
    JPanel panelreser = new JPanel(new BorderLayout());

    public miviaje_usuario() {

        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 10));
        principal.setBackground(Color.white);
        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));
        navegador.setBackground(Color.white);

        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima1 = new ImageIcon("buscar.PNG");
        descubrir = new JButton("buscar", ima1);
        descubrir.setContentAreaFilled(false);
        descubrir.setVerticalTextPosition(JButton.BOTTOM);
        descubrir.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("corazon.PNG");
        viaje = new JButton("mi viaje", ima2);
        viaje.setContentAreaFilled(false);
        viaje.setVerticalTextPosition(JButton.BOTTOM);
        viaje.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);
        inicio.addActionListener(this);
        descubrir.addActionListener(this);
        viaje.addActionListener(this);
        yo.addActionListener(this);
        viaje.setBorderPainted(false);
        descubrir.setBorderPainted(false);
        yo.setBorderPainted(false);
        inicio.setBorderPainted(false);

        principal.add(inicio);
        principal.add(descubrir);
        principal.add(viaje);
        principal.add(yo);

        Botonhover efectoHover = new Botonhover(principal);
        efectoHover.aplicarEfectoHover();

        navegador.add(principal);
        contenedor.add(navegador, BorderLayout.SOUTH);

        JPanel a1 = new JPanel(new BorderLayout());
        a1.setBackground(Color.white);

        TitledBorder titledBorder = BorderFactory.createTitledBorder("MIS RESERVAS");
        titledBorder.setTitleFont(new Font("Serif", Font.BOLD, 30));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.CENTER);

        a1.setBorder(titledBorder);

        JPanel a3 = new JPanel(new GridLayout(1, 3, 10, 3));
        a3.setBackground(Color.white);

        efectiva = new Redondiarboton("Efectiva");
        efectiva.addActionListener(this);
        terminada = new Redondiarboton("terminada");
        terminada.addActionListener(this);
        activa = new Redondiarboton("Activa");
        activa.setBackground(Color.orange);
        activa.addActionListener(this);

        a3.add(activa);
        a3.add(efectiva);
        a3.add(terminada);

        a1.add(a3, BorderLayout.NORTH);
        contenedor.add(a1, BorderLayout.NORTH);

        panelreser = new JPanel(new GridLayout(0, 2, 5, 10));
        panelreser.setPreferredSize(new Dimension(460, 1000));
        panelreser.setBackground(Color.white);

        a1.add(panelreser, BorderLayout.CENTER);

        JScrollPane scrollPane = new JScrollPane(panelreser, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        contenedor.add(scrollPane, BorderLayout.CENTER);
        reservaactiva();

        setSize(500, 800);

    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == inicio) {
            dispose();
            inicio_usuario a = new inicio_usuario();
            a.setVisible(true);
        }

        if (e.getSource() == yo) {

            dispose();
            perfil a = new perfil();
            a.setVisible(true);

        }
        if (e.getSource() == descubrir) {
            dispose();
            buscar a = new buscar();
            a.setVisible(true);
        }

        if (e.getSource() == activa) {

            panelreser.removeAll();
            reservaactiva();
            panelreser.revalidate();
            panelreser.repaint();
            activa.setBackground(Color.orange);
            efectiva.setBackground(null);
            terminada.setBackground(null);
        }
        if (e.getSource() == efectiva) {

            panelreser.removeAll();
            reservaefectiva();
            panelreser.revalidate();
            panelreser.repaint();
            efectiva.setBackground(Color.orange);
            activa.setBackground(null);
            terminada.setBackground(null);
        }
        if (e.getSource() == terminada) {

            panelreser.removeAll();
            reservaterminada();
            panelreser.revalidate();
            panelreser.repaint();
            efectiva.setBackground(null);
            activa.setBackground(null);
            terminada.setBackground(Color.orange);
        }
    }

    private void reservaactiva() {

        ReservaDao alo = new ReservaDao();

        List<Reserva> reserva = alo.reserva(1);

        for (Reserva reservas : reserva) {
            Redondiarjpanel panelreserva = new Redondiarjpanel();

            panelreserva.setBackground(Color.white);
            panelreserva.setLayout(new GridLayout(5, 1));

            JLabel id = new JLabel("ID " + reservas.getIdreserva());
            JLabel habitacion = new JLabel("numero de habitacion: " + reservas.getHabitacion());
            nombrealojamiento = new JLabel("Nombre del alojamiento: " + reservas.getNombreAlojamiento());
            direccion = new JLabel("Dirreccion: " + reservas.getDireccionAlojamiento());
            telefono = new JLabel("Telefono: " + reservas.getTelefonoAlojamiento());
            System.out.print("ss" + reservas.getIdreserva());

            panelreserva.add(id);
            panelreserva.add(nombrealojamiento);
            panelreserva.add(direccion);
            panelreserva.add(telefono);
            panelreserva.add(habitacion);

            panelreser.add(panelreserva, BorderLayout.CENTER);
            panelreserva.addMouseListener(new MouseAdapter() {

                @Override
                public void mouseClicked(MouseEvent e) {

                    dispose();
                    datosguardados.setReservaactual(reservas);
                    Detalle_miviaje_usuario a = new Detalle_miviaje_usuario(1);
                    Controlador_reserva b = new Controlador_reserva(a);
                    a.setVisible(true);

//                    dispose();
                }

                @Override
                public void mouseEntered(MouseEvent e) {
                    panelreserva.setBackground(Color.orange);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    panelreserva.setBackground(Color.WHITE);
                }

            });
        }
    }

    private void reservaefectiva() {

        ReservaDao alo = new ReservaDao();

        List<Reserva> reserva = alo.reserva(2);

        for (Reserva reservas : reserva) {
            Redondiarjpanel panelreserva = new Redondiarjpanel();

            panelreserva.setBackground(Color.white);
            panelreserva.setLayout(new GridLayout(5, 1));

            JLabel id = new JLabel("ID " + reservas.getIdreserva());
            JLabel habitacion = new JLabel("numero de habitacion: " + reservas.getHabitacion());
            nombrealojamiento = new JLabel("Nombre del hotel: " + reservas.getNombreAlojamiento());
            direccion = new JLabel("Dirreccion: " + reservas.getDireccionAlojamiento());
            telefono = new JLabel("Telefono: " + reservas.getTelefonoAlojamiento());
            panelreserva.add(id);
            panelreserva.add(nombrealojamiento);
            panelreserva.add(direccion);
            panelreserva.add(telefono);
            panelreserva.add(habitacion);

            panelreser.add(panelreserva, BorderLayout.CENTER);
            panelreserva.addMouseListener(new MouseAdapter() {

                @Override
                public void mouseClicked(MouseEvent e) {

                    dispose();
                    datosguardados.setReservaactual(reservas);
                    Detalle_miviaje_usuario a = new Detalle_miviaje_usuario(2);
                    Controlador_reserva b = new Controlador_reserva(a);
                    a.setVisible(true);

//                    dispose();
                }

                @Override
                public void mouseEntered(MouseEvent e) {
                    panelreserva.setBackground(Color.orange);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    panelreserva.setBackground(Color.WHITE);
                }

            });
        }
    }

    private void reservaterminada() {

        ReservaDao alo = new ReservaDao();

        List<Reserva> reserva = alo.reserva(3);

        for (Reserva reservas : reserva) {
            Redondiarjpanel panelreserva = new Redondiarjpanel();

            panelreserva.setBackground(Color.white);
            panelreserva.setLayout(new GridLayout(5, 1));

            JLabel id = new JLabel("ID " + reservas.getIdreserva());
            JLabel habitacion = new JLabel("numero de habitacion: " + reservas.getHabitacion());
            nombrealojamiento = new JLabel("Nombre del hotel: " + reservas.getNombreAlojamiento());
            direccion = new JLabel("Dirreccion: " + reservas.getDireccionAlojamiento());
            telefono = new JLabel("Telefono: " + reservas.getTelefonoAlojamiento());
            panelreserva.add(id);
            panelreserva.add(nombrealojamiento);
            panelreserva.add(direccion);
            panelreserva.add(telefono);
            panelreserva.add(habitacion);

            panelreser.add(panelreserva, BorderLayout.CENTER);

        }
    }

    public static void main(String[] args) {
        miviaje_usuario a = new miviaje_usuario();
        a.setVisible(true);
    }

}
