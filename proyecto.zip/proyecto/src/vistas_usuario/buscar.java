/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_usuario;

import controlador.Controlador_comentarios;
import datos.datosguardados;
import efectos.Botonhover;
import efectos.Redondiarjpanel;
import inicios_gui.Inicio;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import modelo_alojamiento.alojamiento;
import modelo_alojamiento.alojamientoDao;
import modelo_usuario.Usuario;

/**
 *
 * @author Aprendiz
 */
public class buscar extends JFrame implements ActionListener {

    private JTextArea labelDescripcion, labelNombre, labelDireccion;
    private Container contenedor;
    public JTextField buscar_Tx;
    public JButton buscar, inicio, descubrir, viaje, yo;
    Font font = new Font("Arial", Font.PLAIN, 14);
    JPanel panelalojamientos = new JPanel(new BorderLayout());
    private alojamiento alojamientoSeleccionado;
    int num;
    private JLabel labelImagen;

    public buscar() {
        contenedor = getContentPane();
        JPanel cabecera = new JPanel(new BorderLayout());
        TitledBorder titledBorder = BorderFactory.createTitledBorder("BUSCA TU ALOJAMIENTO");
        titledBorder.setTitleFont(new Font("Serif", Font.BOLD, 20));
        titledBorder.setTitleJustification(TitledBorder.CENTER);

        cabecera.setBorder(titledBorder);
        cabecera.setBackground(Color.white);

        JPanel buscar1 = new JPanel(new FlowLayout());
        buscar_Tx = new JTextField();
        buscar_Tx.setPreferredSize(new Dimension(350, 70));
        Icon ima1 = new ImageIcon("buscar.PNG");
        buscar = new JButton(ima1);
        buscar.setContentAreaFilled(false);
        buscar.addActionListener(this);

        buscar1.add(buscar_Tx);
        buscar1.add(buscar);

        cabecera.add(buscar1, BorderLayout.NORTH);

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 40));

        JPanel navegador = new JPanel();
        navegador.setBackground(Color.white);
        principal.setPreferredSize(new Dimension(450, 100));
        principal.setBackground(Color.white);

        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);
        inicio.setBorderPainted(false);

        descubrir = new JButton("buscar", ima1);
        descubrir.setContentAreaFilled(false);
        descubrir.setVerticalTextPosition(JButton.BOTTOM);
        descubrir.setHorizontalTextPosition(JButton.CENTER);
        descubrir.setBorderPainted(false);

        Icon ima2 = new ImageIcon("corazon.PNG");
        viaje = new JButton("mi viaje", ima2);
        viaje.setContentAreaFilled(false);
        viaje.setVerticalTextPosition(JButton.BOTTOM);
        viaje.setHorizontalTextPosition(JButton.CENTER);
        viaje.setBorderPainted(false);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);
        yo.setBorderPainted(false);

        inicio.addActionListener(this);
        descubrir.addActionListener(this);
        viaje.addActionListener(this);
        yo.addActionListener(this);

        principal.add(inicio);
        principal.add(descubrir);
        principal.add(viaje);
        principal.add(yo);

        navegador.add(principal);
        contenedor.add(navegador, BorderLayout.SOUTH);

        Botonhover efectoHover = new Botonhover(principal);
        efectoHover.aplicarEfectoHover();

        panelalojamientos = new JPanel(new GridLayout(0, 2, 10, 10));
        panelalojamientos.setBackground(Color.WHITE);
        panelalojamientos.setPreferredSize(new Dimension(420, 580));
        panelalojamientos.setBackground(null);

        panelalojamientos.setBackground(Color.white);
        cabecera.add(panelalojamientos, BorderLayout.CENTER);
        inicializar();

        contenedor.add(cabecera, BorderLayout.CENTER);
        setSize(500, 800);

    }

    private void inicializar() {
        panelalojamientos.removeAll();
        alojamientoDao alo = new alojamientoDao();

        new GridLayout(1, 1);

        List<alojamiento> Alojamiento = alo.buscar(buscar_Tx.getText().toString());

        for (alojamiento alojamientos : Alojamiento) {
            Redondiarjpanel panelAlojamiento = new Redondiarjpanel();
             panelAlojamiento.setBackground(Color.white);
            panelAlojamiento.setLayout(new FlowLayout());
            panelAlojamiento.setPreferredSize(new Dimension(400, 200));

            labelNombre = new JTextArea("HOTEL: " + alojamientos.getNombre());
            labelNombre.setEditable(false);
            labelNombre.setFont(font);
            labelNombre.setFocusable(false);
            labelNombre.setBackground(null);
            labelNombre.setPreferredSize(new Dimension(200, 50));
            labelNombre.setLineWrap(true);
            labelNombre.setWrapStyleWord(true);

            labelDescripcion = new JTextArea("DESCRIPCION: " + alojamientos.getDescripcion());
            labelDescripcion.setEditable(false);
            labelDescripcion.setFont(font);
            labelDescripcion.setFocusable(false);
            labelDescripcion.setBackground(null);
            labelDescripcion.setPreferredSize(new Dimension(200, 90));
            labelDescripcion.setLineWrap(true);
            labelDescripcion.setWrapStyleWord(true);

            labelDireccion = new JTextArea("DIRECCION: " + alojamientos.getDireccion());
            labelDireccion.setEditable(false);
            labelDireccion.setFont(font);
            labelDireccion.setFocusable(false);
            labelDireccion.setBackground(null);
            labelDireccion.setPreferredSize(new Dimension(200, 50));
            labelDireccion.setLineWrap(true);
            labelDireccion.setWrapStyleWord(true);

            labelImagen = new JLabel();
            byte[] imagenBytes = alojamientos.getImagen();
            Image imagen = Toolkit.getDefaultToolkit().createImage(imagenBytes);
            ImageIcon imagenIcono = new ImageIcon(imagen.getScaledInstance(150, 100, Image.SCALE_SMOOTH));
            labelImagen.setIcon(imagenIcono);

            panelAlojamiento.add(labelImagen, BorderLayout.NORTH);
            panelAlojamiento.add(labelNombre);
            panelAlojamiento.add(labelDescripcion);
            panelAlojamiento.add(labelDireccion);

            panelalojamientos.add(panelAlojamiento, BorderLayout.CENTER);
            panelAlojamiento.addMouseListener(new MouseAdapter() {

                @Override
                public void mouseClicked(MouseEvent e) {
                    alojamientoSeleccionado = alojamientos;
                    dispose();
                    datosguardados.setAlojamientoActual(alojamientoSeleccionado);
//
                    alojamiento_usuario a = new alojamiento_usuario();
                    Controlador_comentarios b = new Controlador_comentarios(a);
                    a.setVisible(true);
//
                    System.out.println(alojamientos.getId());

                }

                @Override
                public void mouseEntered(MouseEvent e) {
                    panelAlojamiento.setBackground(Color.orange);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    panelAlojamiento.setBackground(Color.WHITE);
                }

            });

        }
        panelalojamientos.revalidate();
        panelalojamientos.repaint();

    }

    public static void main(String[] args) {
        buscar a = new buscar();
        a.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == inicio) {
            dispose();
            inicio_usuario a = new inicio_usuario();
            a.setVisible(true);
        }

        if (e.getSource() == yo) {
            dispose();
            perfil a = new perfil();
            a.setVisible(true);
        }

        if (e.getSource() == viaje) {
            Usuario usu = datosguardados.getUsuarioactual();
            if (usu == null) {
                dispose();
                Inicio inicio = new Inicio();
                inicio.setVisible(true);

            } else {
                dispose();
                miviaje_usuario a = new miviaje_usuario();
                a.setVisible(true);
            }
        }
        if (e.getSource() == buscar) {

            inicializar();

        }
    }
}
