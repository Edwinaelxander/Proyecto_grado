/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_usuario;

import controlador.Controlador_alojamiento;
import datos.datosguardados;
import efectos.Botonhover;
import inicios_gui.Inicio;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.border.TitledBorder;
import modelo_usuario.Usuario;

/**
 *
 * @author Marely
 */
public class datos_usuario extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio, descubrir, viaje, yo, modificar, eliminar, confirmar;
    public JLabel nombre, correo, telefono, contraseña;
    public JTextField nombre_TX, correo_TX, telefono_TX, contraseña_TX;
    public JPasswordField contraseña1;

    public datos_usuario() {
 Usuario usu = datosguardados.getUsuarioactual();
    if (usu == null) {
        dispose();
        Inicio i = new Inicio();
        i.setVisible(true);
        
        return;
    }
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 10));

        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));
        principal.setBackground(Color.white);
        navegador.setBackground(Color.white);
        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima1 = new ImageIcon("buscar.PNG");
        descubrir = new JButton("buscar", ima1);
        descubrir.setContentAreaFilled(false);
        descubrir.setVerticalTextPosition(JButton.BOTTOM);
        descubrir.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("corazon.PNG");
        viaje = new JButton("mi viaje", ima2);
        viaje.setContentAreaFilled(false);
        viaje.setVerticalTextPosition(JButton.BOTTOM);
        viaje.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);
        inicio.addActionListener(this);
        descubrir.addActionListener(this);
        viaje.addActionListener(this);
        yo.addActionListener(this);
        viaje.setBorderPainted(false);
        descubrir.setBorderPainted(false);
        yo.setBorderPainted(false);
        inicio.setBorderPainted(false);

        principal.add(inicio);
        principal.add(descubrir);
        principal.add(viaje);
        principal.add(yo);

        Botonhover efectoHover = new Botonhover(principal);
        efectoHover.aplicarEfectoHover();

        navegador.add(principal);
        contenedor.add(navegador, BorderLayout.SOUTH);

        JPanel cabecera = new JPanel(new BorderLayout());

        TitledBorder titledBorder1 = BorderFactory.createTitledBorder("MIS DATOS");
        titledBorder1.setTitleFont(new Font("Serif", Font.BOLD, 30));
        titledBorder1.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder1.setTitleJustification(TitledBorder.CENTER);

        cabecera.setBorder(titledBorder1);

        JPanel datos = new JPanel(new GridLayout(10, 1));

        nombre = new JLabel("Nombre:");
        correo = new JLabel("Correo:");
        telefono = new JLabel("Teléfono:");
        contraseña = new JLabel("contraseña");

        nombre_TX = new JTextField(20);
        nombre_TX.setText(usu.getNombre());
        nombre_TX.setEditable(false);
        correo_TX = new JTextField(20);
        correo_TX.setEditable(false);
        correo_TX.setText(usu.getCorre());
        telefono_TX = new JTextField(20);
        telefono_TX.setEditable(false);
        telefono_TX.setText(usu.getTelefono());

        contraseña1 = new JPasswordField(20);
        contraseña1.setEditable(false);
        contraseña1.setText(usu.getContraseña());

        eliminar = new JButton("eliminar");
        modificar = new JButton("modificar");
        confirmar = new JButton("confirmar");
        confirmar.setVisible(false);
        confirmar.addActionListener(this);
        modificar.addActionListener(this);
        JPanel crud = new JPanel(new GridLayout(1, 2));
        crud.add(modificar);
        crud.add(eliminar);

        datos.add(nombre);
        datos.add(nombre_TX);
        datos.add(telefono);
        datos.add(telefono_TX);
        datos.add(correo);
        datos.add(correo_TX);
        datos.add(contraseña);
        datos.add(contraseña1);
        datos.add(confirmar);
        datos.add(crud);

        cabecera.add(datos);

        contenedor.add(cabecera, BorderLayout.CENTER);

        setSize(500, 800);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == inicio) {
            dispose();
            inicio_usuario a = new inicio_usuario();
            a.setVisible(true);
        }

        if (e.getSource() == yo) {
            dispose();
            perfil a = new perfil();
            a.setVisible(true);
        }
         if (e.getSource() == descubrir) {
            dispose();
            buscar a = new buscar();
            Controlador_alojamiento b = new Controlador_alojamiento(a);
            a.setVisible(true);
        }

        if (e.getSource() == modificar) {
            nombre_TX.setEditable(true);
            correo_TX.setEditable(true);
            telefono_TX.setEditable(true);
            contraseña1.setEditable(true);
            confirmar.setVisible(true);
        }
        if (e.getSource() == confirmar) {
            confirmar.setVisible(false);
            nombre_TX.setEditable(false);
            correo_TX.setEditable(false);
            telefono_TX.setEditable(false);
            contraseña1.setEditable(false);
        }
          if (e.getSource() == viaje) {
            Usuario usu = datosguardados.getUsuarioactual();
            if (usu == null) {
                dispose();
                Inicio inicio = new Inicio();
                inicio.setVisible(true);

            } else {
                dispose();
                miviaje_usuario a = new miviaje_usuario();
                a.setVisible(true);
            }
        }
    }
    
    public static void main(String[] args) {
        datos_usuario a = new datos_usuario();
        a.setVisible(true);
    }

}
