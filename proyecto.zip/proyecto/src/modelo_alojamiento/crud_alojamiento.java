/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_alojamiento;

import java.util.List;
import modelo_gerente.gerente;

/**
 *
 * @author Marely
 */
public interface crud_alojamiento<Alojamiento> {

    public int agregaralojamiento(alojamiento tr);

    public int modificaralojamiento(alojamiento tr);

    public int inactivaralojamiento(alojamiento tr);

    public List<Alojamiento> obtenerAlojamientos();

}
