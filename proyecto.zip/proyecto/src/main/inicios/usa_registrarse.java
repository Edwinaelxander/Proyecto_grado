/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main.inicios;

import Db.Conexion;
import controlador.Controlador_usuarios;
import inicios_gui.Registrarse;

/**
 *
 * @author Marely
 */
public class usa_registrarse {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Registrarse i = new Registrarse();
        Controlador_usuarios cona = new Controlador_usuarios(i);
        
        Conexion con = new Conexion();
        con.getCon();
        
        
        i.setVisible(true);
       
        
    }

}
