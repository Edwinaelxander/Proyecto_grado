/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main.inicios;

import Db.Conexion;
import controlador.Controlador_iniciosesion;
import inicios_gui.Iniciar_sesion;

/**
 *
 * @author Marely
 */
import javax.swing.*;

public class usa_iniciosesion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
           
  
        

           
        Iniciar_sesion i = new Iniciar_sesion();
        Controlador_iniciosesion c = new Controlador_iniciosesion(i);

        Conexion con = new Conexion();
        con.getCon();
        i.correo_TX.setText("rece1");
        i.contraseñapass.setText("1");

        i.setVisible(true);

         
                 }

                

}
