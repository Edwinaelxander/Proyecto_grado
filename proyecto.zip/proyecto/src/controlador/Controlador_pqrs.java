/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo_pqrs.Pqrs;
import modelo_pqrs.PqrsDao;
import vistas_admind.Perfil_admin;
import vistas_admind.Pqrs_admin;
import vistas_admind.Responderpqrs;
import vistas_usuario.Pqrs_usuario;

/**
 *
 * @author Marely
 */
public class Controlador_pqrs implements ActionListener {

    private Pqrs t = new Pqrs();
    private PqrsDao dao = new PqrsDao();
    private Pqrs_usuario vista = new Pqrs_usuario();
    private Responderpqrs vista2;

    public Controlador_pqrs(Pqrs_usuario v) {
        this.vista = v;
        this.vista.enviar.addActionListener(this);
    }

    public Controlador_pqrs(Responderpqrs vista2) {
        this.vista2 = vista2;
        this.vista2.enviar.addActionListener(this);
        this.vista2.atras.addActionListener(this);
        this.vista2.ico.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.enviar) {
            agregarpqrs();
        }

        if (e.getSource() == vista2.enviar) {
            responder();
        }
        if (e.getSource() == vista2.atras) {
            vista2.dispose();
            Pqrs_admin a=new Pqrs_admin();
            a.setVisible(true);

        }
        if(e.getSource()==vista2.ico){
                vista2.dispose();
            Perfil_admin a=new Perfil_admin();
            a.setVisible(true);
            
        }

    }

    private void agregarpqrs() {
        int resultado;
        String tipo = vista.tipo_box.getSelectedItem().toString();
        String descripcion = vista.descripcion_area.getText().toString();
        String alojamiento = vista.alojamiento_Tx.getText().toString();
        t.setTipo(tipo);
        t.setDescripcion(descripcion);
        t.setAlojamiento(alojamiento);
        resultado = dao.agregarpqrs(t);
        if (resultado == 1) {
            JOptionPane.showMessageDialog(vista, "se inserto correctamente su " + vista.tipo_box.getSelectedItem());
        } else {
            JOptionPane.showMessageDialog(vista, "error en la insersion" + JOptionPane.ERROR_MESSAGE);
        }

    }

    private void responder() {
        try {
            String respuesta = vista2.mensaje.getText().toString();

            if (respuesta.isEmpty()) {
                JOptionPane.showMessageDialog(vista2, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            t.setRespuesta(respuesta);
            int resultado = dao.responder(t);

            if (resultado == 1) {
                JOptionPane.showMessageDialog(vista2, "pqrs respondida con exito", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(vista2, "Error en responder pqrs", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, "Error inesperado", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
