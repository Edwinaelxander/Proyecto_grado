/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import datos.datosguardados;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.util.Calendar;
import javax.swing.JLabel;

import javax.swing.table.DefaultTableModel;
import modelo_reserva.Reserva;
import modelo_reserva.ReservaDao;
import vistas_usuario.Reserva_usuario;
import javax.swing.JOptionPane;
import modelo_alojamiento.alojamiento;
import modelo_habitaciones.habitacion;
import modelo_pagos.Pagar;
import vistas_recepcionista.Generar_reserva_recepcionista;
import vistas_recepcionista.pagar_recerva_recepcionista;
import vistas_usuario.Detalle_miviaje_usuario;
import vistas_usuario.miviaje_usuario;
import vistas_usuario.pagar_usuario;

/**
 *
 * @author Marely
 */
public class Controlador_reserva implements ActionListener {

    private int num;

    private habitacion t = new habitacion();
    private alojamiento a = new alojamiento();
    private Reserva r = new Reserva();
    private ReservaDao dao = new ReservaDao();
    private Reserva_usuario vista;
    private miviaje_usuario vista2;
    private Detalle_miviaje_usuario vista3;
    private Generar_reserva_recepcionista vista4;

    public Controlador_reserva(Reserva_usuario r) {
        this.vista = r;
        this.vista.pagar.addActionListener(this);

    }

    public Controlador_reserva(Generar_reserva_recepcionista vista4) {
        this.vista4 = vista4;
        this.vista4.pagar.addActionListener(this);
    }

    public Controlador_reserva(miviaje_usuario m) {
        vista2 = m;
        // buscar();
    }

    public Controlador_reserva(Detalle_miviaje_usuario d) {
        vista3 = d;
        buscar1();
        vista3.confirmar.addActionListener(this);
        vista3.cancelar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (vista3 != null) {
            if (e.getSource() == vista3.confirmar) {
                modificarreserva();
            }
        }
        if (vista3 != null) {
            if (e.getSource() == vista3.cancelar) {
                int resultado = JOptionPane.showConfirmDialog(vista3, "¿Estás seguro de querer cancelar la reserva?", "Confirmación", JOptionPane.YES_NO_OPTION);
                if (resultado == JOptionPane.YES_OPTION) {
                    cancelarreserva();
                    vista3.dispose();;
                    miviaje_usuario a = new miviaje_usuario();
                    a.setVisible(true);

                }
            }
        }

        if (vista4 != null) {
            if (e.getSource() == vista4.pagar) {
                if (totalpagar() == 1) {
                    if (insertarReserva() == 1) {
                        vista4.dispose();
                        pagar_recerva_recepcionista a = new pagar_recerva_recepcionista();
                        Controlador_pagar c = new Controlador_pagar(a);
                        a.setVisible(true);

                    }
                }

            }
        }

        if (vista != null) {

            if (e.getSource() == vista.pagar) {
                if (totalpagar() == 1) {
                    if (insertarReserva() == 1) {
                        vista.dispose();
                        pagar_usuario a = new pagar_usuario();
                        Controlador_pagar c = new Controlador_pagar(a);
                        a.setVisible(true);
                    }
                }
            }
        }

    }

    private int totalpagar() {
        habitacion h = datosguardados.getHabitacionActual();
        float valor = h.getPrecio();

        int habitaciones = 0;
        java.util.Date fechaentrada, fechasalida;
        if (vista == null) {
            habitaciones = Integer.parseInt(vista4.habitaciones_TX.getText());
            fechaentrada = vista4.fechaentrada.getDate();
            fechasalida = vista4.fechasalidad.getDate();

        } else {
            habitaciones = Integer.parseInt(vista.habitaciones_TX.getText());
            fechaentrada = vista.fechaentrada.getDate();
            fechasalida = vista.fechasalidad.getDate();

        }

        Calendar calSalida = Calendar.getInstance();
        calSalida.setTime(fechasalida);

        Calendar calEntrada = Calendar.getInstance();
        calEntrada.setTime(fechaentrada);

        long diferenciaMillis = calSalida.getTimeInMillis() - calEntrada.getTimeInMillis();
        long diasDiferencia = diferenciaMillis / (1000 * 60 * 60 * 24);
        if (diasDiferencia < 0) {
            JOptionPane.showMessageDialog(vista, "Cantidad de dias no valido, retifica las fechas");
            return 0;
        }

        double pagar = valor * habitaciones * diasDiferencia;
        System.out.println("pagar: " + pagar);

        Pagar p = new Pagar();
        p.setValorpagar(pagar);
        datosguardados.setPagaractual(p);
        return 1;
    }

    private int insertarReserva() {
        java.util.Date fechaentrada, fechasalida;
        String habitacionesStr;
        try {
            if (vista != null) {
                fechaentrada = vista.fechaentrada.getDate();
                fechasalida = vista.fechasalidad.getDate();
                habitacionesStr = vista.habitaciones_TX.getText().trim();
            } else {
                fechaentrada = vista4.fechaentrada.getDate();
                fechasalida = vista4.fechasalidad.getDate();
                habitacionesStr = vista4.habitaciones_TX.getText().trim();
            }

            if (habitacionesStr.isEmpty()) {
                JOptionPane.showMessageDialog(vista, "Debe completar todos los campos", "Error", JOptionPane.ERROR_MESSAGE);
                return 0;
            }

            int habitaciones = Integer.parseInt(habitacionesStr);
            num  += habitaciones;

            if (fechaentrada == null || fechasalida == null) {
                JOptionPane.showMessageDialog(vista, "Debe seleccionar fechas válidas", "Error", JOptionPane.ERROR_MESSAGE);
                return 0;
            }

            Date fechaentradaSQL = new Date(fechaentrada.getTime());
            Date fechasalidaSQL = new Date(fechasalida.getTime());

            r.setFechaentrada(fechaentradaSQL);
            r.setFechasalida(fechasalidaSQL);

            r.setC_habitaciones(habitaciones);
            int resultado = 3;
            int[] idsReserva = new int[num];

            for (int i = 0; i < num; i++) {
                if (vista != null) {
                    resultado = dao.agregarreserva(r);
                } else {
                    resultado = dao.reservarecepcionista(r);
                }
                Reserva reservaActual = datosguardados.getReservaactual();
                Pagar p = new Pagar();

                int idReserva = reservaActual.getIdreserva();
                idsReserva[i] = idReserva;
                p.setIdreserva(idsReserva);

            }

            if (resultado == 1) {
                JOptionPane.showMessageDialog(vista, "Reserva insertada correctamente");
                return 1;
            } else {
                JOptionPane.showMessageDialog(vista, "Error en la inserción", "Error", JOptionPane.ERROR_MESSAGE);
                return 0;
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(vista, "Error: Los campos 'Teléfono' y 'Cantidad de Habitaciones' deben ser números enteros válidos", "Error", JOptionPane.ERROR_MESSAGE);
            return 0;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, "Error en la inserción de la reserva: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);

            return 0;
        }
    }

    private void buscar1() {

        int resultado = dao.detallereserva(r, a, t);

        vista3.fechaEntrada.setDate(r.getFechaentrada());
        vista3.fechaSalida.setDate(r.getFechasalida());
        vista3.tipoHabitacion.setText(t.getTipo());
        vista3.vistaHabitacion.setText(t.getVista());
        vista3.precioHabitacion.setText("" + t.getPrecio());
        vista3.nombreAlojamiento.setText(a.getNombre());
        vista3.direccionAlojamiento.setText(a.getDireccion());
        vista3.ID.setText("" + r.getIdreserva());
        int id = r.getIdreserva();
        int[] ids = new int[]{id};
        vista3.numHabitaciones1.setText("" + r.getHabitacion());
        Pagar p = new Pagar();
        p.setIdreserva(ids);
        p.setValorpagar(t.getPrecio());
        datosguardados.setPagaractual(p);
//          
//          System.out.print(r.getNombre());
//          System.out.print(t.getTipo());
//          System.out.print(a.getNombre());

    }

    private void modificarreserva() {

        java.util.Date fechaentrada = vista3.fechaEntrada.getDate();
        java.util.Date fechasalida = vista3.fechaSalida.getDate();

        if (fechaentrada == null || fechasalida == null) {
            JOptionPane.showMessageDialog(vista, "Debe seleccionar fechas válidas", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {

            Date fechaentradaSQL = new Date(fechaentrada.getTime());
            Date fechasalidaSQL = new Date(fechasalida.getTime());

            r.setFechaentrada(fechaentradaSQL);
            r.setFechasalida(fechasalidaSQL);

            int resultado = dao.modificarreserva(r);
            if (resultado == 1) {
                JOptionPane.showMessageDialog(vista, "Reserva modificada correctamente");

            } else {
                JOptionPane.showMessageDialog(vista, "Error en la modificacion", "Error", JOptionPane.ERROR_MESSAGE);

            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(vista, "Por favor ingrese un número de personas o habitaciones válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    }

    public void cancelarreserva() {

        int resultado = dao.modificarestadoreserva(1);
        if (resultado == 1) {
            JOptionPane.showMessageDialog(vista, "cancelacion exitosamente");
        }
    }

}
