/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo_comentario.Comentario;
import modelo_comentario.ComentarioDao;
import vistas_usuario.alojamiento_usuario;

/**
 *
 * @author Marely
 */
public class Controlador_comentarios implements ActionListener {

    Comentario c = new Comentario();
    ComentarioDao dao = new ComentarioDao();
    alojamiento_usuario vista = new alojamiento_usuario();

    public Controlador_comentarios(alojamiento_usuario a) {
        this.vista = a;
        this.vista.enviar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.enviar) {
            insertar();
            vista.comentario_TX.setText("");
            vista.calificacion_TX.setText("");
        }
    }
    
    
     private  void insertar() {
         try {
        String comentar = vista.comentario_TX.getText().trim();
        String calificacionStr = vista.calificacion_TX.getText().trim(); 
        
        if (comentar.isEmpty() || calificacionStr.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Debe completar todos los campos", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int calificacion = Integer.parseInt(calificacionStr);
        
        if (calificacion < 0 || calificacion > 5) {
            JOptionPane.showMessageDialog(vista, "La calificación debe estar entre 0 y 10", "Error", JOptionPane.ERROR_MESSAGE);
            return; 
        }
        
        c.setComentario(comentar);
        c.setCalificacion(calificacion);
        
        int resultado = dao.agregarcomentario(c);
        
        if (resultado == 1) {
            JOptionPane.showMessageDialog(vista, "Comentario enviado con éxito");
        } 
        if(resultado==2){
                            JOptionPane.showMessageDialog(vista, "Debes estar registrado","Error",JOptionPane.ERROR_MESSAGE);

            
        }else {
            JOptionPane.showMessageDialog(vista, "Error", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(vista, "Error: La calificación debe ser un número entero válido", "Error", JOptionPane.ERROR_MESSAGE);
    }
     }


}
