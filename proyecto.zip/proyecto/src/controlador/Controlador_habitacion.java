/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import datos.datosguardados;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo_alojamiento.alojamiento;
import modelo_habitaciones.habitacion;
import modelo_habitaciones.habitacionDao;
import ventanas_emergentes.Inactivar_habitacion;
import vistas_gerentes.Detalles_habitacion;
import vistas_gerentes.Registrar_habitaciones;
import vistas_gerentes.Habitaciones;
import vistas_gerentes.Modificar_habitacion;
import vistas_recepcionista.Detalles_habitacion_recepcionista;
import vistas_recepcionista.Modificar_habitacion_recepcionista;
import vistas_recepcionista.Registrar_habitaciones_recepcionista;
import vistas_usuario.detalles_habitacion_usuario;

/**
 *
 * @author Marely
 */
public class Controlador_habitacion implements ActionListener {

    private habitacion habitacionseleccionada;
    private habitacion t = new habitacion();
    private habitacionDao dao = new habitacionDao();
    public Registrar_habitaciones vista = new Registrar_habitaciones();
    public Detalles_habitacion vista1 = new Detalles_habitacion();
    public Modificar_habitacion vista2 = new Modificar_habitacion();
    public Inactivar_habitacion vista3 = new Inactivar_habitacion();
    public detalles_habitacion_usuario vista4 = new detalles_habitacion_usuario();
    public Registrar_habitaciones_recepcionista vista5;
    private Detalles_habitacion_recepcionista vista6;
    private Modificar_habitacion_recepcionista vista7;

    public Controlador_habitacion(Modificar_habitacion_recepcionista vista7) {
        this.vista7 = vista7;
        this.vista7.confirmar.addActionListener(this);
    }

    public Controlador_habitacion(Detalles_habitacion_recepcionista a, habitacion habitacionseleccionada) {
        this.vista6 = a;
        this.habitacionseleccionada = habitacionseleccionada;
        this.vista6.inactivar.addActionListener(this);
        buscar2();
    }

    public Controlador_habitacion(Registrar_habitaciones_recepcionista vista5) {
        this.vista5 = vista5;
        this.vista5.registrar.addActionListener(this);
    }

    public Controlador_habitacion(Registrar_habitaciones v) {
        this.vista = v;
        this.vista.registrar.addActionListener(this);

    }

    public Controlador_habitacion(Detalles_habitacion a, habitacion habitacionseleccionada) {
        this.vista1 = a;
        this.habitacionseleccionada = habitacionseleccionada;
        this.vista1.inactivar.addActionListener(this);
        buscar();
    }

    public Controlador_habitacion(detalles_habitacion_usuario detalles) {
        this.vista4 = detalles;
        buscar1();
    }

    public Controlador_habitacion(Modificar_habitacion m) {
        this.vista2 = m;
        this.vista2.confirmar.addActionListener(this);
    }

    public Controlador_habitacion(Inactivar_habitacion i) {
        this.vista3 = i;
        this.vista3.no.addActionListener(this);
        this.vista3.si.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.registrar) {
            setinsertar();
        }
        if (vista5 != null) {
            if (e.getSource() == vista5.registrar) {
                setinsertar();
            }
        }

        if (e.getSource() == vista2.confirmar) {
            vista2.confirmar.setVisible(false);
            vista2.cancelar.setVisible(false);
            modificar1(1);
            vista2.modificar.setVisible(true);
            vista2.tipo_TX.setEditable(false);
            vista2.cantidad_TX.setEditable(false);
            vista2.precio_TX.setEditable(false);
            vista2.areaservicios.setEditable(false);

        }
        if (vista7 != null) {
            if (e.getSource() == vista7.confirmar) {
                vista7.confirmar.setVisible(false);
                vista7.cancelar.setVisible(false);
                modificar1(2);
                vista7.modificar.setVisible(true);
                vista7.tipo_TX.setEditable(false);
                vista7.cantidad_TX.setEditable(false);
                vista7.precio_TX.setEditable(false);
                vista7.areaservicios.setEditable(false);

            }
        }
        if (e.getSource() == vista1.inactivar) {
            int resultado = JOptionPane.showConfirmDialog(vista1, "¿Estás seguro de querer inhabilitar esta habitacion?", "Confirmación", JOptionPane.YES_NO_OPTION);
            if (resultado == JOptionPane.YES_OPTION) {
                inactivar();
            }
        }
        if (e.getSource() == vista6.inactivar) {
            int resultado = JOptionPane.showConfirmDialog(vista6, "¿Estás seguro de querer inhabilitar esta habitacion?", "Confirmación", JOptionPane.YES_NO_OPTION);
            if (resultado == JOptionPane.YES_OPTION) {
                inactivar();
            }
        }

    }

    public void setinsertar() {
        try {

            alojamiento alo = datosguardados.getAlojamientoActual();
            int alojamientoid = alo.getId();

            String tipo = vista.tipo_TX.getText().toString();
            String vistas = vista.vista_TX.getText().toString();
            String cantidadStr = vista.cantidad_TX.getText().toString();
            String precioStr = vista.precio_TX.getText().toString();
            String servicios = vista.areaservicios.getText().toString();
            String c_habitaciones = vista.c_habitaciones_TX.getText().toString();

            if (tipo.isEmpty() || vistas.isEmpty() || cantidadStr.isEmpty() || precioStr.isEmpty() || servicios.isEmpty() || c_habitaciones.isEmpty()) {
                JOptionPane.showMessageDialog(vista, "Por favor complete todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
            }

            int cantidad = Integer.parseInt(cantidadStr);
            int precio = Integer.parseInt(precioStr);
            int c_habitacion = Integer.parseInt(c_habitaciones);

            t.setAlojamientoid(alojamientoid);
            t.setTipo(tipo);
            t.setVista(vistas);
            t.setCantidad(cantidad);
            t.setPrecio(precio);
            t.setServicios(servicios);
            t.setCantidad_habitaciones(c_habitacion);

            int resultado = dao.verificarparainsertar(t);

            if (resultado == 1) {
                JOptionPane.showMessageDialog(vista, "Se insertó correctamente");
            } else if (resultado == 3) {
                JOptionPane.showMessageDialog(vista, "\"La cantidad de habitaciones que estás intentando registrar "
                        + "supera la capacidad máxima del hotel."
                        + " Por favor, revisa la cantidad de habitaciones disponibles"
                        + " y ajusta tu registro en consecuencia.\"");

            } else {
                JOptionPane.showMessageDialog(vista, "Error en la inserción", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(vista, "Cantidad y precio deben ser números", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void buscar() {
        int resultado;
        habitacion a = datosguardados.getHabitacionActual();
        int id = a.getHabitacionid();
        t.setHabitacionid(id);

        resultado = dao.info(t);

        vista1.tipo.setText("tipo de habitacion: " + t.getTipo());
        vista1.vista.setText("tipo de vista: " + t.getVista());
        vista1.cantidad.setText("cantidad de huespedes " + t.getCantidad());
        vista1.precio.setText("PRECIO: " + t.getPrecio());
        vista1.servicio.setText("SERVICIOS: $" + t.getServicios());
    }

    private void buscar2() {
        int resultado;
        habitacion a = datosguardados.getHabitacionActual();
        int id = a.getHabitacionid();
        t.setHabitacionid(id);

        resultado = dao.info(t);

           vista6.tipo.setText("tipo de habitacion: " + t.getTipo());
        vista6.vista.setText("tipo de vista: " + t.getVista());
        vista6.cantidad.setText("cantidad de huespedes " + t.getCantidad());
        vista6.precio.setText("PRECIO: " + t.getPrecio());
        vista6.servicio.setText("SERVICIOS: $" + t.getServicios());
    }

    private void buscar1() {
        int resultado;
        habitacion a = datosguardados.getHabitacionActual();
        int id = a.getHabitacionid();
        t.setHabitacionid(id);
        resultado = dao.info(t);
       vista4.tipo.setText("tipo de habitacion: " + t.getTipo());
        vista4.vista.setText("tipo de vista: " + t.getVista());
        vista4.cantidad.setText("cantidad de huespedes " + t.getCantidad());
        vista4.precio.setText("PRECIO: " + t.getPrecio());
        vista4.servicio.setText("SERVICIOS: $" + t.getServicios());
    }

    private void modificar1(int a) {
        try {
            int resultado;
            habitacion alo = datosguardados.getHabitacionActual();
            String tipo, cantidadStr, precioStr, servicio;

            int habitacionid = alo.getHabitacionid();

            if (a == 1) {
                tipo = vista2.tipo_TX.getText().toString();
                cantidadStr = vista2.cantidad_TX.getText().toString();
                precioStr = vista2.precio_TX.getText().toString();
                servicio = vista2.areaservicios.getText().toString();
            } else {
                tipo = vista7.tipo_TX.getText().toString();
                cantidadStr = vista7.cantidad_TX.getText().toString();
                precioStr = vista7.precio_TX.getText().toString();
                servicio = vista7.areaservicios.getText().toString();
            }

            if (tipo.isEmpty() || cantidadStr.isEmpty() || precioStr.isEmpty() || servicio.isEmpty()) {
                JOptionPane.showMessageDialog(vista, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int cantidad = Integer.parseInt(cantidadStr);
            Float precio = Float.parseFloat(precioStr);

            t.setHabitacionid(habitacionid);
            t.setTipo(tipo);
            t.setCantidad(cantidad);
            t.setPrecio(precio);
            t.setServicios(servicio);

            resultado = dao.modificarhabitacion(t);

            if (resultado == 1) {
                JOptionPane.showMessageDialog(vista, "Se modificó correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(vista, "Error en la modificación", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(vista, "Error: Los campos de cantidad y precio deben ser valores numéricos", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, "Error inesperado", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void inactivar() {
        int resultado;
        habitacion alo = datosguardados.getHabitacionActual();

        int habitacionid = alo.getHabitacionid();
        t.setHabitacionid(habitacionid);
        resultado = dao.inactivar(t);
        if (resultado == 1) {

            JOptionPane.showMessageDialog(vista1, "se inactivo correctamente");
        } else {
            JOptionPane.showMessageDialog(vista1, "error en la modificacion" + JOptionPane.ERROR_MESSAGE);
        }

    }
}
