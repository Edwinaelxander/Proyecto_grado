/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo_gerente.gerente;
import modelo_gerente.gerenteDao;
import vistas_admind.Registrar_gerentes;

/**
 *
 * @author Marely
 */
public class Controlador_gerente implements ActionListener {

    public gerenteDao dao = new gerenteDao();
    public gerente t = new gerente();
    public Registrar_gerentes vista = new Registrar_gerentes();
    public boolean flag = false;
   

    public Controlador_gerente(Registrar_gerentes v) {
    this.vista = v;
    this.vista.registrar.addActionListener(this); // Add ActionListener for the registrar button
}


    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == vista.registrar) {
            setinsertar();
        }
    }
        
     public void setinsertar() {
    int resultado;
    
    try {
        String nombre = vista.nombre_TX.getText().toString();
        int cedula = Integer.parseInt(vista.cedula_TX.getText().toString());
        String telefonoStr = vista.telefono_TX.getText().toString();
        String correo = vista.correo_TX.getText().toString();
        String contraseña = vista.contraseña_TX.getText().toString();
        
        if (nombre.isEmpty() || correo.isEmpty() || contraseña.isEmpty() || telefonoStr.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Error: Todos los campos son obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        
        if (telefonoStr.length() != 10 ) {
            JOptionPane.showMessageDialog(vista, "Error: El teléfono debe tener 10 dígitos numéricos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

      

        t.setNombre(nombre);
        t.setCedula(cedula);
        t.setTelefono(telefonoStr);
        t.setCorre(correo);
        t.setContraseña(contraseña);
        
        resultado = dao.setagregargerente(t);
        
        if (resultado == 1) {
            JOptionPane.showMessageDialog(vista, "Se insertó correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(vista, "Error: No se pudo insertar el gerente.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(vista, "Error: La cédula y el teléfono deben ser números válidos.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}
}
