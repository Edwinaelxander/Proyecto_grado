/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import datos.datosguardados;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo_alojamiento.alojamiento;
import modelo_alojamiento.alojamientoDao;
import modelo_gerente.gerente;
import modelo_usuario.Usuario;
import ventanas_emergentes.Inactivar_alojamiento;
import vistas_gerentes.Detalles_alojamientos;
import vistas_gerentes.Modificar_alojamiento;
import vistas_gerentes.Principal_gerente;
import vistas_gerentes.Registrar_alojamiento;
import vistas_usuario.buscar;

/**
 *
 * @author Marely
 */
public class Controlador_alojamiento implements ActionListener {

    private alojamiento t = new alojamiento();
    private alojamientoDao dao = new alojamientoDao();
    private Registrar_alojamiento vista = new Registrar_alojamiento();
    private Modificar_alojamiento vista1 = new Modificar_alojamiento();
    private Inactivar_alojamiento vista3 = new Inactivar_alojamiento();
    private buscar vista4 = new buscar();

    public Controlador_alojamiento(Registrar_alojamiento v) {
        this.vista = v;
        this.vista.registrar.addActionListener(this);

    }

    public Controlador_alojamiento(Modificar_alojamiento m) {
        this.vista1 = m;
        this.vista1.confirmar.addActionListener(this);
    }

    public Controlador_alojamiento(Inactivar_alojamiento i) {
        this.vista3 = i;
        this.vista3.si.addActionListener(this);
        this.vista3.no.addActionListener(this);

    }

    public Controlador_alojamiento(buscar b) {
        vista4 = b;
        vista4.buscar.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == vista.registrar) {
            setinsertar();
        }

        if (ae.getSource() == vista1.confirmar) {
            modificar();
            vista1.confirmar.setVisible(false);
            vista1.cancelar.setVisible(false);
        }

        if (ae.getSource() == vista3.no) {
            vista3.dispose();
            Detalles_alojamientos a = new Detalles_alojamientos();
            a.setVisible(true);

        }

        if (ae.getSource() == vista3.si) {
            inactivar();
            vista3.dispose();
            Principal_gerente a = new Principal_gerente();
            a.setVisible(true);
        }

        if (ae.getSource() == vista4.buscar) {

        }
    }

    private void setinsertar() {
        try {
            int resultado;

            String nitStr = vista.nit_TX.getText().toString();
            String nombre = vista.nombre_TX.getText().toString();
            String correo = vista.correo_TX.getText().toString();
            String telefonoStr = vista.telefono_TX.getText().toString();
            String direccion = vista.direccion_TX.getText().toString();
            String c_habitacionesstr = vista.c_habitaciones_TX.getText().toString();
            String descripcion = vista.descripcionarea.getText();
            byte[] imagenBytes = leerImagen(vista.archivoSeleccionado);
            
            if (nitStr.isEmpty() || nombre.isEmpty() || correo.isEmpty() || telefonoStr.isEmpty() || direccion.isEmpty() || c_habitacionesstr.isEmpty() || descripcion.isEmpty()) {
                JOptionPane.showMessageDialog(vista, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int nit = Integer.parseInt(nitStr);

            int c_habitaciones = Integer.parseInt(c_habitacionesstr);

            if (telefonoStr.length() != 10) {
                JOptionPane.showMessageDialog(vista, "El número de teléfono debe tenerc 10 dígitos", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            gerente miGerente = datosguardados.getGerenteActual();
            int gerenteID = miGerente.getGerenteid();

            t.setNit(nit);
            t.setNombre(nombre);
            t.setCorreo(correo);
            t.setTelefono(telefonoStr);
            t.setDireccion(direccion);
            t.setGerente(gerenteID);
            t.setHabticacionesc(c_habitaciones);
            t.setDescripcion(descripcion);
            t.setImagen(imagenBytes);

            resultado = dao.agregaralojamiento(t);

            if (resultado == 1) {
                JOptionPane.showMessageDialog(vista, "Se insertó correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(vista, "Error en la inserción", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(vista, "Error: Nit, teléfono y Cantidad de habitaciones deben ser valores numéricos", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, "Error inesperado", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private byte[] leerImagen(File archivo) {
        try {
            FileInputStream fis = new FileInputStream(archivo);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int len;
            while ((len = fis.read(buffer)) > -1) {
                bos.write(buffer, 0, len);
            }
            bos.flush();
            return bos.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private void modificar() {
        try {
            int resultado;
            alojamiento alo = datosguardados.getAlojamientoActual();

            int alojamientoid = alo.getId();
            String nombre = vista1.nombre_TX.getText().toString();
            String correo = vista1.correo_TX.getText().toString();
            String telefonoStr = vista1.telefono_TX.getText().toString();
            String descripcion = vista1.descripcion_TX.getText().toString();

            if (nombre.isEmpty() || correo.isEmpty() || telefonoStr.isEmpty() || descripcion.isEmpty()) {
                JOptionPane.showMessageDialog(vista, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
                vista1.nombre_TX.setEditable(false);
                vista1.correo_TX.setEditable(false);
                vista1.telefono_TX.setEditable(false);
                vista1.descripcion_TX.setEditable(false);
                return;
            }

            if (telefonoStr.length() != 10) {
                JOptionPane.showMessageDialog(vista, "El número de teléfono debe tener 10 dígitos", "Error", JOptionPane.ERROR_MESSAGE);
                vista1.nombre_TX.setEditable(false);
                vista1.correo_TX.setEditable(false);
                vista1.telefono_TX.setEditable(false);
                return;
            }

            t.setId(alojamientoid);
            t.setNombre(nombre);
            t.setCorreo(correo);
            t.setTelefono(telefonoStr);
            t.setDescripcion(descripcion);
            resultado = dao.modificaralojamiento(t);

            if (resultado == 1) {
                JOptionPane.showMessageDialog(vista, "Se modificó correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(vista, "Error en la modificación", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(vista, "Error: El número de teléfono debe ser un valor numérico", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, "Error inesperado", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void inactivar() {
        int resultado;
        alojamiento alo = datosguardados.getAlojamientoActual();

        int alojamientoid = alo.getId();
        t.setId(alojamientoid);
        resultado = dao.inactivaralojamiento(t);
        if (resultado == 1) {

            JOptionPane.showMessageDialog(vista, "se inactivo correctamente");
        } else {
            JOptionPane.showMessageDialog(vista, "error en la modificacion" + JOptionPane.ERROR_MESSAGE);
        }

    }

//    private void buscar(){
////        String nombre=vista4.buscar_Tx.getText();
////        t.setNombre(nombre);
////        int resultado=dao.buscar(t);
////        if (resultado == 1) {
////              
////            } else {
////                JOptionPane.showMessageDialog(vista, "no se encontro ese alojamiento");
////            }
////        
////    }
}
