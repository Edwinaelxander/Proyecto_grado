/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import datos.datosguardados;
import inicios_gui.Cambiar_contraseña;
import inicios_gui.Iniciar_sesion;
import inicios_gui.Recuperar_contraseña;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.admin.Administrador;
import modelo_usuario.Usuario;
import modelo_usuario.usuarioDao;
import modelo.admin.AdministradorDao;
import modelo_gerente.gerente;
import modelo_gerente.gerenteDao;
import modelo_recepcionista.Recepcionista;
import modelo_recepcionista.RecepcionistaDao;

import vistas_admind.Principal;
import vistas_gerentes.Habitaciones;
import vistas_gerentes.Principal_gerente;
import vistas_recepcionista.inicio_recepcionista;
import vistas_usuario.inicio_usuario;

/**
 *
 * @author Marely
 */
public class Controlador_iniciosesion implements ActionListener {

    public Usuario t = new Usuario();
    public usuarioDao dao = new usuarioDao();

    Administrador tadmin = new Administrador();
    AdministradorDao daoadmin = new AdministradorDao();

    gerente tgerente = new gerente();
    gerenteDao daogerente = new gerenteDao();

    Recepcionista trecep = new Recepcionista();
    RecepcionistaDao daorecep = new RecepcionistaDao();

    private Iniciar_sesion vista;

    private Recuperar_contraseña vista1 = new Recuperar_contraseña();

    private Cambiar_contraseña vista2 = new Cambiar_contraseña();

    public Controlador_iniciosesion(Cambiar_contraseña vista2) {
        this.vista2 = vista2;
        this.vista2.enviar.addActionListener(this);
    }

    public Controlador_iniciosesion(Recuperar_contraseña vista1) {
        this.vista1 = vista1;
        this.vista1.enviar.addActionListener(this);
    }

    public Controlador_iniciosesion(Iniciar_sesion v) {
        this.vista = v;
        this.vista.iniciar_sesion.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == vista1.enviar) {
            if (buscar_modificar() == 1) {
                vista1.dispose();
                Cambiar_contraseña a = new Cambiar_contraseña();
                Controlador_iniciosesion b = new Controlador_iniciosesion(a);
                a.setVisible(true);

            }

        } else if (e.getSource() == vista2.enviar) {
            if (modificar() == 1) {
                inicio_usuario a = new inicio_usuario();

                a.setVisible(true);
            }
        } else if (e.getSource() == vista.iniciar_sesion) {
            if (vista.correo_TX.getText().toString().isEmpty() || vista.contraseña.getText().toString().isEmpty()) {
                JOptionPane.showMessageDialog(vista, "Por favor complete todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);

            } else {

                if (setbuscar() == 1) {
                    vista.dispose();
                    inicio_usuario a = new inicio_usuario();
                    a.setVisible(true);

                } else {
                    if (setbuscarAmind() == 1) {
                        vista.dispose();
                        Principal a = new Principal();
                        a.setVisible(true);
                    } else {
                        if (setbuscargerente() == 1) {
                            vista.dispose();
                            Principal_gerente a = new Principal_gerente();
                            a.setVisible(true);

                        } else {
                            if (buscarrecepcionista() == 1) {
                                vista.dispose();
                                inicio_recepcionista a = new inicio_recepcionista();
                                a.setVisible(true);
                            } else {

                                JOptionPane.showMessageDialog(null, "correo o contraseña incorrectas");
                            }
                        }
                    }
                }

            }
        }

    }

    private int setbuscar() {
        int resultado;
        String correo = vista.correo_TX.getText().toString().trim();
        String contraseña = vista.contraseñapass.getText().toString().trim();
        t.setCorre(correo);
        t.setContraseña(contraseña);
        resultado = dao.setbuscar(t);
        if (resultado == 1) {

//            JOptionPane.showMessageDialog(vista, "correctamente");
            return 1;
        } else {

            //    JOptionPane.showMessageDialog(vista, "error de busquedad" + JOptionPane.ERROR_MESSAGE);
            return 0;
        }
    }

    private int setbuscarAmind() {
        int resultado;
        String correo = vista.correo_TX.getText().toString().trim();
        String contraseña = vista.contraseñapass.getText().toString().trim();
        tadmin.setCorreo(correo);
        tadmin.setContraseña(contraseña);
        resultado = daoadmin.buscar(tadmin);

        if (resultado == 1) {
//            JOptionPane.showMessageDialog(vista, "correctamente");
            return 1;
        } else {
            //     JOptionPane.showMessageDialog(vista, "error de busquedad" + JOptionPane.ERROR_MESSAGE);
            return 0;
        }
    }

    private int setbuscargerente() {
        int resultado;
        String correo = vista.correo_TX.getText().toString().trim();
        String contraseña = vista.contraseñapass.getText().toString().trim();
        tgerente.setCorre(correo);
        tgerente.setContraseña(contraseña);
        resultado = daogerente.setbuscar(tgerente);
//       System.out.print("id "+ tgerente.getGerenteid());
        if (resultado == 1) {
//            JOptionPane.showMessageDialog(vista, "correctamente");
            return 1;
        } else {
            //   JOptionPane.showMessageDialog(vista, "error de busquedad" + JOptionPane.ERROR_MESSAGE);
            return 0;
        }

    }

    private int buscarrecepcionista() {
        int resultado;
        String correo = vista.correo_TX.getText().toString().trim();
        String contraseña = vista.contraseñapass.getText().toString().trim();
        trecep.setCorreo(correo);
        trecep.setContraseña(contraseña);
        resultado = daorecep.iniciarsesionrecepcionista(trecep);

        if (resultado == 1) {
//            JOptionPane.showMessageDialog(vista, "correctamente");
            return 1;
        } else {
            //   JOptionPane.showMessageDialog(vista, "error de busquedad" + JOptionPane.ERROR_MESSAGE);
            return 0;
        }

    }

    private int buscar_modificar() {

        String cedula1 = vista1.cedula_TX.getText().trim();
        String correo = vista1.correo_TX.getText().trim();

        if (cedula1.isEmpty() || correo.isEmpty()) {
            JOptionPane.showMessageDialog(vista1, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
            return 0;

        }

        try {
            int cedula = Integer.parseInt(cedula1);

            t.setCedula(cedula);
            t.setCorre(correo);
            int resultado = dao.tbuscarcorreo(t);
            if (resultado == 1) {

                datosguardados.setUsuarioactual(t);
                return 1;
            } else {
                JOptionPane.showMessageDialog(vista1, "Usuario no resgistrado ", "error", JOptionPane.ERROR_MESSAGE);
                return 0;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(vista1, "Error: La cedula debe ser un valor numérico", "Error", JOptionPane.ERROR_MESSAGE);
            return 0;
        }

    }

    private int modificar() {
        String contraseña = vista2.confircontra_TX.getText().trim();
        String contraseña1 = vista2.contraseña_TX.getText().trim();

        if (!contraseña1.equals(contraseña)) {
            JOptionPane.showMessageDialog(vista, "No coinciden las contraseñas ", "error", JOptionPane.ERROR_MESSAGE);

            return 0;
        }

        if (contraseña.isEmpty() || contraseña1.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
            return 0;
        }
        t.setContraseña(contraseña);
        int resultado = dao.modificarusuario(t);
        if (resultado == 1) {
            JOptionPane.showMessageDialog(vista, "Contraseña modificada correctamente");
            return 1;
        } else {
            JOptionPane.showMessageDialog(vista, "Contraseña no se puedo modificar", "error", JOptionPane.ERROR_MESSAGE);
            return 0;
        }

    }

}
