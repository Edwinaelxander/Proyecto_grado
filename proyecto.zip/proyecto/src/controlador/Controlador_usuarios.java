/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import datos.datosguardados;
import inicios_gui.Registrarse;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo_usuario.Usuario;
import modelo_usuario.usuarioDao;
import vistas_admind.Inactivar_usuario;
import vistas_admind.Perfil_admin;
import vistas_usuario.datos_usuario;
import vistas_usuario.inicio_usuario;

/**
 *
 * @author Marely
 */
public class Controlador_usuarios implements ActionListener {

    private Usuario t = new Usuario();
    private usuarioDao dao = new usuarioDao();
    private Registrarse vista = new Registrarse();
    private Inactivar_usuario vista1 = new Inactivar_usuario();
    private datos_usuario vista2;

    public Controlador_usuarios(Registrarse v) {
        this.vista = v;
        this.vista.registrar.addActionListener(this);
    }

    public Controlador_usuarios(Inactivar_usuario a) {
        this.vista1 = a;
        this.vista1.inactivar1.addActionListener(this);
    }

    public Controlador_usuarios(datos_usuario d) {
        this.vista2 = d;
        this.vista2.confirmar.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == vista.registrar) {
            if (setinsertar() == 1) {
                vista.dispose();
                inicio_usuario a = new inicio_usuario();

                a.setVisible(true);
            }

        }

        if (ae.getSource() == vista1.inactivar1) {
            if (setbuscar() == 1) {
                eliminar();
            } else {
                JOptionPane.showMessageDialog(vista, "usuario no existe");
            }

        }
        if (vista2 != null) {
            if (ae.getSource() == vista2.confirmar) {
                actualizar();
            }
        }

    }

    private int setinsertar() {
        int resultado;

        String nombre = vista.nombre_TX.getText().trim();
        String cedulaStr = vista.cedula_TX.getText().trim();
        String telefonoStr = vista.telefono_TX.getText().trim();
        String correo = vista.correo_TX.getText().trim();
        String contraseña = vista.contraseña_TX.getText().trim();

        if (nombre.isEmpty() || cedulaStr.isEmpty() || telefonoStr.isEmpty() || correo.isEmpty() || contraseña.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Por favor complete todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
            return 0;
        }
        if (telefonoStr.length() != 10) {
            JOptionPane.showMessageDialog(vista, "El teléfono debe tener 10 dígitos.", "Error", JOptionPane.ERROR_MESSAGE);
            return 0;
        }

        try {

            int cedula = Integer.parseInt(cedulaStr);

            t.setNombre(nombre);
            t.setCedula(cedula);
            t.setTelefono(telefonoStr);
            t.setCorre(correo);
            t.setContraseña(contraseña);

            resultado = dao.setagregarusuari(t);
            if (resultado == 1) {
                JOptionPane.showMessageDialog(vista, "se inserto correctamente");
                datosguardados.setUsuarioactual(t);
                return 1;
            } else if (resultado == 3) {
                JOptionPane.showMessageDialog(vista, "Ya estas resgistrado", "error", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(vista, "error en la inserción", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(vista, "Por favor ingrese números válidos en los campos de cédula o teléfono.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return 0;
    }

    public int setbuscar() {
        int resultado;
        String correo = vista1.correo_TX.getText().toString();

        if (correo.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Error: El campo de correo está vacío.", "Error", JOptionPane.ERROR_MESSAGE);
            return 3;
        }

        t.setCorre(correo);
        resultado = dao.setbuscar1(t);

        if (resultado == 1) {
            JOptionPane.showMessageDialog(vista, "Se va a eliminar el correo: " + correo, "Eliminar Correo", JOptionPane.INFORMATION_MESSAGE);
            return 1;
        } else {
            JOptionPane.showMessageDialog(vista, "Error de búsqueda", "Error", JOptionPane.ERROR_MESSAGE);
            return 0;
        }

    }

    private void eliminar() {
        int resultado1;
        String correo = vista1.correo_TX.getText().toString();
        t.setCorre(correo);
        resultado1 = dao.setinactivarusuari(t);

        if (resultado1 == 1) {
            JOptionPane.showMessageDialog(vista, "se  elimino correctamente");
        } else {
            JOptionPane.showMessageDialog(vista, "error en la eliminacion" + JOptionPane.ERROR_MESSAGE);
        }

    }

//    private void datos() {
//        int resultado;
//        resultado = dao.setbuscar(t);
//        vista2.nombre_TX.setText(t.getNombre());
//        vista2.telefono_TX.setText("" + t.getTelefono());
//        vista2.correo_TX.setText(t.getCorre());
//        vista2.contraseña1.setText(t.getContraseña());
//
//    }
    private void actualizar() {

        String nombre = vista2.nombre_TX.getText().trim();
        String telefonoStr = vista2.telefono_TX.getText().trim();
        String correo = vista2.correo_TX.getText().trim();
        String contraseña = vista2.contraseña1.getText().trim();

        if (nombre.isEmpty() || telefonoStr.isEmpty() || correo.isEmpty() || contraseña.isEmpty()) {
            JOptionPane.showMessageDialog(vista, "Por favor complete todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
            vista2.confirmar.setVisible(true);
            return;
        }
        if (telefonoStr.length() != 10) {
            JOptionPane.showMessageDialog(vista, "El teléfono debe tener 10 dígitos.");
            vista2.confirmar.setVisible(true);
            return;
        }

        try {

            t.setNombre(nombre);
            t.setTelefono(telefonoStr);
            t.setCorre(correo);
            t.setContraseña(contraseña);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(vista, "Por favor ingrese un número de teléfono válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int resultado = dao.setmodificarusuari(t);
        if (resultado == 1) {
            JOptionPane.showMessageDialog(vista, "¡La actualización se realizó correctamente!");
        } else {
            JOptionPane.showMessageDialog(vista, "Se produjo un error durante la actualización. Por favor, inténtelo de nuevo.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

}
