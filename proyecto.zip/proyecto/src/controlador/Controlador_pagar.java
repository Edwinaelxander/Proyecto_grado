/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import inicios_gui.Inicio;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import javax.swing.JOptionPane;
import modelo_pagos.Pagar;
import modelo_pagos.PagarDao;
import vistas_recepcionista.inicio_recepcionista;
import vistas_recepcionista.pagar_recerva_recepcionista;
import vistas_usuario.miviaje_usuario;
import vistas_usuario.pagar_usuario;

/**
 *
 * @author Marely
 */
public class Controlador_pagar implements ActionListener {

    private Pagar p = new Pagar();
    private PagarDao dao = new PagarDao();
    private pagar_usuario vista = new pagar_usuario();
    private pagar_recerva_recepcionista vista1;

    public Controlador_pagar(pagar_recerva_recepcionista vista1) {
        this.vista1 = vista1;
        this.vista1.pagar.addActionListener(this);
    }

    public Controlador_pagar(pagar_usuario p) {
        this.vista = p;
        this.vista.pagar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.pagar) {
            if (hacerPago() == 1) {
                vista.dispose();
                miviaje_usuario a = new miviaje_usuario();
                a.setVisible(true);
            }
        }
        
        if (e.getSource() == vista1.pagar) {
            if (hacerPago() == 1) {
                vista1.dispose();
               inicio_recepcionista a=new inicio_recepcionista();
                a.setVisible(true);
            }
        }
    }

    private int hacerPago() {
        try {
            
            String nombre,numeroStr, codigoStr;
            java.util.Date  fecha;
            
            if(vista==null){
             nombre = vista.nombre_TX.getText().trim();
             numeroStr = vista.numero_TX.getText().trim();
             codigoStr = vista.codigo_TX.getText().trim();
             fecha = vista.fechatarjeta.getDate();
            }else{
                  nombre = vista1.nombre_TX.getText().trim();
             numeroStr = vista1.numero_TX.getText().trim();
             codigoStr = vista1.codigo_TX.getText().trim();
             fecha = vista.fechatarjeta.getDate();
            }
            if (nombre.isEmpty() || numeroStr.isEmpty() || codigoStr.isEmpty()) {
                JOptionPane.showMessageDialog(vista, "Debe completar todos los campos", "Error", JOptionPane.ERROR_MESSAGE);
                return 0;
            }
            if (codigoStr.length() != 3) {
                JOptionPane.showMessageDialog(vista, "El codigo de seguridad debe tener 3 dígitos.");
                return 0;
            }

  
            if (fecha == null) {
                JOptionPane.showMessageDialog(vista, "Debe seleccionar una fecha de expedición válida", "Error", JOptionPane.ERROR_MESSAGE);
                return 0;
            }

            int numero = Integer.parseInt(numeroStr);
            int codigo = Integer.parseInt(codigoStr);
            Date fechaSQL = new Date(fecha.getTime());

            p.setNombre(nombre);
            p.setNumero_tarjeta(numero);
            p.setFecha_expedicion(fechaSQL);
            p.setCodigo(codigo);

            int resultado = dao.hacerpago(p);

            if (resultado == 1) {
                JOptionPane.showMessageDialog(vista, "Pago realizado correctamente");
                return 1;
            } else {
                JOptionPane.showMessageDialog(vista, "Error en el pago", "Error", JOptionPane.ERROR_MESSAGE);
                return 0;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(vista, "Error: Los campos 'Número de tarjeta' y 'Código de seguridad' deben ser números enteros válidos", "Error", JOptionPane.ERROR_MESSAGE);
            return 0;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, "Error en el proceso de pago: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            return 0;
        }
    }
}
