/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo_incidentes.Incidente;
import modelo_incidentes.IncidenteDao;
import vistas_gerentes.Detalles_incidente;

/**
 *
 * @author Marely
 */
public class Controlador_incidente implements ActionListener {

    private Incidente t = new Incidente();
    private IncidenteDao dao = new IncidenteDao();
    private Detalles_incidente vista;

    public Controlador_incidente(Detalles_incidente vista) {
        this.vista = vista;
        this.vista.enviar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.enviar) {
            responder();
        }
    }

    private void responder() {
        try {
            String respuesta = vista.mensaje.getText().toString();

            if (respuesta.isEmpty()) {
                JOptionPane.showMessageDialog(vista, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            t.setResponder(respuesta);
            int resultado = dao.responder(t);

            if (resultado == 1) {
                JOptionPane.showMessageDialog(vista, "pqrs respondida con exito", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(vista, "Error en responder pqrs", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, "Error inesperado", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }

}
