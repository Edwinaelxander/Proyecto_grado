/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo_recepcionista.Recepcionista;
import modelo_recepcionista.RecepcionistaDao;
import vistas_gerentes.Modificar_recepcionista;
import vistas_gerentes.registrar_recepcionista;

/**
 *
 * @author Marely
 */
public class Controlador_recepcionista implements ActionListener {

    private Recepcionista r = new Recepcionista();
    private RecepcionistaDao dao = new RecepcionistaDao();
    private registrar_recepcionista vista;
    private Modificar_recepcionista vista2;

    public Controlador_recepcionista(Modificar_recepcionista vista2) {
        this.vista2 = vista2;
        this.vista2.confirmar.addActionListener(this);
    }

    public Controlador_recepcionista(registrar_recepcionista vista) {
        this.vista = vista;
        this.vista.registrar.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista2.confirmar) {
            vista2.contraseña_TX.setEditable(false);
                vista2.correo_TX.setEditable(false);
                vista2.telefono_TX.setEditable(false);
                vista2.confirmar.setVisible(false);
                vista2.cancelar.setVisible(false);
            modificar();
            
        } else if (e.getSource() == vista.registrar) {
            insertarrecepcionista();
        }

    }

    private void insertarrecepcionista() {
        try {
            String nombre = vista.nombre_TX.getText();
            String cedulaStr = vista.cedula_TX.getText();
            String correo = vista.correo_TX.getText();
            String contraseña = vista.contraseña_TX.getText();
            String telefono = vista.telefono_TX.getText();

            if (nombre.isEmpty() || cedulaStr.isEmpty() || correo.isEmpty() || contraseña.isEmpty() || telefono.isEmpty()) {
                JOptionPane.showMessageDialog(vista, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int cedula = Integer.parseInt(cedulaStr);

            r.setNombre(nombre);
            r.setCedula(cedula);
            r.setCorreo(correo);
            r.setContraseña(contraseña);
            r.setTelefono(telefono);

            int resultado = dao.agregarrecepcionista(r);
            if (resultado == 1) {
                JOptionPane.showMessageDialog(vista, "Se insertó correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(vista, "Error en la inserción", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(vista, "Error: Cedula y  teléfono deben ser valores numéricos ", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, "Error inesperado", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void modificar() {
        try {
            Recepcionista a = datos.datosguardados.getRecepcionistaactual();
            int b = a.getRecepcionistaid();
            String contraseña = vista2.contraseña_TX.getText().toString();
            String correo = vista2.correo_TX.getText().toString();
            String telefonoStr = vista2.telefono_TX.getText().toString();
        
           
            if (contraseña.isEmpty() || correo.isEmpty() || telefonoStr.isEmpty()) {
                JOptionPane.showMessageDialog(vista, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
               vista2.contraseña_TX.setEditable(false);
                vista2.correo_TX.setEditable(false);
                vista2.telefono_TX.setEditable(false);
                return;
            }

            r.setRecepcionistaid(b);
            r.setContraseña(contraseña);
            r.setCorreo(correo);
            r.setTelefono(telefonoStr);
            int resultado = dao.modificarrecepcionista(r);
            if (resultado == 1) {
                JOptionPane.showMessageDialog(vista, "Se modificó correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(vista, "Error en la modificación", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(vista, "Error: El número de teléfono debe ser un valor numérico", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(vista, "Error inesperado", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

}
