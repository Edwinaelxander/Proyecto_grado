/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inicios_gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

/**
 *
 * @author Marely
 */
public class Recuperar_contraseña extends JFrame implements ActionListener {

    private Container contenedor;
    public JLabel correo, cedula;
    public JTextField correo_TX, cedula_TX;
    public JButton enviar;

    public Recuperar_contraseña() {
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel fondo = new JPanel();
        fondo.setBorder(BorderFactory.createEmptyBorder(100, 10, 10, 10));

        JPanel recuperar = new JPanel(new GridLayout(5, 1, 2, 10));
        TitledBorder titledBorder = BorderFactory.createTitledBorder("RECUPERAR CONTRASEÑA");
        titledBorder.setTitleFont(new Font("Serif", Font.BOLD, 20));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.CENTER);

        recuperar.setBorder(titledBorder);
        recuperar.setPreferredSize(new Dimension(450, 500));
        recuperar.setBackground(Color.WHITE);

        correo = new JLabel("Correo:");
        cedula = new JLabel("Cédula:");
        correo_TX = new JTextField(); 
        cedula_TX = new JTextField(); 
        enviar = new JButton("Enviar");
        
        recuperar.add(correo);
        recuperar.add(correo_TX);
        recuperar.add(cedula);
        recuperar.add(cedula_TX);
        recuperar.add(enviar);
        
        fondo.add(recuperar);
        
        contenedor.add(fondo,BorderLayout.CENTER);
             setSize(500, 800);
        

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    public static void main(String[] args) {
        Recuperar_contraseña a = new Recuperar_contraseña();
        a.setVisible(true);
    }
    

}
