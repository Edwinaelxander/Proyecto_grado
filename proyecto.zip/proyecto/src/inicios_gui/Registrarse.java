/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inicios_gui;

import Db.Conexion;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

/**
 *
 * @author Marely
 */
public class Registrarse extends JFrame implements ActionListener{

    private Container contenedor;
    public JButton registrar,atras;
    public JLabel gerente, cedula, telefono, nombre, correo, contraseña;
    public JTextField cedula_TX, nombre_TX, correo_TX, contraseña_TX, telefono_TX;

    public Registrarse() {
         Conexion con = new Conexion();
        con.getCon();
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel fondo = new JPanel();
        fondo.setBorder(BorderFactory.createEmptyBorder(100, 10, 10, 10));

        JPanel registrarse = new JPanel(new GridLayout(12, 1, 2, 10));
        TitledBorder titledBorder = BorderFactory.createTitledBorder("REGISTRATE");
        titledBorder.setTitleFont(new Font("Arial", Font.BOLD, 50));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.CENTER);

        registrarse.setBorder(titledBorder);
        registrarse.setPreferredSize(new Dimension(450, 550));
        registrarse.setBackground(Color.WHITE);
        
        Icon ima = new ImageIcon("atras.PNG");
        atras = new JButton("", ima);
        atras.setContentAreaFilled(false);
        atras.addActionListener(this);
        
        nombre = new JLabel("nombre");
        cedula = new JLabel("cedula:");
        telefono = new JLabel("telefono");
        correo = new JLabel("correo");
        contraseña = new JLabel("contraseña");

        nombre_TX = new JTextField(10);
        cedula_TX = new JTextField(10);
        telefono_TX = new JTextField(10);
        correo_TX = new JTextField(50);
        contraseña_TX = new JTextField(10);

        registrar = new JButton("registrate");
        registrar.setBackground(Color.orange);

        registrarse.add(atras);
        registrarse.add(nombre);
        registrarse.add(nombre_TX);
        registrarse.add(cedula);
        registrarse.add(cedula_TX);
        registrarse.add(telefono);
        registrarse.add(telefono_TX);
        registrarse.add(correo);
        registrarse.add(correo_TX);
        registrarse.add(contraseña);
        registrarse.add(contraseña_TX);
        registrarse.add(registrar);
        fondo.add(registrarse);
        contenedor.add(fondo, BorderLayout.CENTER);

        

        setSize(500, 800);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
  if (e.getSource() == atras) {
            dispose();
            Inicio a = new Inicio();
            a.setVisible(true);
        }    }

}
