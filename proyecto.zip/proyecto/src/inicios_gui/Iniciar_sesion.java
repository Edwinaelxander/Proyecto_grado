/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inicios_gui;

import Db.Conexion;
import controlador.Controlador_iniciosesion;
import controlador.Controlador_usuarios;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JPasswordField;

/**
 *
 * @author Marely
 */
public class Iniciar_sesion extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton iniciar_sesion, registrar, olvidar, atras;
    public JLabel correo, contraseña;
    public JPasswordField contraseñapass;
    public JTextField correo_TX;
    Font font = new Font("Arial", Font.PLAIN, 16);

    public Iniciar_sesion() {

        super();
        
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());
      

        JPanel fondo = new JPanel();
        fondo.setBorder(BorderFactory.createEmptyBorder(100, 10, 10, 10));

        JPanel iniciosesion = new JPanel(new GridLayout(8, 1, 2, 10));
        TitledBorder titledBorder = BorderFactory.createTitledBorder("INICIAR SESION");
        titledBorder.setTitleFont(new Font("Serif", Font.BOLD, 50));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.CENTER);

        iniciosesion.setBorder(titledBorder);
        iniciosesion.setPreferredSize(new Dimension(450, 500));
        iniciosesion.setBackground(Color.WHITE);

        Icon ima = new ImageIcon("atras.PNG");
        atras = new JButton("", ima);
        atras.setContentAreaFilled(false);
        atras.addActionListener(this);

        correo = new JLabel("correo electronico");
        correo.setFont(font);
        contraseña = new JLabel("contraseña");
        contraseña.setFont(font);

        correo_TX = new JTextField(10);
        contraseñapass = new JPasswordField(10);

        iniciar_sesion = new JButton("iniciar sesion");
        registrar = new JButton("¿es tu primera vez? registrate");
        olvidar = new JButton("¿olvidaste contreseña?");

        registrar.setBorderPainted(false);
        olvidar.setBorderPainted(false);
        iniciar_sesion.setBackground(Color.orange);

        registrar.setOpaque(false);
        olvidar.setOpaque(false);
        olvidar.addActionListener(this);
        

        //quitar fondo
        registrar.setContentAreaFilled(false);
        registrar.addActionListener(this);
        olvidar.setContentAreaFilled(false);

        iniciosesion.add(atras);
        iniciosesion.add(registrar);
        iniciosesion.add(correo);
        iniciosesion.add(correo_TX);
        iniciosesion.add(contraseña);
        iniciosesion.add(contraseñapass);
        iniciosesion.add(olvidar);
        iniciosesion.add(iniciar_sesion);

        fondo.add(iniciosesion, BorderLayout.SOUTH);

        contenedor.add(fondo, BorderLayout.CENTER);

        setSize(500, 800);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == atras) {
            dispose();
            Inicio a = new Inicio();
            a.setVisible(true);
        }

        if (e.getSource() == registrar) {
             dispose();
            Registrarse a = new Registrarse();
            Controlador_usuarios cona = new Controlador_usuarios(a);
            a.setVisible(true);
        }
        
        if(e.getSource()==olvidar){
            dispose();
            Recuperar_contraseña a=new Recuperar_contraseña();
            Controlador_iniciosesion b=new Controlador_iniciosesion(a);
            a.setVisible(true);
        }
    }

}
