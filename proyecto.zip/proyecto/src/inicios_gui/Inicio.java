/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inicios_gui;

import controlador.Controlador_iniciosesion;
import controlador.Controlador_usuarios;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import vistas_usuario.inicio_usuario;

/**
 *
 * @author Marely
 */
public class Inicio extends JFrame implements ActionListener {

    private Container contenedor;

    public JButton registrar, iniciarsesion, atras;
    public JLabel titulo, subtitulo;

    public Inicio() {
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel cabecera = new JPanel();

        JPanel c = new JPanel();
        JPanel fondo = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                Image imagenDeFondo = new ImageIcon("fondo1.JPG").getImage();

                g.drawImage(imagenDeFondo, 0, 0, 500, 800, this);

            }
        };

        cabecera.setBorder(BorderFactory.createEmptyBorder(80, 10, 10, 10));
        c.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel texto = new JPanel(new GridLayout(2, 1, 2, 15));
//         texto.setPreferredSize(new Dimension(200,200));

        JPanel inicios = new JPanel(new GridLayout(3, 1, 2, 10));
        inicios.setPreferredSize(new Dimension(400, 100));

        registrar = new JButton("registrarse");
        iniciarsesion = new JButton("iniciar sesion");
        registrar.setContentAreaFilled(false);
        iniciarsesion.setBackground(Color.ORANGE);
        atras = new JButton("regresar");
        atras.setBorderPainted(false);
        atras.setOpaque(false);
        atras.setContentAreaFilled(false);
        atras.addActionListener(this);
        titulo = new JLabel("HOTELERA.COM");
        subtitulo = new JLabel("la mejor plataforma para hacer reserva de alojamientos");

        texto.add(titulo);
        texto.add(subtitulo);

        cabecera.add(texto);

        inicios.add(iniciarsesion);
        inicios.add(registrar);
        inicios.add(atras);
        c.add(inicios);

        registrar.addActionListener(this);
        iniciarsesion.addActionListener(this);

//        fondo.add(cabecera,BorderLayout.NORTH);
      fondo.add(c, BorderLayout.SOUTH);
      
        contenedor.add(fondo);
        setSize(500, 800);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == registrar) {
            dispose();
            openregistrar();

        }
        if (e.getSource() == iniciarsesion) {
            dispose();
            openriniciarsesion();

        }
        if (e.getSource() == atras) {
            dispose();
            inicio_usuario a = new inicio_usuario();
            a.setVisible(true);
        }
    }

    private void openregistrar() {
        Registrarse a = new Registrarse();
        Controlador_usuarios cona = new Controlador_usuarios(a);
        a.setVisible(true);

    }

    private void openriniciarsesion() {
        Iniciar_sesion a = new Iniciar_sesion();
        Controlador_iniciosesion c = new Controlador_iniciosesion(a);
        a.setVisible(true);
    }
}
