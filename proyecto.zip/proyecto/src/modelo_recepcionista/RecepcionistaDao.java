/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_recepcionista;

import Db.Conexion;
import datos.datosguardados;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import modelo_alojamiento.alojamiento;
import modelo_gerente.gerente;

/**
 *
 * @author Marely
 */
public class RecepcionistaDao implements crud_recepcionista {

    Conexion conetion = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    @Override
    public int agregarrecepcionista(Recepcionista r) {
        String sql = "INSERT INTO recepcionista (GerenteID, AlojamientoID, nombre, cedula, correo, contraseña, telefono, estado ) VALUES(?,?,?,?,?,?,?,?)";

        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            gerente g = datosguardados.getGerenteActual();
            alojamiento a = datosguardados.getAlojamientoActual();
            ps.setInt(1, g.getGerenteid());
            ps.setInt(2, a.getId());
            ps.setString(3, r.getNombre());
            ps.setInt(4, r.getCedula());
            ps.setString(5, r.getCorreo());
            ps.setString(6, r.getContraseña());
            ps.setString(7, r.getTelefono());

            ps.setInt(8, 0);
            ps.executeUpdate();
            return 1;
        } catch (java.sql.SQLIntegrityConstraintViolationException e) {
            JOptionPane.showMessageDialog(null, "Recepcionista ya esta registrado", e.getMessage(), JOptionPane.ERROR_MESSAGE);

            return 3;
        } catch (Exception q) {
            JOptionPane.showMessageDialog(null, q.toString(), "error de insercion" + q.getMessage(), JOptionPane.ERROR_MESSAGE);
            q.printStackTrace();
            return 0;
        }
    }

    @Override
    public int modificarrecepcionista(Recepcionista r) {
        String sql = "UPDATE recepcionista SET correo=?, contraseña=?, telefono=? WHERE recepcionistaID=?";
        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);

            ps.setString(1, r.getCorreo());

            ps.setString(2, r.getContraseña());
            ps.setString(3, r.getTelefono());
            ps.setInt(4, r.getRecepcionistaid());
            ps.executeUpdate();
            return 1;
        } catch (Exception e) {
            System.out.print(e.toString() + "error de actualiacion 1 " + e.getMessage());
            return 0;
        }
    }

    @Override
    public int inhabilitarrecepcionista(Recepcionista r) {
 String sql = "UPDATE recepcionista SET estado=? WHERE recepcionistaID=?";
        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);

            ps.setInt(1,1);
            ps.setInt(2, r.getRecepcionistaid());
            ps.executeUpdate();
            return 1;
        } catch (Exception e) {
            System.out.print(e.toString() + "error de eliminacion" + e.getMessage());
            return 0;
        }    }

    public List recepcionistas() {

        List<Recepcionista> recepcionistas = new ArrayList<>();
        String sql = "SELECT * FROM recepcionista WHERE estado=0 AND GerenteID=? AND AlojamientoID=?";
        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            gerente g = datosguardados.getGerenteActual();
            alojamiento a = datosguardados.getAlojamientoActual();
            ps.setInt(1, g.getGerenteid());
            ps.setInt(2, a.getId());
            rs = ps.executeQuery();
            while (rs.next()) {
                Recepcionista r = new Recepcionista();
                r.setRecepcionistaid(rs.getInt("recepcionistaID"));
                r.setGerenteId(rs.getInt("GerenteID"));
                r.setNombre(rs.getString("nombre"));
                r.setCedula(rs.getInt("cedula"));
                r.setCorreo(rs.getString("correo"));
                r.setContraseña(rs.getString("contraseña"));
                r.setTelefono(rs.getString("telefono"));

                datosguardados.setRecepcionistaactual(r);
                recepcionistas.add(r);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return recepcionistas;
    }

    
    
    public int iniciarsesionrecepcionista(Recepcionista r){
         String sql = "SELECT * FROM recepcionista WHERE correo=? AND contraseña=?";
         try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ps.setString(1, r.getCorreo());
            ps.setString(2, r.getContraseña());
            
            rs = ps.executeQuery();
            if (rs.next()) {
                 int id = rs.getInt("recepcionistaID");
                 r.setRecepcionistaid(id);
               
                 alojamiento a=new alojamiento();
                 a.setId(rs.getInt("AlojamientoID"));
                 
                 datosguardados.setAlojamientoActual(a);
                 datosguardados.setRecepcionistaactual(r);
                return 1;
                
                

            } else {
                return 0;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "error de busquedad" + e.getMessage(), JOptionPane.ERROR_MESSAGE);
            return 0;
        }

    }
}
