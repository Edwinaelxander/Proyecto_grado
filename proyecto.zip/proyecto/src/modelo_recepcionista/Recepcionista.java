/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_recepcionista;

/**
 *
 * @author Marely
 */
public class Recepcionista {
    private int recepcionistaid,cedula,gerenteId;
    private String nombre,correo,contraseña,telefono;

    public Recepcionista() {
    }

    public int getCedula() {
        return cedula;
    }

    public int getGerenteId() {
        return gerenteId;
    }

    public void setGerenteId(int gerenteId) {
        this.gerenteId = gerenteId;
    }
    

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }
    

    public int getRecepcionistaid() {
        return recepcionistaid;
    }

    public void setRecepcionistaid(int recepcionistaid) {
        this.recepcionistaid = recepcionistaid;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
    
    
}
