/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_pqrs;

/**
 *
 * @author Marely
 */
public class Pqrs {
    private  int pqrsid;
    private  String nombre;
    private  String tipo;
    private  String descripcion;
    private  String alojamiento;
    private  String respuesta;

    public Pqrs(int pqrsid, String tipo, String descripcion, String alojamiento) {
        this.pqrsid = pqrsid;
        this.tipo = tipo;
        this.descripcion = descripcion;
        this.alojamiento = alojamiento;
    }

    public Pqrs() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    

    public int getPqrsid() {
        return pqrsid;
    }
    
    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }


    public void setPqrsid(int pqrsid) {
        this.pqrsid = pqrsid;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getAlojamiento() {
        return alojamiento;
    }

    public void setAlojamiento(String alojamiento) {
        this.alojamiento = alojamiento;
    }
    
    
    
    
}
