/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_admind;

import controlador.Controlador_gerente;
import controlador.Controlador_usuarios;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

/**
 *
 * @author Marely
 */
public class Principal extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton registrarg, inactivaru, ico,pqrs;
    public JLabel admistrador;
    

    public Principal() {
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel cabecera = new JPanel();

        JPanel principal = new JPanel(new GridLayout(3, 1, 20, 50));
        TitledBorder titledBorder = BorderFactory.createTitledBorder("ADMINISTRADOR");
        titledBorder.setTitleFont(new Font("Serif", Font.BOLD, 30));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.CENTER);

        

        principal.setBorder(titledBorder);
        principal.setPreferredSize(new Dimension(450, 300));
        principal.setBackground(Color.WHITE);
        
        JPanel admin = new JPanel(new FlowLayout());
        Icon ima = new ImageIcon("icono.PNG");
        ico = new JButton("yo", ima);
        ico.setPreferredSize(new Dimension(600, 100));
        admin.add(ico);

        registrarg = new JButton("registrar gerente");
        inactivaru = new JButton("inactivar usuario");
        pqrs=new JButton("Pqrs");

        principal.add(registrarg);
        principal.add(inactivaru);
        principal.add(pqrs);
        cabecera.add(principal);
        
        contenedor.add(admin,BorderLayout.SOUTH);
        contenedor.add(cabecera, BorderLayout.CENTER);
        
       
        setSize(500, 800);
        
        ico.addActionListener(this);
        pqrs.addActionListener(this);
        registrarg.addActionListener(this);
        inactivaru.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == registrarg) {
            dispose();
            openregistrar();
        }

        if (e.getSource() == inactivaru) {
            dispose();
            openreliminar();
        }
        if (e.getSource() == ico) {
            dispose();
            Perfil_admin a=new Perfil_admin();
            a.setVisible(true);
        }
        if(e.getSource()==pqrs){
            dispose();
            Pqrs_admin a=new Pqrs_admin();
            a.setVisible(true);
            
        }
        
    }

    private void openregistrar() {
        Registrar_gerentes a = new Registrar_gerentes();
        Controlador_gerente cona = new Controlador_gerente(a);
        a.setVisible(true);
    }

    private void openreliminar() {
        Inactivar_usuario b= new Inactivar_usuario();
        Controlador_usuarios con = new Controlador_usuarios(b);
        b.setVisible(true);
    }
}
