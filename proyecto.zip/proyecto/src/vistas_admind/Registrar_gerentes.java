package vistas_admind;

import Db.Conexion;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author Marely
 */
public class Registrar_gerentes extends JFrame implements ActionListener {

    private Container contenedor;

    public JButton registrar, atras, ico;
    public JLabel gerente, cedula, telefono, nombre, correo, contraseña;
    public JTextField cedula_TX, nombre_TX, correo_TX, contraseña_TX, telefono_TX;

    public Registrar_gerentes() {
        super();
        Conexion con = new Conexion();
        con.getCon();
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel formularioregistargerente = new JPanel();
        formularioregistargerente.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel registrargerente = new JPanel(new GridLayout(12, 1, 2, 10));
        TitledBorder titledBorder = BorderFactory.createTitledBorder("REGISTRAR GERENTES");
        titledBorder.setTitleFont(new Font("Serif", Font.BOLD, 30));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.CENTER);

        registrargerente.setBorder(titledBorder);
        registrargerente.setPreferredSize(new Dimension(450, 700));
        registrargerente.setBackground(Color.WHITE);

        JPanel admin = new JPanel(new FlowLayout());
        Icon ima1 = new ImageIcon("icono.PNG");
        ico = new JButton("yo", ima1);
        ico.setPreferredSize(new Dimension(600, 100));
        admin.add(ico);
        ico.addActionListener(this);

        Icon ima = new ImageIcon("atras.PNG");
        atras = new JButton("", ima);
        atras.setContentAreaFilled(false);
        atras.addActionListener(this);

        nombre = new JLabel("nombre");
        cedula = new JLabel("cedula:");
        telefono = new JLabel("telefono");
        correo = new JLabel("correo");
        contraseña = new JLabel("contraseña");

        nombre_TX = new JTextField(10);
        cedula_TX = new JTextField(10);
        telefono_TX = new JTextField(10);
        correo_TX = new JTextField(50);
        contraseña_TX = new JTextField(10);

        registrar = new JButton("registar regente");
        registrar.setBackground(Color.ORANGE);
        registrar.setSize(new Dimension(10, 2));

        registrargerente.add(atras);
        registrargerente.add(nombre);
        registrargerente.add(nombre_TX);
        registrargerente.add(cedula);
        registrargerente.add(cedula_TX);
        registrargerente.add(telefono);
        registrargerente.add(telefono_TX);
        registrargerente.add(correo);
        registrargerente.add(correo_TX);
        registrargerente.add(contraseña);
        registrargerente.add(contraseña_TX);
        registrargerente.add(registrar);
        formularioregistargerente.add(registrargerente);

        JScrollPane scrollPane = new JScrollPane(formularioregistargerente, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        contenedor.add(admin, BorderLayout.SOUTH);
        contenedor.add(scrollPane, BorderLayout.CENTER);
        

        setSize(500, 800);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == atras) {
            dispose();
            Principal a = new Principal();
            a.setVisible(true);
        }
        if (e.getSource() == ico) {
            dispose();
            Perfil_admin a = new Perfil_admin();
            a.setVisible(true);
        }
    }

}
