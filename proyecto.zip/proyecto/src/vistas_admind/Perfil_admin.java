/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_admind;

import inicios_gui.Inicio;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author Marely
 */
public class Perfil_admin extends JFrame implements ActionListener{
    
      private Container contenedor;

    public JButton salir,inicio;

    public Perfil_admin() {
        
          contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());
        
     
        JPanel texto = new JPanel(new FlowLayout());
        texto.setBorder(BorderFactory.createEmptyBorder(100, 10, 10, 10));
        
        
        salir=new JButton("cerrar sesion");
        salir.setPreferredSize(new Dimension(600, 150));
        salir.setBackground(Color.red);
        
        JPanel admin = new JPanel(new FlowLayout());
        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setPreferredSize(new Dimension(600, 100));
        admin.add(inicio);
        
        texto.add(salir);
        
         contenedor.add(admin,BorderLayout.SOUTH);
        contenedor.add(texto,BorderLayout.CENTER);
        

        setSize(500, 800);
        salir.addActionListener(this);
        inicio.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
          if (e.getSource() == salir) {
              dispose();
              Inicio a=new Inicio();
              a.setVisible(true);
          }
          
           if (e.getSource() == inicio) {
            dispose();
            Principal a=new Principal();
            a.setVisible(true);
        }
    }
    
    
    
}
