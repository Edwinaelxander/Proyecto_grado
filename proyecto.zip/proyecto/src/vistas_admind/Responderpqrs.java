/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_admind;

import datos.datosguardados;
import efectos.Redondiarjpanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;
import modelo_pqrs.Pqrs;

/**
 *
 * @author Marely
 */
public class Responderpqrs extends JFrame {

    private Container contenedor;
    public JButton ico, enviar,atras;
    private JLabel responde;
    public JTextArea mensaje;

    public JLabel nombre, tipo, descripcion;

    JPanel panelinformes = new JPanel(new BorderLayout());

    public Responderpqrs(Pqrs pq) {
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel pqrsp = new JPanel(new BorderLayout());
        TitledBorder titledBorder = BorderFactory.createTitledBorder("PQRS");
        titledBorder.setTitleFont(new Font("Serif", Font.BOLD, 20));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.CENTER);

        pqrsp.setBorder(titledBorder);

        pqrsp.setBackground(Color.WHITE);

        JPanel admin = new JPanel(new FlowLayout());
        Icon ima1 = new ImageIcon("icono.PNG");
        ico = new JButton("yo", ima1);
        ico.setPreferredSize(new Dimension(600, 100));
        admin.add(ico);

        contenedor.add(admin, BorderLayout.SOUTH);

        JPanel responder = new JPanel(new GridLayout(3, 1, 10, 10));
        responder.setPreferredSize(new Dimension(450, 300));
        responder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        responde = new JLabel("responder");
        mensaje = new JTextArea(10, 20);
        enviar = new JButton("enviar");

        responder.add(responde);
        responder.add(mensaje);
        responder.add(enviar);

        pqrsp.add(responder, BorderLayout.SOUTH);

        panelinformes = new JPanel(new GridLayout(0, 1, 2, 10));

        pqrsp.add(panelinformes, BorderLayout.NORTH);
        inicializar(pq);
        contenedor.add(pqrsp, BorderLayout.CENTER);
        
        Icon ima = new ImageIcon("atras.PNG");
        atras = new JButton("", ima);
        atras.setContentAreaFilled(false);
        
        contenedor.add(atras,BorderLayout.NORTH);
     

        setSize(500, 800);
    }

    private void inicializar(Pqrs pq1) {
        Pqrs a=datosguardados.getPqrsactual();

        JPanel panelPqrs = new JPanel();

        panelPqrs.setBackground(Color.white);
        panelPqrs.setLayout(new GridLayout(3, 1));

        JLabel nombre = new JLabel("Usuario: " + pq1.getNombre());
        JLabel tipo = new JLabel("tipo: " + pq1.getTipo());
        JLabel descripcion = new JLabel("Descripcion: " + pq1.getDescripcion());

        panelPqrs.add(nombre);
        panelPqrs.add(tipo);
        panelPqrs.add(descripcion);
        panelinformes.add(panelPqrs);
        panelinformes.revalidate();
        System.out.println(a.getPqrsid());

    }

}
