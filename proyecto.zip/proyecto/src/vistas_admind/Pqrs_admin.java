/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_admind;

import controlador.Controlador_comentarios;
import controlador.Controlador_pqrs;
import datos.datosguardados;
import efectos.Redondiarjpanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;
import modelo_alojamiento.alojamiento;
import modelo_pqrs.Pqrs;
import modelo_pqrs.PqrsDao;
import modelo_usuario.Usuario;
import vistas_usuario.alojamiento_usuario;

/**
 *
 * @author Marely
 */
public class Pqrs_admin extends JFrame implements ActionListener{

    private Container contenedor;
    public JButton ico,atras;
    JPanel panelpqrs;
       private Pqrs pqrsSeleccionada;

    Pqrs p = new Pqrs();

    public Pqrs_admin() {

        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel pqrsp = new JPanel();
        TitledBorder titledBorder = BorderFactory.createTitledBorder("PQRS");
        titledBorder.setTitleFont(new Font("Serif", Font.BOLD, 20));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.CENTER);

        pqrsp.setBorder(titledBorder);

        pqrsp.setBackground(Color.WHITE);

        JPanel admin = new JPanel(new FlowLayout());
        Icon ima1 = new ImageIcon("icono.PNG");
        ico = new JButton("yo", ima1);
        ico.setPreferredSize(new Dimension(600, 100));
        admin.add(ico);
        ico.addActionListener(this);

        contenedor.add(admin, BorderLayout.SOUTH);
         Icon ima = new ImageIcon("atras.PNG");
        atras = new JButton("", ima);
        atras.setContentAreaFilled(false);
        atras.addActionListener(this);
        

        panelpqrs = new JPanel(new GridLayout(0, 1, 8, 8));
        panelpqrs.setBackground(Color.WHITE);

        panelpqrs.setBackground(null);
        panelpqrs.setPreferredSize(new Dimension(420, 500));
        panelpqrs.setBackground(Color.white);
        JScrollPane scrollPane = new JScrollPane(panelpqrs, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        inicializar();

        pqrsp.add(scrollPane);
        contenedor.add(atras,BorderLayout.NORTH);

        contenedor.add(pqrsp, BorderLayout.CENTER);
        setSize(500, 800);
    }

    private void inicializar() {
        PqrsDao pq = new PqrsDao();

        List<Pqrs> pqrs = pq.pqrs();

        for (Pqrs pqr : pqrs) {

            Redondiarjpanel panelPqrs = new Redondiarjpanel();

            panelPqrs.setBackground(Color.white);
            panelPqrs.setLayout(new GridLayout(3, 1));

            JLabel nombre = new JLabel("Usuario: " + pqr.getNombre());
            JLabel tipo = new JLabel("tipo: " + pqr.getTipo());
            JLabel descripcion = new JLabel("Descripcion: " + pqr.getDescripcion());

            panelPqrs.add(nombre);
            panelPqrs.add(tipo);
            panelPqrs.add(descripcion);
             panelPqrs.addMouseListener(new MouseAdapter() {

                @Override
                public void mouseClicked(MouseEvent e) {
                    pqrsSeleccionada = pqr;
                    dispose();
                    datosguardados.setPqrsactual(pqrsSeleccionada);
                    Responderpqrs a=new Responderpqrs(pqrsSeleccionada);
                    Controlador_pqrs b=new Controlador_pqrs(a);
                    a.setVisible(true);
                    
                    
                }

                @Override
                public void mouseEntered(MouseEvent e) {
                    panelPqrs.setBackground(Color.orange);
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    panelPqrs.setBackground(Color.WHITE);
                }

            });

            panelpqrs.add(panelPqrs, BorderLayout.CENTER);
        }
        panelpqrs.revalidate();
    }

    public static void main(String[] args) {
        Pqrs_admin a = new Pqrs_admin();
        a.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==atras){
            dispose();
            Principal a= new Principal();
            a.setVisible(true);
            
        }
        if (e.getSource() == ico) {
            dispose();
            Perfil_admin a=new Perfil_admin();
            a.setVisible(true);
        }

    }

}
