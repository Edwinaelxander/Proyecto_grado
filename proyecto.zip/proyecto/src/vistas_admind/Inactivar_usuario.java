/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_admind;

import Db.Conexion;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

/**
 *
 * @author Marely
 */
public class Inactivar_usuario extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inactivar1, atras, ico;
    public JLabel correo;
    public JTextField correo_TX;

    public Inactivar_usuario() {

      
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel fondo = new JPanel();
        fondo.setBorder(BorderFactory.createEmptyBorder(100, 10, 10, 10));

        JPanel inactivar = new JPanel(new GridLayout(4, 1, 2, 10));
        TitledBorder titledBorder = BorderFactory.createTitledBorder("INACTIVAR USUARIO");
        titledBorder.setTitleFont(new Font("Serif", Font.BOLD, 20));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.CENTER);

        inactivar.setBorder(titledBorder);
        inactivar.setPreferredSize(new Dimension(450, 300));
        inactivar.setBackground(Color.WHITE);

        JPanel admin = new JPanel(new FlowLayout());
        Icon ima1 = new ImageIcon("icono.PNG");
        ico = new JButton("yo", ima1);
        ico.setPreferredSize(new Dimension(600, 100));
        admin.add(ico);
        ico.addActionListener(this);

        Icon ima = new ImageIcon("atras.PNG");
        atras = new JButton("", ima);
        atras.setContentAreaFilled(false);
        atras.addActionListener(this);

        correo = new JLabel("correo");
        correo_TX = new JTextField(10);

        inactivar1 = new JButton("inactivar usuario");
        inactivar1.setBackground(Color.red);

        inactivar.add(atras);
        inactivar.add(correo);
        inactivar.add(correo_TX);
        inactivar.add(inactivar1);
        fondo.add(inactivar);

        contenedor.add(fondo, BorderLayout.CENTER);
        contenedor.add(admin, BorderLayout.SOUTH);

        

        setSize(500, 800);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == atras) {
            dispose();
            Principal a = new Principal();
            a.setVisible(true);
        }
        if (e.getSource() == ico) {
            dispose();
            Perfil_admin a=new Perfil_admin();
            a.setVisible(true);
        }
    }

}
