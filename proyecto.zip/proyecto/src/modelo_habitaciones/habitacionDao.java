/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_habitaciones;

import Db.Conexion;
import datos.datosguardados;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import modelo_alojamiento.alojamiento;

/**
 *
 * @author Marely
 */
public class habitacionDao implements Crud_habitacion {

    Conexion conetion = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    @Override
    public int agregarhabitacion(habitacion tr) {
//        String sql = "INSERT INTO habitaciones ( AlojamientoID, Tipo, Vista, cantidad, Precio, ServiciosIncluidos ) VALUES(?,?,?,?,?,?) ";
//        try {
//            con = conetion.getCon();
//            ps = con.prepareStatement(sql);
//            ps.setInt(1, tr.getAlojamientoid());
//            ps.setString(2, tr.getTipo());
//            ps.setString(3, tr.getVista());
//            ps.setInt(4, tr.getCantidad());
//            ps.setDouble(5, tr.getPrecio());
//            ps.setString(6, tr.getServicios());
//            ps.executeUpdate();
//            return 1;
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(null, e.toString(), "error de insercion" + e.getMessage(), JOptionPane.ERROR_MESSAGE);
//            return 0;
//        }
return 3;
    }

    @Override
    public int modificarhabitacion(habitacion tr) {
        String sql = "UPDATE habitaciones SET Tipo=?, cantidad=?, precio=?, ServiciosIncluidos=? WHERE HabitacionID=?";

        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);

            ps.setString(1, tr.getTipo());

            ps.setInt(2, tr.getCantidad());
            ps.setDouble(3, tr.getPrecio());
            ps.setString(4, tr.getServicios());
            ps.setInt(5, tr.getHabitacionid());
            ps.executeUpdate();
            return 1;

        } catch (Exception e) {
            System.out.print(e.toString() + "error de actualiacion 1 " + e.getMessage());
            return 0;
        }

    }

    @Override
    public List habitaciones() {

        List<habitacion> habitaciones = new ArrayList<>();
        String sql = "SELECT * FROM habitaciones WHERE AlojamientoID=?  AND Disponibilidad = 0";

        try {
            alojamiento alo = datosguardados.getAlojamientoActual();
//      
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ps.setInt(1, alo.getId());
            rs = ps.executeQuery();

            while (rs.next()) {

                String tipo = rs.getString("tipo");
                float precio = rs.getFloat("precio");
                int id = rs.getInt("HabitacionID");

                habitacion habitacion = new habitacion();
                habitacion.setTipo(tipo);
                habitacion.setPrecio(precio);
                habitacion.setHabitacionid(id);

                datosguardados.setHabitacionActual(habitacion);
                habitaciones.add(habitacion);

            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString(), "error de busquedad" + e.getMessage(), JOptionPane.ERROR_MESSAGE);

        }
        return habitaciones;
    }

    @Override
    public int info(habitacion tr) {
        String sql = "SELECT * FROM habitaciones WHERE HabitacionID=?";

        try {
            habitacion alo = datosguardados.getHabitacionActual();
//            System.out.println(alo.getHabitacionid());
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ps.setInt(1, alo.getHabitacionid());
            rs = ps.executeQuery();

            rs.next();

            tr.setTipo(rs.getString("Tipo"));
            tr.setVista(rs.getString("Vista"));
            tr.setCantidad(rs.getInt("cantidad"));
            tr.setPrecio(rs.getFloat("Precio"));
            tr.setServicios(rs.getString("ServiciosIncluidos"));

            datosguardados.setHabitacionActual(tr);

            return 1;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.toString(), "error de busquedad" + e.getMessage(), JOptionPane.ERROR_MESSAGE);
            return 0;
        }

    }

    @Override
    public int inactivar(habitacion tr) {
        String sql = "UPDATE habitaciones SET Disponibilidad=?  WHERE HabitacionID=?";
        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            int estado = 1;

            ps.setInt(1, estado);
            ps.setInt(2, tr.getHabitacionid());
            ps.executeUpdate();
            return 1;

        } catch (Exception e) {
            System.out.print(e.toString() + "error de eliminacion " + e.getMessage());
            return 0;
        }

    }

    public int verificarparainsertar(habitacion tr) {
        String sql1 = "SELECT SUM(cantidad_habitaciones) AS total_habitaciones FROM habitaciones WHERE AlojamientoID =?";
        String sql2 = "SELECT SUM(cantidad_habitaciones) as habitaciones FROM alojamientos WHERE AlojamientoID = ?";

        try {

            alojamiento alo = datosguardados.getAlojamientoActual();
            con = conetion.getCon();
            ps = con.prepareStatement(sql1);
            PreparedStatement pss1 = con.prepareStatement(sql2);
            ps.setInt(1, alo.getId());
            pss1.setInt(1, alo.getId());

            rs = ps.executeQuery();
            ResultSet alojamiento = pss1.executeQuery();

            int total_habitaciones = 0;
            int maximo_habitaciones = 0;

            if (rs.next()) {
                total_habitaciones = rs.getInt("total_habitaciones");
            }

            if (alojamiento.next()) {
                maximo_habitaciones = alojamiento.getInt("habitaciones");
            }

            maximo_habitaciones -= total_habitaciones;
           

            if (maximo_habitaciones > 0) {

                String sql = "INSERT INTO habitaciones ( AlojamientoID, Tipo, Vista, cantidad, Precio, ServiciosIncluidos, cantidad_habitaciones,Disponibilidad ) VALUES(?,?,?,?,?,?,?,?) ";
                try {
                    con = conetion.getCon();
                    ps = con.prepareStatement(sql);
                    ps.setInt(1, tr.getAlojamientoid());
                    ps.setString(2, tr.getTipo());
                    ps.setString(3, tr.getVista());
                    ps.setInt(4, tr.getCantidad());
                    ps.setDouble(5, tr.getPrecio());
                    ps.setString(6, tr.getServicios());
                    ps.setInt(7, tr.getCantidad_habitaciones());
                    ps.setInt(8, 0);
                    
                    
                    maximo_habitaciones -=tr.getCantidad_habitaciones();
                    if(maximo_habitaciones>=0){
                    ps.executeUpdate();
                    }else{
                        return 3;
                    }
                    return 1;
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e.toString(), "error de insercion" + e.getMessage(), JOptionPane.ERROR_MESSAGE);
                    e.printStackTrace();
                    return 0;
                }
            }else {
                return 3;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
   }
      
}
}

