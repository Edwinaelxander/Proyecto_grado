/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ventanas_emergentes;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Marely
 */
public class Inactivar_habitacion extends JFrame{
    
    private Container contenedor;
    private JLabel a;
    public JButton si, no;

    public Inactivar_habitacion() {
          contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel cabecera = new JPanel(new BorderLayout());
        JPanel principala = new JPanel(new BorderLayout());
        a = new JLabel("deseas inactivar esta habitacion?");

        principala.add(a, BorderLayout.CENTER);

        si = new JButton("si");
        no = new JButton("no");

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelBotones.add(si);
        panelBotones.add(no);

        principala.add(panelBotones, BorderLayout.SOUTH);

        cabecera.add(principala);
        cabecera.setBackground(Color.white);
        cabecera.setPreferredSize(new Dimension(200, 200));
        contenedor.add(cabecera, BorderLayout.CENTER);

        setLocation(500, 200);
        setSize(300, 300);
    }
    
}
