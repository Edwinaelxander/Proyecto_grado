/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_recepcionista;

import vistas_gerentes.*;
import Db.Conexion;
import controlador.Controlador_alojamiento;
import controlador.Controlador_habitacion;
import controlador.Controlador_reserva;
import datos.datosguardados;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import modelo_habitaciones.habitacion;
import ventanas_emergentes.Inactivar_habitacion;

/**
 *
 * @author Marely
 */
public class Detalles_habitacion_recepcionista extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio, informes, yo, modificar, inactivar,reservar,reserva;
    public JLabel tipo, vista, cantidad, precio;
    public JTextArea servicio;

    JPanel paneldescripcion = new JPanel(new BorderLayout());

    public Detalles_habitacion_recepcionista() {
        Conexion con = new Conexion();
        con.getCon();
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel cabecera = new JPanel(new BorderLayout());
        cabecera.setPreferredSize(new Dimension(450, 600));
        cabecera.setBackground(Color.WHITE);
        cabecera.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 50));
        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));

         JPanel cru1 = new JPanel(new BorderLayout());
          cru1.setBackground(Color.WHITE);
        JPanel cru = new JPanel(new GridLayout(1, 3, 10, 10));
        cru.setPreferredSize(new Dimension(400, 50));
        
        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

       
        Icon ima2 = new ImageIcon("informe.PNG");
        informes = new JButton("informe", ima2);
        informes.setContentAreaFilled(false);
        informes.setVerticalTextPosition(JButton.BOTTOM);
        informes.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);
        
        Icon ima4 = new ImageIcon("reserva.PNG");
        reserva = new JButton("reservar", ima4);
        reserva.setContentAreaFilled(false);
        reserva.setVerticalTextPosition(JButton.BOTTOM);
        reserva.setHorizontalTextPosition(JButton.CENTER);
        reserva.addActionListener(this);

        principal.add(inicio);
       principal.add(reserva);
        principal.add(informes);
        principal.add(yo);

        navegador.add(principal);
        
        paneldescripcion = new JPanel(new GridLayout(0, 1));
        cabecera.add(paneldescripcion);
        JScrollPane scrollPane = new JScrollPane(cabecera, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        contenedor.add(scrollPane, BorderLayout.NORTH);
        buscar();

        contenedor.add(navegador, BorderLayout.SOUTH);
       
        setSize(500, 800);
        
        modificar=new JButton("modificar");
        modificar.setBackground(Color.orange);
        inactivar=new JButton("inactivar");
        inactivar.setBackground(Color.RED.brighter());
        reservar=new JButton("reservar");
        reservar.setBackground(Color.orange);
        cru.add(modificar);
        cru.add(reservar);
        cru.add(inactivar);
        
        cru1.add(cru);
            contenedor.add(cru1, BorderLayout.CENTER);
             inicio.addActionListener(this);
         
           informes.addActionListener(this);
           yo.addActionListener(this);
        modificar.addActionListener(this);
        reservar.addActionListener(this);
        
    }

    private void buscar() {

        habitacion a = datosguardados.getHabitacionActual();
        tipo = new JLabel("TIPO: " + a.getTipo());
        vista = new JLabel("VISTA: " + a.getVista());
        cantidad = new JLabel("CANTIDAD: " + a.getCantidad());
        System.err.println(a.getPrecio());
        precio = new JLabel("PRECIO: $" + a.getPrecio());
        servicio = new JTextArea();
        servicio.setEditable(false);
        servicio.setFocusable(false);
        servicio.setBackground(null);
        JPanel panelDetalles = new JPanel(new GridLayout(5, 1));

        panelDetalles.add(tipo);
        panelDetalles.add(vista);
        panelDetalles.add(cantidad);
        panelDetalles.add(precio);
        panelDetalles.add(servicio);

        paneldescripcion.add(panelDetalles, BorderLayout.CENTER);
        
       
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       
          if (e.getSource() == informes) {
            dispose();
            Incidente_recepcionista a = new Incidente_recepcionista();
            
            a.setVisible(true);

        }
        if(e.getSource()==inicio){
            dispose();
            inicio_recepcionista a=new inicio_recepcionista();
            a.setVisible(true);
        }
        if(e.getSource()==yo){
            dispose();
            Salir_recepcionista a=new Salir_recepcionista();
            a.setVisible(true);
            
        }

        if(e.getSource()==modificar){
            dispose();
            Modificar_habitacion_recepcionista v=new Modificar_habitacion_recepcionista();
            Controlador_habitacion f=new Controlador_habitacion(v);
            v.setVisible(true);
        }
      
         if(e.getSource()==reservar){
            dispose();
            Generar_reserva_recepcionista a=new Generar_reserva_recepcionista();
           Controlador_reserva b=new Controlador_reserva(a);
            a.setVisible(true);
        }
         if (e.getSource() == reserva) {
            dispose();
            Reservas_recepcionista a = new Reservas_recepcionista();
            a.setVisible(true);
        }
    }
}
