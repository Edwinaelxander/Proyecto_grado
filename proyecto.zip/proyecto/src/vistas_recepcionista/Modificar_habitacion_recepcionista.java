/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_recepcionista;

import vistas_gerentes.*;
import Db.Conexion;
import controlador.Controlador_alojamiento;
import datos.datosguardados;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import modelo_habitaciones.habitacion;

/**
 *
 * @author Marely
 */
public class Modificar_habitacion_recepcionista extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio, informes, yo, modificar, confirmar, cancelar, reserva;
    public JLabel tipo, cantidad, precio, servicio;
    public JTextField tipo_TX, cantidad_TX, precio_TX;
    public JTextArea areaservicios;

    public Modificar_habitacion_recepcionista() {
        Conexion con = new Conexion();
        con.getCon();
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 50));
        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));

        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("informe.PNG");
        informes = new JButton("informe", ima2);
        informes.setContentAreaFilled(false);
        informes.setVerticalTextPosition(JButton.BOTTOM);
        informes.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);

        Icon ima4 = new ImageIcon("reserva.PNG");
        reserva = new JButton("reservar", ima4);
        reserva.setContentAreaFilled(false);
        reserva.setVerticalTextPosition(JButton.BOTTOM);
        reserva.setHorizontalTextPosition(JButton.CENTER);
        reserva.addActionListener(this);

        principal.add(inicio);
        principal.add(reserva);
        principal.add(informes);
        principal.add(yo);

        navegador.add(principal);

        inicio.addActionListener(this);

        informes.addActionListener(this);
        yo.addActionListener(this);
        contenedor.add(navegador, BorderLayout.SOUTH);

        JPanel formulario = new JPanel();
        formulario.setPreferredSize(new Dimension(450, 600));
        JPanel formulario1 = new JPanel(new GridLayout(11, 1, 2, 10));
        formulario1.setPreferredSize(new Dimension(450, 500));

        tipo = new JLabel("tipo de habitacion:");
        cantidad = new JLabel("cantidad de huespedes");
        precio = new JLabel("precio");
        servicio = new JLabel("Servicios");

        habitacion hab = datosguardados.getHabitacionActual();
        tipo_TX = new JTextField(10);
        cantidad_TX = new JTextField(10);
        precio_TX = new JTextField(50);
        areaservicios = new JTextArea(10, 1);

        tipo_TX.setText(hab.getTipo());
        cantidad_TX.setText("" + hab.getCantidad());
        System.err.println(hab.getPrecio());
        precio_TX.setText("" + hab.getPrecio());
        areaservicios.setText(hab.getServicios());

        JScrollPane scrollPane1 = new JScrollPane(areaservicios, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        modificar = new JButton("modificar");
        modificar.setBackground(Color.orange);
        modificar.addActionListener(this);

        confirmar = new JButton("Confirmar");
        confirmar.setVisible(false);
        confirmar.setBackground(Color.orange);
        cancelar = new JButton("Cancelar");
        cancelar.setVisible(false);
        cancelar.addActionListener(this);

        tipo_TX.setEditable(false);
        cantidad_TX.setEditable(false);
        precio_TX.setEditable(false);
        areaservicios.setEditable(false);

        formulario1.add(tipo);
        formulario1.add(tipo_TX);
        formulario1.add(cantidad);
        formulario1.add(cantidad_TX);
        formulario1.add(precio);
        formulario1.add(precio_TX);
        formulario1.add(servicio);
        formulario1.add(scrollPane1);
        formulario1.add(confirmar);
        formulario1.add(cancelar);
        formulario1.add(modificar);

        formulario.add(formulario1);

        contenedor.add(formulario, BorderLayout.CENTER);

        setSize(500, 800);

    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == informes) {
            dispose();
            Incidente_recepcionista a = new Incidente_recepcionista();

            a.setVisible(true);

        }
        if (e.getSource() == inicio) {
            dispose();
            inicio_recepcionista a = new inicio_recepcionista();
            a.setVisible(true);
        }
        if (e.getSource() == yo) {
            dispose();
            Salir_recepcionista a = new Salir_recepcionista();
            a.setVisible(true);

        }
        if (e.getSource() == reserva) {
            dispose();
            Reservas_recepcionista a = new Reservas_recepcionista();
            a.setVisible(true);
        }

        if (e.getSource() == modificar) {
            tipo_TX.setEditable(true);
            cantidad_TX.setEditable(true);
            precio_TX.setEditable(true);
            areaservicios.setEditable(true);

            confirmar.setVisible(true);
            cancelar.setVisible(true);
            modificar.setVisible(false);
        }
        if (e.getSource() == cancelar) {

            tipo_TX.setEditable(false);
            cantidad_TX.setEditable(false);
            precio_TX.setEditable(false);
            areaservicios.setEditable(false);

            confirmar.setVisible(false);
            cancelar.setVisible(false);
            modificar.setVisible(true);

        }
    }

}
