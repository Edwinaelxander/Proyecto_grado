/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_recepcionista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import org.jdesktop.swingx.JXDatePicker;

/**
 *
 * @author Marely
 */
public class pagar_recerva_recepcionista extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio, informes, yo, reserva, pagar;
    public JLabel nombre, numero, fecha, codigo;
    public JTextField nombre_TX, numero_TX, codigo_TX;
    public JXDatePicker fechatarjeta;

    public pagar_recerva_recepcionista() {
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());
        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 50));
        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));

        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("informe.PNG");
        informes = new JButton("informe", ima2);
        informes.setContentAreaFilled(false);
        informes.setVerticalTextPosition(JButton.BOTTOM);
        informes.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);

        Icon ima4 = new ImageIcon("reserva.PNG");
        reserva = new JButton("reservar", ima4);
        reserva.setContentAreaFilled(false);
        reserva.setVerticalTextPosition(JButton.BOTTOM);
        reserva.setHorizontalTextPosition(JButton.CENTER);
        reserva.addActionListener(this);

        principal.add(inicio);
        principal.add(reserva);
        principal.add(informes);
        principal.add(yo);

        navegador.add(principal);

        contenedor.add(navegador, BorderLayout.SOUTH);

        JPanel cabecera = new JPanel(new BorderLayout());
        TitledBorder titledBorder1 = BorderFactory.createTitledBorder("PAGAR");
        titledBorder1.setTitleFont(new Font("Arial", Font.BOLD, 30));
        titledBorder1.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder1.setTitleJustification(TitledBorder.CENTER);

        cabecera.setBorder(titledBorder1);

        JPanel pagarreserva = new JPanel(new GridLayout(9, 1));

        pagar = new JButton("Pagar");

        nombre = new JLabel("Nombre:");
        numero = new JLabel("Número de tarjeta:");
        fecha = new JLabel("Fecha de expedicion:");
        codigo = new JLabel("cvc:");

        nombre_TX = new JTextField(20);
        numero_TX = new JTextField(20);

        codigo_TX = new JTextField(20);

        fechatarjeta = new JXDatePicker();
        fechatarjeta.setDate(new Date());
        fechatarjeta.setFormats(new SimpleDateFormat("MM/yyyy"));

        pagarreserva.add(nombre);
        pagarreserva.add(nombre_TX);
        pagarreserva.add(numero);
        pagarreserva.add(numero_TX);
        pagarreserva.add(fecha);
        pagarreserva.add(fechatarjeta);
        pagarreserva.add(codigo);
        pagarreserva.add(codigo_TX);
        pagarreserva.add(pagar, BorderLayout.CENTER);
        cabecera.add(pagarreserva);
        contenedor.add(cabecera, BorderLayout.CENTER);

        setSize(500, 800);
         inicio.addActionListener(this);
         
           informes.addActionListener(this);
           yo.addActionListener(this);
     

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == informes) {
            dispose();
            Incidente_recepcionista a = new Incidente_recepcionista();

            a.setVisible(true);

        }
        if (e.getSource() == inicio) {
            dispose();
            inicio_recepcionista a = new inicio_recepcionista();
            a.setVisible(true);
        }
        if (e.getSource() == yo) {
            dispose();
            Salir_recepcionista a = new Salir_recepcionista();
            a.setVisible(true);

        }
        if (e.getSource() == reserva) {
            dispose();
            Reservas_recepcionista a = new Reservas_recepcionista();
            a.setVisible(true);
        }
    }

    public static void main(String[] args) {
        pagar_recerva_recepcionista a = new pagar_recerva_recepcionista();
        a.setVisible(true);
    }

}
