/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_recepcionista;

import datos.datosguardados;
import efectos.Botonhover;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import modelo_habitaciones.habitacion;
import org.jdesktop.swingx.JXDatePicker;

/**
 *
 * @author Marely
 */
public class Generar_reserva_recepcionista extends JFrame implements ActionListener {

    private Container contenedor;
    public JLabel calendariosalidad, calendarioentrada, personas, habitaciones;
    public JTextField personas_TX, habitaciones_TX;
    public JXDatePicker fechasalidad, fechaentrada;
    public java.sql.Date fechaSeleccionadasalidad, fechaSeleccionadaSentrada;
    public JButton inicio, informes, yo, pagar, registrar, reserva;
    Font font = new Font("Futura ", Font.BOLD, 16);

    public Generar_reserva_recepcionista() {
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 50));
        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));

        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("informe.PNG");
        informes = new JButton("informe", ima2);
        informes.setContentAreaFilled(false);
        informes.setVerticalTextPosition(JButton.BOTTOM);
        informes.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);

        Icon ima4 = new ImageIcon("reserva.PNG");
        reserva = new JButton("reservar", ima4);
        reserva.setContentAreaFilled(false);
        reserva.setVerticalTextPosition(JButton.BOTTOM);
        reserva.setHorizontalTextPosition(JButton.CENTER);

        principal.add(inicio);
        principal.add(reserva);
        principal.add(informes);
        principal.add(yo);

        navegador.add(principal);
        contenedor.add(navegador, BorderLayout.SOUTH);
        Botonhover efectoHover = new Botonhover(principal);
        efectoHover.aplicarEfectoHover();

        JPanel cabecera = new JPanel(new BorderLayout());
        TitledBorder titledBorder1 = BorderFactory.createTitledBorder("RESERVAR");
        titledBorder1.setTitleFont(new Font("Serif", Font.BOLD, 30));
        titledBorder1.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder1.setTitleJustification(TitledBorder.CENTER);

        cabecera.setBorder(titledBorder1);

        JPanel reservas = new JPanel(new GridLayout(9, 1));

        calendariosalidad = new JLabel("fecha Salida:");

        calendarioentrada = new JLabel("Fecha Entrada:");
        personas = new JLabel("Cantidad maxima de huespedes por habitacion:");
        habitaciones = new JLabel("Cantidad de habitaciones:");

        personas_TX = new JTextField(20);
        habitacion h = datosguardados.getHabitacionActual();
        personas_TX.setText("" + h.getCantidad());
        personas_TX.setEditable(false);
        habitaciones_TX = new JTextField(20);

        pagar = new JButton("pagar");
        pagar.setBackground(Color.orange);
         Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);

        fechasalidad = new JXDatePicker();
        fechasalidad.setDate(cal.getTime());
        fechasalidad.setFormats(new SimpleDateFormat("dd/MM/yyyy"));
        fechaentrada = new JXDatePicker();
        fechaentrada.setDate(new Date());
        fechaentrada.setFormats(new SimpleDateFormat("dd/MM/yyyy"));

        Date fechaSeleccionada = fechasalidad.getDate();
        Date fechaSeleccionada1 = fechaentrada.getDate();
        fechaSeleccionadasalidad = new java.sql.Date(fechaSeleccionada.getTime());
        fechaSeleccionadaSentrada = new java.sql.Date(fechaSeleccionada1.getTime());

        reservas.add(calendarioentrada);
        reservas.add(fechaentrada);
        reservas.add(calendariosalidad);
        reservas.add(fechasalidad);
        reservas.add(personas);
        reservas.add(personas_TX);
        reservas.add(habitaciones);
        reservas.add(habitaciones_TX);
        reservas.add(pagar);

        cabecera.add(reservas);
        contenedor.add(cabecera, BorderLayout.CENTER);

        inicio.addActionListener(this);

        informes.addActionListener(this);
        yo.addActionListener(this);
        setSize(500, 800);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == informes) {
            dispose();
            Incidente_recepcionista a = new Incidente_recepcionista();

            a.setVisible(true);

        }
        if (e.getSource() == inicio) {
            dispose();
            inicio_recepcionista a = new inicio_recepcionista();
            a.setVisible(true);
        }
        if (e.getSource() == yo) {
            dispose();
            Salir_recepcionista a = new Salir_recepcionista();
            a.setVisible(true);

        }
        if (e.getSource() == reserva) {
            dispose();
            Reservas_recepcionista a = new Reservas_recepcionista();
            a.setVisible(true);
        }
    }

}
