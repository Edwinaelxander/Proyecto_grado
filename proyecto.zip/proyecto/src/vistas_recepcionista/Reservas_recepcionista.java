/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_recepcionista;

import datos.datosguardados;
import efectos.Redondiarboton;
import efectos.Redondiarjpanel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;
import modelo_habitaciones.habitacion;
import modelo_reserva.Reserva;
import modelo_reserva.ReservaDto;
import modelo_reserva.ReservaDao;
import modelo_usuario.Usuario;

/**
 *
 * @author Marely
 */
public class Reservas_recepcionista extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio, informes, yo, registrar, reserva, a, misreservas, reservasonline, terminada, check_in, check_out;
    JPanel panelreser = new JPanel(new BorderLayout());

    public Reservas_recepcionista() {
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 50));
        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));

        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        Icon ima2 = new ImageIcon("informe.PNG");
        informes = new JButton("informe", ima2);
        informes.setContentAreaFilled(false);
        informes.setVerticalTextPosition(JButton.BOTTOM);
        informes.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);

        Icon ima4 = new ImageIcon("reserva.PNG");
        reserva = new JButton("reservar", ima4);
        reserva.setContentAreaFilled(false);
        reserva.setVerticalTextPosition(JButton.BOTTOM);
        reserva.setHorizontalTextPosition(JButton.CENTER);

        principal.add(inicio);
        principal.add(reserva);
        principal.add(informes);
        principal.add(yo);

        navegador.add(principal);
        contenedor.add(navegador, BorderLayout.SOUTH);

        JPanel a1 = new JPanel(new BorderLayout());
        a1.setBackground(Color.white);

        TitledBorder titledBorder = BorderFactory.createTitledBorder("RESERVAS");
        titledBorder.setTitleFont(new Font("Serif", Font.BOLD, 30));
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        titledBorder.setTitleJustification(TitledBorder.CENTER);

        a1.setBorder(titledBorder);

        JPanel a3 = new JPanel(new GridLayout(1, 4, 10, 3));
        a3.setBackground(Color.white);

        misreservas = new Redondiarboton("local");
        misreservas.addActionListener(this);

        terminada = new Redondiarboton("terminada");
        reservasonline = new Redondiarboton("online");
        reservasonline.setBackground(Color.orange);
        reservasonline.addActionListener(this);
        a = new Redondiarboton("activa");
        a.addActionListener(this);
        a3.add(reservasonline);
        a3.add(misreservas);
        a3.add(a);
        a3.add(terminada);

        a1.add(a3, BorderLayout.NORTH);
        contenedor.add(a1, BorderLayout.NORTH);

        panelreser = new JPanel(new GridLayout(0, 2, 5, 10));
        panelreser.setPreferredSize(new Dimension(460, 1000));
        panelreser.setBackground(Color.white);

        a1.add(panelreser, BorderLayout.CENTER);

        JScrollPane scrollPane = new JScrollPane(panelreser, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        contenedor.add(scrollPane, BorderLayout.CENTER);
        reservaonlines();

        setSize(500, 800);
        inicio.addActionListener(this);
        informes.addActionListener(this);
        yo.addActionListener(this);
       terminada.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == misreservas) {
            panelreser.removeAll();
            reservaspresenciales();
            panelreser.revalidate();
            panelreser.repaint();
            misreservas.setBackground(Color.ORANGE);
            reservasonline.setBackground(null);
            a.setBackground(null);
            terminada.setBackground(null);
        }
        if (e.getSource() == reservasonline) {
            panelreser.removeAll();
            reservaonlines();
            panelreser.revalidate();
            panelreser.repaint();
            reservasonline.setBackground(Color.ORANGE);
            misreservas.setBackground(null);
            a.setBackground(null);
            terminada.setBackground(null);
        }

        if (e.getSource() == a) {
            panelreser.removeAll();
            reservas();
            panelreser.revalidate();
            panelreser.repaint();
            a.setBackground(Color.orange);
            misreservas.setBackground(null);
            reservasonline.setBackground(null);
            terminada.setBackground(null);
        }
        if (e.getSource() == terminada) {
            panelreser.removeAll();
            terminarreserva();
            panelreser.revalidate();
            panelreser.repaint();
            a.setBackground(null);
            misreservas.setBackground(null);
            reservasonline.setBackground(null);
            terminada.setBackground(Color.orange);
        }

        if (e.getSource() == informes) {
            dispose();
            Incidente_recepcionista a = new Incidente_recepcionista();
            a.setVisible(true);

        }
        if (e.getSource() == inicio) {
            dispose();
            inicio_recepcionista a = new inicio_recepcionista();
            a.setVisible(true);
        }
        if (e.getSource() == yo) {
            dispose();
            Salir_recepcionista a = new Salir_recepcionista();
            a.setVisible(true);

        }

    }

    public static void main(String[] args) {
        Reservas_recepcionista a = new Reservas_recepcionista();
        a.setVisible(true);
    }

    private void reservaonlines() {
        ReservaDao alo = new ReservaDao();
        List<ReservaDto> reserva = alo.reservasVirtuales();
        for (ReservaDto reservaDTO : reserva) {
            Usuario u = datosguardados.getUsuarioactual();
            habitacion h = datosguardados.getHabitacionActual();

            Redondiarjpanel panelreserva = new Redondiarjpanel();
            panelreserva.setBackground(Color.white);
            panelreserva.setLayout(new GridLayout(9, 1));

            check_in = new Redondiarboton("check-in");

            JLabel idReservaLabel = new JLabel("ID de Reserva: " + reservaDTO.getIdReserva());
            JLabel fechaEntradaLabel = new JLabel("Fecha de Entrada: " + reservaDTO.getFechaEntrada());
            JLabel fechaSalidaLabel = new JLabel("Fecha de Salida: " + reservaDTO.getFechaSalida());
            JLabel habitacionLabel = new JLabel("Habitación: " + reservaDTO.getHabitacion());
            JLabel nombreUsuarioLabel = new JLabel("Nombre de Usuario: " + reservaDTO.getNombreUsuario());
            JLabel cedulaUsuarioLabel = new JLabel("Cédula de Usuario: " + reservaDTO.getCedulaUsuario());
            JLabel tipoHabitacionLabel = new JLabel("Tipo de Habitación: " + reservaDTO.getTipoHabitacion());
            JLabel cantidadHuespedesLabel = new JLabel("Cantidad maxima de Huéspedes: " + reservaDTO.getCantidadHuespedes());
            panelreserva.add(idReservaLabel);
            panelreserva.add(fechaEntradaLabel);
            panelreserva.add(fechaSalidaLabel);
            panelreserva.add(habitacionLabel);
            panelreserva.add(nombreUsuarioLabel);
            panelreserva.add(cedulaUsuarioLabel);
            panelreserva.add(tipoHabitacionLabel);
            panelreserva.add(cantidadHuespedesLabel);
            panelreserva.add(check_in);

            panelreser.add(panelreserva, BorderLayout.CENTER);
            check_in.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    Reserva r = new Reserva();
                    r.setIdreserva(reservaDTO.getIdReserva());
                    datosguardados.setReservaactual(r);
                    int resultado = JOptionPane.showConfirmDialog(null, "¿Estás seguro de confirmar reserva?", "Confirmación", JOptionPane.YES_NO_OPTION);
                    if (resultado == JOptionPane.YES_OPTION) {
                        ReservaDao d = new ReservaDao();
                        int resul = d.modificarestadoreserva(2);
                        if (resul == 1) {
                            JOptionPane.showMessageDialog(panelreser, "check-in exitoso");
                        }
                    }
                }

            });
        }
    }

    private void reservaspresenciales() {
        ReservaDao alo = new ReservaDao();
        List<ReservaDto> reserva = alo.reservaspresenciales(1);
        for (ReservaDto reservaDTO : reserva) {
            Usuario u = datosguardados.getUsuarioactual();
            habitacion h = datosguardados.getHabitacionActual();

            Redondiarjpanel panelreserva = new Redondiarjpanel();
            panelreserva.setBackground(Color.white);
            panelreserva.setLayout(new GridLayout(7, 1));

            check_in = new Redondiarboton("check-in");

            JLabel idReservaLabel = new JLabel("ID de Reserva: " + reservaDTO.getIdReserva());
            JLabel fechaEntradaLabel = new JLabel("Fecha de Entrada: " + reservaDTO.getFechaEntrada());
            JLabel fechaSalidaLabel = new JLabel("Fecha de Salida: " + reservaDTO.getFechaSalida());
            JLabel habitacionLabel = new JLabel("Habitación: " + reservaDTO.getHabitacion());
            JLabel tipoHabitacionLabel = new JLabel("Tipo de Habitación: " + reservaDTO.getTipoHabitacion());
            JLabel cantidadHuespedesLabel = new JLabel("Cantidad de Huéspedes: " + reservaDTO.getCantidadHuespedes());
            panelreserva.add(idReservaLabel);
            panelreserva.add(fechaEntradaLabel);
            panelreserva.add(fechaSalidaLabel);
            panelreserva.add(habitacionLabel);
            panelreserva.add(tipoHabitacionLabel);
            panelreserva.add(cantidadHuespedesLabel);
            panelreserva.add(check_in);

            panelreser.add(panelreserva, BorderLayout.CENTER);
            check_in.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    Reserva r = new Reserva();
                    r.setIdreserva(reservaDTO.getIdReserva());
                    datosguardados.setReservaactual(r);
                    int resultado = JOptionPane.showConfirmDialog(null, "¿Estás seguro de confirmar reserva?", "Confirmación", JOptionPane.YES_NO_OPTION);
                    if (resultado == JOptionPane.YES_OPTION) {
                        ReservaDao d = new ReservaDao();
                        int resul = d.modificarestadoreserva(2);
                        if (resul == 1) {
                            JOptionPane.showMessageDialog(panelreser, "check-in exitoso");
                        }
                    }
                }

            });

        }

    }

    private void reservas() {
        ReservaDao alo = new ReservaDao();
        List<ReservaDto> reserva = alo.reservaspresenciales(2);
        for (ReservaDto reservaDTO : reserva) {
            Usuario u = datosguardados.getUsuarioactual();
            habitacion h = datosguardados.getHabitacionActual();

            Redondiarjpanel panelreserva = new Redondiarjpanel();
            panelreserva.setBackground(Color.white);
            panelreserva.setLayout(new GridLayout(7, 1));

            check_out = new Redondiarboton("check-out");

            JLabel idReservaLabel = new JLabel("ID de Reserva: " + reservaDTO.getIdReserva());
            JLabel fechaEntradaLabel = new JLabel("Fecha de Entrada: " + reservaDTO.getFechaEntrada());
            JLabel fechaSalidaLabel = new JLabel("Fecha de Salida: " + reservaDTO.getFechaSalida());
            JLabel habitacionLabel = new JLabel("Habitación: " + reservaDTO.getHabitacion());
            JLabel tipoHabitacionLabel = new JLabel("Tipo de Habitación: " + reservaDTO.getTipoHabitacion());
            JLabel cantidadHuespedesLabel = new JLabel("Cantidad de Huéspedes: " + reservaDTO.getCantidadHuespedes());
            panelreserva.add(idReservaLabel);
            panelreserva.add(fechaEntradaLabel);
            panelreserva.add(fechaSalidaLabel);
            panelreserva.add(habitacionLabel);
            panelreserva.add(tipoHabitacionLabel);
            panelreserva.add(cantidadHuespedesLabel);
            panelreserva.add(check_out);

            panelreser.add(panelreserva, BorderLayout.CENTER);
            check_out.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    Reserva r = new Reserva();
                    r.setIdreserva(reservaDTO.getIdReserva());
                    datosguardados.setReservaactual(r);
                    int resultado = JOptionPane.showConfirmDialog(null, "¿Estás seguro de confirmar chein_out?", "Confirmación", JOptionPane.YES_NO_OPTION);
                    if (resultado == JOptionPane.YES_OPTION) {
                        ReservaDao d = new ReservaDao();
                        int resul = d.modificarestadoreserva(3);
                        if (resul == 1) {
                            JOptionPane.showMessageDialog(panelreser, "check-in exitoso");
                        }
                    }
                }

            });


        }

    }
    private void terminarreserva() {
        ReservaDao alo = new ReservaDao();
        List<ReservaDto> reserva = alo.reservaspresenciales(3);
        for (ReservaDto reservaDTO : reserva) {
            Usuario u = datosguardados.getUsuarioactual();
            habitacion h = datosguardados.getHabitacionActual();

            Redondiarjpanel panelreserva = new Redondiarjpanel();
            panelreserva.setBackground(Color.white);
            panelreserva.setLayout(new GridLayout(7, 1));

            check_out = new Redondiarboton("check-out");

            JLabel idReservaLabel = new JLabel("ID de Reserva: " + reservaDTO.getIdReserva());
            JLabel fechaEntradaLabel = new JLabel("Fecha de Entrada: " + reservaDTO.getFechaEntrada());
            JLabel fechaSalidaLabel = new JLabel("Fecha de Salida: " + reservaDTO.getFechaSalida());
            JLabel habitacionLabel = new JLabel("Habitación: " + reservaDTO.getHabitacion());
            JLabel tipoHabitacionLabel = new JLabel("Tipo de Habitación: " + reservaDTO.getTipoHabitacion());
            JLabel cantidadHuespedesLabel = new JLabel("Cantidad de Huéspedes: " + reservaDTO.getCantidadHuespedes());
            panelreserva.add(idReservaLabel);
            panelreserva.add(fechaEntradaLabel);
            panelreserva.add(fechaSalidaLabel);
            panelreserva.add(habitacionLabel);
            panelreserva.add(tipoHabitacionLabel);
            panelreserva.add(cantidadHuespedesLabel);
            panelreserva.add(check_out);

            panelreser.add(panelreserva, BorderLayout.CENTER);
          


        }

    }

}
