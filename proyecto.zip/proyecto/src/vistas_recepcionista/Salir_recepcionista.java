/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistas_recepcionista;

import vistas_gerentes.*;
import controlador.Controlador_alojamiento;
import datos.datosguardados;
import inicios_gui.Inicio;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import modelo_gerente.gerente;
import modelo_recepcionista.Recepcionista;

/**
 *
 * @author Marely
 */
public class Salir_recepcionista extends JFrame implements ActionListener {

    private Container contenedor;
    public JButton inicio,  informes, yo, salir,reserva;

    public Salir_recepcionista() {
        contenedor = getContentPane();
        contenedor.setLayout(new BorderLayout());

        JPanel cru1 = new JPanel(new BorderLayout());

        cru1.setBackground(Color.WHITE);
        JPanel cru = new JPanel(new GridLayout(1, 3, 10, 50));
        cru.setPreferredSize(new Dimension(450, 80));

        JPanel principal = new JPanel(new GridLayout(1, 4, 10, 50));
        JPanel navegador = new JPanel();
        principal.setPreferredSize(new Dimension(450, 100));

        Icon ima = new ImageIcon("inicio.PNG");
        inicio = new JButton("inicio", ima);
        inicio.setContentAreaFilled(false);
        inicio.setVerticalTextPosition(JButton.BOTTOM);
        inicio.setHorizontalTextPosition(JButton.CENTER);

        
        Icon ima2 = new ImageIcon("informe.PNG");
        informes = new JButton("informe", ima2);
        informes.setContentAreaFilled(false);
        informes.setVerticalTextPosition(JButton.BOTTOM);
        informes.setHorizontalTextPosition(JButton.CENTER);

        Icon ima3 = new ImageIcon("icono.PNG");
        yo = new JButton("yo", ima3);
        yo.setContentAreaFilled(false);
        yo.setVerticalTextPosition(JButton.BOTTOM);
        yo.setHorizontalTextPosition(JButton.CENTER);
        
        Icon ima4 = new ImageIcon("reserva.PNG");
        reserva = new JButton("reservar", ima4);
        reserva.setContentAreaFilled(false);
        reserva.setVerticalTextPosition(JButton.BOTTOM);
        reserva.setHorizontalTextPosition(JButton.CENTER);
        reserva.addActionListener(this);

        principal.add(inicio);
      principal.add(reserva);
        principal.add(informes);
        principal.add(yo);

        navegador.add(principal);

        contenedor.add(navegador, BorderLayout.SOUTH);
       
        setSize(500, 800);

        JPanel texto = new JPanel(new FlowLayout());
        texto.setBorder(BorderFactory.createEmptyBorder(100, 10, 10, 10));

        salir = new JButton("cerrar sesion");
        salir.setPreferredSize(new Dimension(600, 150));
        salir.setBackground(Color.red);
        texto.add(salir);
        contenedor.add(texto, BorderLayout.CENTER);

        salir.addActionListener(this);
        inicio.addActionListener(this);
       
        informes.addActionListener(this);
        yo.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        if (e.getSource() == informes) {
            dispose();
            Incidente_recepcionista a = new Incidente_recepcionista();
            a.setVisible(true);

        }
        if (e.getSource() == inicio) {
            dispose();
            inicio_recepcionista a = new inicio_recepcionista();
            a.setVisible(true);
        }
        if (e.getSource() == yo) {
            dispose();
            Salir_recepcionista a = new Salir_recepcionista();
            a.setVisible(true);

        }
        if(e.getSource()==salir){
            dispose();
            Recepcionista g=new Recepcionista();
            datosguardados.setRecepcionistaactual(g);
           
            Inicio a=new Inicio();
            a.setVisible(true);
        }
        if (e.getSource() == reserva) {
            dispose();
            Reservas_recepcionista a = new Reservas_recepcionista();
            a.setVisible(true);
        }
    }

}
