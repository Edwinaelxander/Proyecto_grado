/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_incidentes;

import Db.Conexion;
import datos.datosguardados;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo_alojamiento.alojamiento;
import modelo_pqrs.Pqrs;

/**
 *
 * @author Marely
 */
public class IncidenteDao implements crud_incidente {
    
    Conexion conetion = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    
    @Override
    public int hacerinforme(Object tr) {
        return 0;
    }
    
    @Override
    public List lisinformes() {
        List<Incidente> informe = new ArrayList<>();
        String sql = "SELECT * FROM incidentes WHERE respuesta IS NULL OR respuesta = ''";
        try {
            
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            while (rs.next()) {
                
                int id = rs.getInt("incidenteID");
                String descripcion = rs.getString("descripcion");
                int idalojamiento = rs.getInt("AlojamientoId");
                
                Incidente informes = new Incidente();
                
                informes.setIncidenteid(id);
                informes.setDescripcion(descripcion);
                informes.setAlojamientoid(idalojamiento);
                
                informe.add(informes);
                datosguardados.setIncidenteactual(informes);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return informe;
        
    }
    
    public int responder(Incidente incidente) {
        String sql = "UPDATE incidentes SET respuesta=? WHERE incidenteID=?";
        try {
            Incidente i = datosguardados.getIncidenteactual();
            con = conetion.getCon();
            ps = con.prepareStatement(sql);
            ps.setString(1, incidente.getResponder());
            ps.setInt(2, i.getIncidenteid());
            
            ps.executeUpdate();
            return 1;
            
        } catch (Exception e) {
            System.out.print(e.toString() + "error en responder " + e.getMessage());
            return 0;
        }
    }
    
}
