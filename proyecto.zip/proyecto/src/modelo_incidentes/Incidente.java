/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_incidentes;

/**
 *
 * @author Marely
 */
public class Incidente {
    private int incidenteid;
    private int alojamientoid;
    private String descripcion;
    private String responder;
    
    

    public Incidente(int usuario, String descripcion, String responder) {
        this.incidenteid = usuario;
        this.descripcion = descripcion;
        this.responder = responder;
    }

 
    public Incidente() {
    }

    public int getAlojamientoid() {
        return alojamientoid;
    }

    public void setAlojamientoid(int alojamientoid) {
        this.alojamientoid = alojamientoid;
    }
    
    

    public String getResponder() {
        return responder;
    }

    public void setResponder(String responder) {
        this.responder = responder;
    }

    public int getIncidenteid() {
        return incidenteid;
    }

    public void setIncidenteid(int incidenteid) {
        this.incidenteid = incidenteid;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    
}
