/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_pagos;

import java.sql.Date;

/**
 *
 * @author Marely
 */
public class Pagar {
    private static int idpago;
    private int numero_tarjeta;
    private Date fecha_expedicion;
    private int codigo;
    private static  int[]idreserva;
    private double valorpagar;
    
    private String nombre;

    public Pagar() {
    }
    

    public Pagar(int idpago, int numero_tarjeta, Date fecha_expedicion, int codigo, String nombre) {
        this.idpago = idpago;
        this.numero_tarjeta = numero_tarjeta;
        this.fecha_expedicion = fecha_expedicion;
        this.codigo = codigo;
        this.nombre = nombre;
    }

    public int getIdpago() {
        return idpago;
    }

    public int[] getIdreserva() {
        return idreserva;
    }

    public double getValorpagar() {
        return valorpagar;
    }

    public void setValorpagar(double valorpagar) {
        this.valorpagar = valorpagar;
    }
         

    public void setIdreserva(int[] idreserva) {
        this.idreserva = idreserva;
    }

    
    public void setIdpago(int idpago) {
        this.idpago = idpago;
    }

    public int getNumero_tarjeta() {
        return numero_tarjeta;
    }

    public void setNumero_tarjeta(int numero_tarjeta) {
        this.numero_tarjeta = numero_tarjeta;
    }

    public Date getFecha_expedicion() {
        return fecha_expedicion;
    }

    public void setFecha_expedicion(Date fecha_expedicion) {
        this.fecha_expedicion = fecha_expedicion;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    
    
}
