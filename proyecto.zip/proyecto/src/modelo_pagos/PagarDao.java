/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_pagos;

import Db.Conexion;
import datos.datosguardados;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import modelo_reserva.Reserva;

/**
 *
 * @author Marely
 */
public class PagarDao implements Crud_pagar {

    Conexion conetion = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    @Override
    public int hacerpago(Pagar tr) {

        String sql = "INSERT INTO pagos (Nombre, Numerotarjeta, fecha_expiracion,codigo,total) VALUES(?,?,?,?,?)";

        try {
            con = conetion.getCon();
            ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setString(1, tr.getNombre());
            ps.setInt(2, tr.getNumero_tarjeta());
            ps.setDate(3, tr.getFecha_expedicion());
            ps.setInt(4, tr.getCodigo());
            Pagar p=datosguardados.getPagaractual();
            ps.setDouble(5, p.getValorpagar());

            int affectedRows = ps.executeUpdate();
            if (affectedRows > 0) {
                ResultSet generatedKeys = ps.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int idPago = generatedKeys.getInt(1);
                    tr.setIdpago(idPago);

                    reportarpago(idPago); // Llamar a reportarpago con el ID de pago generado
                    return 1;
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.toString(), "error de insercion" + e.getMessage(), JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            return 0;
        }
        return 0;
    }

    private void reportarpago(int idPago) {
        Pagar p = new Pagar();
        int[] idsreserva = p.getIdreserva();
        
        String sql = "UPDATE reservas SET pagoID=? WHERE ReservaID=?";
        try {
            for (int id : idsreserva) {

                con = conetion.getCon();
                ps = con.prepareStatement(sql);
                Reserva a = datosguardados.getReservaactual();
                Pagar tr = new Pagar();
                ps.setInt(1, idPago);
                ps.setInt(2, id);
                ps.executeUpdate();

              
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, e.toString(), "error de actualiacion 1 " + e.getMessage(), JOptionPane.ERROR_MESSAGE);

        }
    }

}
