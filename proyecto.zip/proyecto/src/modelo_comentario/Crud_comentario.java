/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo_comentario;

import java.util.List;

/**
 *
 * @author Marely
 */
public interface Crud_comentario<comentario> {

    public int agregarcomentario(Comentario tr);

    public List<comentario> obtenercomentarios();

}
